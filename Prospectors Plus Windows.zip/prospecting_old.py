#!/usr/bin/env python3
"""
Prospecting auto-pan macro for macOS.

THE TWO BARS
    DIG BAR (vertical, right of the player) -- a TIMED skill bar.
        Hold LMB; a white line bounces along the bar. Release when the white
        line is on the GREEN end so it "lands" on green. The macro watches the
        green pixel and releases the instant the white line crosses it.
    CAPACITY BAR (horizontal, gray -> yellow, bottom centre) -- NOT timed.
        Each dig adds yellow. May take one or several digs to fill. When it is
        FULL (all yellow) we run the empty sequence.

ONE FULL LOOP
    repeat:
        dig_once()                 # hold LMB, release when white hits green
        if capacity_full():        # yellow reached the end of the capacity bar
            empty_sequence()       # S back into water, W forward + LMB shake,
                                   # then hold LMB to empty the pan
    # otherwise keep digging until the capacity bar fills

Hotkeys:
    F8   -> start / stop the loop
    Esc  -> quit (always releases keys/mouse first)

SETUP (WINDOWS)
    1.  Run Install.bat (installs Python + the needed packages), or:
          pip install mss numpy pywebview
    2.  Open the app (Prospectors Plus) or run:  python prospecting_app.py
    3.  Calibrate the pixels for YOUR screen in the app's Calibrate tab.
    4.  Tab into Roblox, press Ctrl+K to start/stop, Esc to quit.

NOTE: this is the WINDOWS port. Input uses Windows SendInput (scancodes), hotkeys
use GetAsyncKeyState, screen capture uses mss. The game logic is identical to the
macOS version.
"""

import sys
import gc
import os
import json
import time
import threading
import subprocess
import urllib.request
from collections import namedtuple

# Settings written by the UI (prospecting_ui.py). Loaded at startup to override
# the defaults below, so you can tune everything without editing this file.
# When bundled by PyInstaller (sys.frozen) the config lives in a writable
# per-user folder, matching prospecting_app.py's data dir.
if getattr(sys, "frozen", False):
    _DATA_DIR = os.path.join(os.environ.get("LOCALAPPDATA")
                             or os.path.expanduser("~"), "Prospectors Plus")
else:
    _DATA_DIR = os.path.dirname(os.path.abspath(__file__))
try:
    os.makedirs(_DATA_DIR, exist_ok=True)
except OSError:
    pass
CONFIG_FILE = os.path.join(_DATA_DIR, "prospecting_config.json")


def load_config():
    """Override module config globals from prospecting_config.json (if present)."""
    try:
        with open(CONFIG_FILE) as f:
            data = json.load(f)
    except (FileNotFoundError, ValueError, OSError):
        return
    g = globals()
    applied = 0
    for k, v in data.items():
        if k in g and not callable(g[k]):
            if k in ("WEBHOOK_URL", "WEBHOOK_SECRET") and not v:
                continue          # a blank config must NOT wipe the baked default
            g[k] = v
            applied += 1
    # --- Easy tuning: layer the friendly offsets on top of the real knobs. Each
    #     maps to ALL the knobs that actually drive that move, so the effect shows.
    g["WATER_EXTRA_BACK_MS"]  = g.get("WATER_EXTRA_BACK_MS", 0) + EASY_WATER_BACK_MS
    g["PAN_BACK_MAX_MS"]      = g.get("PAN_BACK_MAX_MS", 0) + EASY_WATER_BACK_MS
    g["LAND_SETTLE_MS"]       = g.get("LAND_SETTLE_MS", 0) + EASY_LAND_FWD_MS
    g["LAND_PROBE_NUDGE_MS"]  = g.get("LAND_PROBE_NUDGE_MS", 0) + EASY_LAND_FWD_MS
    g["DEPOSIT_MAX_MS"]       = g.get("DEPOSIT_MAX_MS", 0) + EASY_LAND_FWD_MS
    g["SHAKE_START_DELAY_MS"] = g.get("SHAKE_START_DELAY_MS", 0) + EASY_SHAKE_DELAY_MS
    g["PRE_DIG_SETTLE_MS"]    = g.get("PRE_DIG_SETTLE_MS", 0) + EASY_FIRST_DIG_DELAY_MS
    g["POST_SHAKE_SETTLE_MS"] = g.get("POST_SHAKE_SETTLE_MS", 0) + EASY_FIRST_DIG_DELAY_MS
    if any((EASY_WATER_BACK_MS, EASY_LAND_FWD_MS, EASY_SHAKE_DELAY_MS,
            EASY_FIRST_DIG_DELAY_MS, EASY_WATER_RETURN_DELAY_MS)):
        print(f"[easy] water_back+{EASY_WATER_BACK_MS} land_fwd+{EASY_LAND_FWD_MS} "
              f"shake_delay+{EASY_SHAKE_DELAY_MS} first_dig+{EASY_FIRST_DIG_DELAY_MS} "
              f"water_return+{EASY_WATER_RETURN_DELAY_MS} -> "
              f"WATER_EXTRA_BACK_MS={g['WATER_EXTRA_BACK_MS']} "
              f"LAND_PROBE_NUDGE_MS={g['LAND_PROBE_NUDGE_MS']} "
              f"SHAKE_START_DELAY_MS={g['SHAKE_START_DELAY_MS']} "
              f"PRE_DIG_SETTLE_MS={g['PRE_DIG_SETTLE_MS']}")
    # pixel coords may arrive as [x, y] lists from the calibrator -> tuples
    for pk in ("CAP_FULL_PIXEL", "DEPOSIT_PIX", "PAN_PIX", "SHAKE_PIX",
               "DIG_TRIGGER_PIXEL", "TERRAIN_PIXEL"):
        if isinstance(g.get(pk), list):
            g[pk] = tuple(g[pk])
    # CAP_START_PIXEL is DERIVED -> recompute after any calibration change
    g["CAP_START_PIXEL"] = (g["CAP_FULL_PIXEL"][0] - g["CAP_BAR_WIDTH"] + 12,
                            g["CAP_FULL_PIXEL"][1])
    print(f"[config] applied {applied} setting(s) from "
          f"{os.path.basename(CONFIG_FILE)}")

# ============================================================================
# CONFIG  --  everything you tune lives here
# ============================================================================

# --- DIG BEHAVIOR TOGGLES ----------------------------------------------------
# MANUAL_DIG: if True, do a FIXED number of digs (DIGS_PER_CYCLE) then empty,
#   instead of digging until the capacity bar reads full. Use when you KNOW how
#   many digs fill the pan (e.g. 1 on this build) -- skips capacity detection.
MANUAL_DIG        = True
DIGS_PER_CYCLE    = 1               # how many digs before emptying (MANUAL_DIG)
# PERFECT: if True, watch the green pixel and release on it. On this build the
#   skill-bar line moves TOO FAST to catch by pixel, so we leave this OFF and use
#   a fixed-length hold (DIG_CLICK_MS) that reliably lands on green instead.
PERFECT           = False
# v2: dig DYNAMICALLY until the capacity bar reads FULL (don't assume 1 dig). This
# is the max digs we'll do to fill before proceeding anyway (safety cap).
MAX_DIGS_TO_FILL  = 8
DIG_CLICK_MS      = 75              # dig hold length -- tuned so the skill bar
                                   # lands on GREEN for this build's dig speed
                                   # (the green pixel is too fast to detect live)
# DIG SPEED: your dig-speed stat (percent). The UI uses it to AUTO-FILL
# DIG_CLICK_MS above (hold = 55000 / DIG_SPEED, i.e. 100% = 550ms, 200% = 275ms).
# Stored for reference; the macro acts on DIG_CLICK_MS, so it's not scaled twice.
DIG_SPEED         = 100            # percent

# Pixel to watch for the white line in "color" mode (= calibrated green pixel).
# The macro releases LMB when this pixel goes WHITE (the line is on it).
DIG_TRIGGER_PIXEL = (1078, 532)     # (x, y)  from calibrate
# "White line present" = all channels bright:
WHITE_MIN         = 175             # r,g,b must all be >= this
# Release earlier/later to fight input lag:
#   If you OVERSHOOT (line passes green before release registers): make the line
#   trigger sooner by moving DIG_TRIGGER_PIXEL a few px toward where the line
#   comes FROM (down the bar), OR leave RELEASE_DELAY_MS at 0.
#   If you UNDERSHOOT (release too early): add a few ms here.
RELEASE_DELAY_MS  = 0
DIG_MAX_MS        = 1500            # per-dig cap: release after this even if green
                                   # was never seen. Long enough for the line to
                                   # reach green on land; also caps how long a dig
                                   # that landed in WATER (no bar) holds before we
                                   # detect the miss and recover.
BETWEEN_DIGS_MS   = 120            # pause between digs when the pan is NOT full
CAP_CHECK_MS      = 30             # tiny settle after a dig before checking full
                                   # (lower = start the walk-back sooner)

# --- CAPACITY BAR: full detection --------------------------------------------
# Pixel near the RIGHT END of the capacity bar: gray when not full, yellow full.
CAP_FULL_PIXEL    = (1120, 900)     # (x, y)  calibrated: yellow=full, gray=empty
# "Yellow" = high red & green, low blue:
YEL_MIN           = 140            # r and g must both be >= this
YEL_BLUE_GAP      = 45             # ...and blue must be <= min(r,g) - this
# Width of the whole bar (left of CAP_FULL_PIXEL) -- used to detect FULLY empty
# so the shake-hold can stop the instant the pan is done, no dead pause.
CAP_BAR_WIDTH     = 440
CAP_EMPTY_FRAC    = 0.04           # yellow fraction below this -> pan is empty
# "Cap STARTED filling" detector: the START (left end) of the bar goes from gray
# to coloured the instant the dig registers. We move as soon as it STARTS (the
# bar is a slider; no need to wait for it to finish). gray = flat (low spread),
# filled = coloured (high spread).
CAP_START_PIXEL   = (CAP_FULL_PIXEL[0] - CAP_BAR_WIDTH + 12, CAP_FULL_PIXEL[1])
CAP_START_DELTA   = 22            # start pixel must change by > this vs its empty
                                  # colour (captured pre-dig) to count as started
# How long to wait after a dig for the cap bar to start filling (so we move at
# the right moment). Proceeds anyway after this.
CAP_START_MS      = 250

# --- DRIFT FIX: "Collect Deposit" cue anchors the forward leg ----------------
# Instead of riding W back for a time-matched duration (which drifts), ride W
# until the "Collect Deposit" prompt appears = you've reached the land edge.
# Re-anchors to the same spot every cycle. Needs the cue pixel calibrated.
DEPOSIT_ANCHOR    = True
DEPOSIT_PIX       = (770, 981)    # white when "Collect Deposit" shows (on land)
PAN_PIX           = (847, 981)    # white when "Pan" shows (in the water)
SHAKE_PIX         = (830, 981)    # white when "Shake" shows (shake initiated)
CUE_WHITE_MIN     = 160           # a pixel is "cue text" if all channels >= this
CUE_WHITE_SPREAD  = 70            # ...and max-min spread <= this (whitish)
CUE_WHITE_FRAC    = 0.12          # cue present if >= this FRACTION of the box is
                                  # white text (counts pixels, doesn't average)
# ADVANCED CUE MATCHING (opt-in): instead of "is this small box mostly white",
# match the EXACT white-pixel shape of the cue word (Pan / Shake / Collect
# Deposit) captured in Advanced Calibration. A random white player cannot
# reproduce the precise letter shape, so it is spoof-proof. Falls back to the
# box check above for any cue without a mask, and whenever the window is resized
# (a fixed mask would misalign -> raises a recalibration warning).
ADVANCED_CUES     = False
CUE_MASK_FRAC     = 0.85          # cue present if >= this fraction of the mask's
                                  # captured pixels read white right now
CUE_MASKS         = {}            # cue -> {ratio:[l,t,w,h], w, h, bits(b64)}
CUE_MASK_BOXES    = {}            # runtime: cue -> live screen box (placed at start)
CUE_MASKS_ONLY    = False         # test mode: use ONLY captured masks, no box fallback
DEPOSIT_MAX_MS    = 1200          # safety cap riding W to find the land cue
SHAKE_INIT_MS     = 280           # window to confirm the "Shake" cue after the
                                  # start-click; if it never shows (and you read
                                  # Collect Deposit + full) the shake failed
PAN_BACK_MAX_MS   = 200           # safety cap walking S back (also = the back
                                  # distance if the Pan cue never fires)

# --- TERRAIN DETECTION (drives S/W by what's under your feet) -----------------
# When True: hold S until you're in the liquid, hold W until back on dirt.
# Self-correcting, no fixed times. When False: use the fixed ms below.
USE_TERRAIN_DETECT = False
# A ground pixel near your feet that reads DIRT on land and the LIQUID in water.
TERRAIN_PIXEL     = (900, 720)      # (x, y)  calibrated
# Reference colours from calibrate. Each terrain can hold ONE colour OR a LIST
# of colours -- add more samples to cover two-tone / gradient ground (e.g. light
# and dark beige, bright and dark lava). Classification picks the nearest match.
DIRT_RGB          = [(120, 195, 70), (150, 210, 95)]    # GREEN land (estimate)
WET_RGB           = [(70, 195, 200), (95, 205, 205)]    # BLUE water (estimate)
# Robustness to the floor tint pulses (green/yellow/white flashes):
#   classification uses colour PROPORTION (chromaticity), so brightness/white
#   pulses are ignored; a pulse that changes hue is filtered by these:
TERRAIN_CONFIRM   = 3     # consecutive agreeing reads required before acting
WALK_BACK_CONFIRM = 1     # reads to confirm WATER on the walk-back (1 = instant)
WALK_BACK_MIN_MS  = 0     # ignore terrain reads for the first N ms of the S move
MOMENTUM_MIN_MS   = 30    # ignore terrain reads for the first N ms of the W move
WALK_BACK_MAX_MS  = 600   # safety cap on the S move (used in detect mode)
MOMENTUM_MAX_MS   = 600   # safety cap on the W move (used in detect mode)
RECOVER_MAX_MS    = 1500  # safety cap when walking back to dirt after drifting

# --- HUD TEXT LAYER (slow but authoritative -- corrects the colour check) -----
# The prompt under the capacity bar reads "Collect Deposit" on dirt, "Pan" in
# the liquid, "Shake" during the shake. We don't OCR it; we measure how much
# white text is present ("Collect Deposit" >> "Shake" > "Pan"). It updates
# slowly, so it ONLY overrides the fast colour terrain check when the two
# clearly disagree (catches dr/ift and "stuck" errors).
USE_TEXT_LAYER  = True
# Region of the prompt text (left, top, width, height). Size it to fit the
# WIDEST prompt, "Collect Deposit". Calibrate with `calibrate-text`.
TEXT_REGION     = (840, 980, 360, 60)
TEXT_WHITE_MIN  = 180     # brightness for a pixel to count as text
# White-pixel fraction bands -- run `calibrate-text`, read the 3 values, set:
TEXT_PAN_MAX    = 0.024   # frac <= this        -> "Pan"   (in liquid)  [meas 0.021]
TEXT_SHAKE_MAX  = 0.040   # this < frac <= ...  -> "Shake" [meas 0.027]; above -> Deposit [0.052]

# --- EMPTY SEQUENCE fixed timings (used only if USE_TERRAIN_DETECT = False) ---
# DRIFT FIX: anchor the walk-back to the lava. Instead of holding S for a fixed
# time (which drifts), hold S until you actually touch the lava (re-anchors to
# the edge every cycle). Forward stays timed, so the dig spot stays put.
# Needs TERRAIN_PIXEL/WET_RGB to read the lava when you back in (verify in
# calibrate). Falls back to the fixed WALK_BACK_MS if set False.
ANCHOR_WALKBACK   = True
# OVERSHOOT FIX: the game shows the "Pan" prompt a beat AFTER you cross into the
# water, and the character keeps gliding back after S is released -- so by the
# time the cue fires you've drifted deep. The moment Pan is detected we tap W
# forward this many ms to cancel the backward glide and stop at the water edge.
# Raise if it still goes too far back; lower (or 0) if the brake pushes you onto
# land before the shake.
WALK_BACK_BRAKE_MS = 70
# After the Pan cue fires, KEEP holding S this long to walk a little FARTHER into
# the water before shaking. The cue can trigger right at the edge; shaking there
# sometimes misses, so going a touch deeper makes the shake land reliably. This
# is the "delay between Pan detected and shake start". Raise to go deeper.
# (0 = disabled -- this delay was found to break the timing, so it's off.)
WATER_EXTRA_BACK_MS = 0
# Pause between releasing S and the first shake click. (0 = disabled.)
SHAKE_START_DELAY_MS = 0
SHAKE_W_LEAD_MS      = 0  # momentum pre-roll: walk forward this long
                          # BEFORE the first shake click (0 = off); cuts
                          # to clicks early when the water edge shows
WALK_BACK_MS      = 95     # hold S to back into the water (fallback / if anchor off)
WALK_BACK_EXTRA_MS = 0     # keep holding S this long AFTER touching water (go a
                          # bit deeper); the forward move adds the same so you
                          # still return to the dig spot
MOMENTUM_W_MS     = 95     # (no longer drives forward distance -- W now matches
                          #  the measured S time; kept for reference)
# Forward W is held for EXACTLY the measured S time + this trim (ms). NEGATIVE
# = less forward (if you overshoot PAST the start); POSITIVE = more forward (if
# you land SHORT, e.g. the shake animation ate movement).
SHAKE_FWD_COMP_MS = 0
# --- SHAKE: momentum technique with rapid CLICKS (no held press) -------------
# Your build empties so fast you don't need to HOLD -- just rattle off clicks.
# And we start holding W the moment the shake begins so momentum carries you
# back ONTO THE LAND while the pan drains (the "special technique"). We stop
# walking W when the Collect Deposit cue shows (we're on land) but keep clicking
# until the CAPACITY reads empty (capacity is the truth; the Shake cue sticks).
SHAKE_MOMENTUM_W   = True   # hold W during the shake -> glide onto land
SHAKE_CLICK_MS     = 18     # length of each shake click (short, fast build)
SHAKE_CLICKS       = 0      # EXACT number of shake clicks (0 = auto: shake until
                            # the pan reads empty). Set a fixed count to stop the
                            # shake cleanly so no extra click bleeds into the dig.
SHAKE_CLICK_GAP_MS = 14     # gap between shake clicks
SHAKE_HOLD_MS      = 1500   # overall shake timeout (stops early when empty)
SHAKE_INIT_GAP_MS    = 10   # (legacy) unused now
SHAKE_PLAIN_HOLD     = False # (legacy) unused now
SHAKE_PRESS_DELAY_MS = 25   # (legacy) unused now
SHAKE_HOLD_DELAY_MS  = 30   # (legacy) unused now
SHAKE_MOMENTUM_MS    = 120  # (legacy) unused now
SHAKE_START_MS    = 70    # (unused in timed path; kept for the detect path)
GAP_MS            = 25    # tiny settle gap between phases
POST_DIG_MS       = 60    # slight settle after a dig, before walking back
AFTER_EMPTY_MS    = 120   # settle after emptying, before digging again
RETRY_GAP_MS      = 25    # gap before RE-trying an empty when the pan stayed full

# --- ERROR HANDLING (capacity is the ground truth) ---------------------------
EMPTY_RETRIES     = 3     # re-attempt the empty (backing up further) if the pan
                         # didn't actually empty (e.g. didn't reach the water)
RETRY_BACK_MS     = 120   # extra S walk-back per retry to reach the water
STUCK_LIMIT       = 4     # consecutive failed empties -> STOP and alert
ALERT_SOUND       = "/System/Library/Sounds/Sosumi.aiff"

# --- ROBUST SUPERVISOR (fused cue + capacity state machine) ------------------
# The control core re-senses every tick and CROSS-CHECKS two independent layers
# before trusting anything:
#     WHERE am I   -> the HUD prompt cue  (Collect Deposit / Pan / Shake)
#     WHAT's in it -> the capacity bar    (full / empty / partial)
# Capacity is the ground truth for "did it empty" (the Shake cue can stick), the
# cue is the ground truth for "where am I". Every action verifies its own result
# on the next tick; a deadlock (same situation N ticks) escalates through
# recovery nudges, and only then a SAFE STOP. This self-heals from ANY start
# state and from missed clicks, under/overshoots, stuck cues and drift.
SENSE_VOTES        = 1    # sensor reads fused per decision (>1 votes out flicker)
MOVE_CONFIRM_MS    = 140  # after a move, wait this long for the target cue to settle
DIG_FILL_MS        = 250  # after a dig, wait up to this for the bar to read FULL
# SMART FILL WAIT (opt-in, default OFF): the game's fill bar ANIMATES up after a
# dig, often longer than DIG_FILL_MS -- the plain wait times out mid-animation
# and re-digs even though the pan was about to read FULL (wasted animations =
# dead time). Smart wait watches the bar's MOTION instead: still RISING -> keep
# waiting (up to DIG_SMART_CAP_MS); PLATEAUED below full for DIG_PLATEAU_MS ->
# this dig genuinely wasn't enough, dig again NOW. Optimal for 1-dig AND
# multi-dig builds: no premature re-digs, no over-waiting between real digs.
DIG_FILL_SMART     = False
DIG_PLATEAU_MS     = 120  # bar unchanged this long (below full) = plateaued
DIG_SMART_CAP_MS   = 900  # hard cap on one smart wait (safety)
# DIG PIPELINE (opt-in, default OFF): between digs the old flow waited for the
# bar's fill ANIMATION to settle before firing the next dig -- pure dead time
# (~300ms per extra dig). The pipeline learns how many digs one fill takes
# (median of the last completed fills), then fires the follow-up digs on your
# dig-animation rhythm and smart-waits ONLY after the last one. Comes up
# short (lag, missed dig)? The normal loop tops it up and the count relearns.
DIG_PIPELINE       = False
DIG_PIPELINE_GAP_MS = 0   # rhythm between digs; 0 = auto (190000/DIG_SPEED+25)
# TRACKER MODE (default OFF): watch-only benchmarking. Sends ZERO input --
# it reads the capacity bar exactly like the macro does and counts the
# GAME'S OWN auto-pan: rises = digs (approximate: distinct rise bursts),
# high-bar -> empty = one pan. Stats stream + History work as normal, with
# runs labelled TRACKER, so the built-in auto-pan and the macro compare on
# the same ruler. Relics and all recovery are disabled while tracking.
TRACKER_MODE       = False
TRACKER_POLL_MS    = 30   # bar sampling rhythm while tracking
# TRACKER + RELICS: keep relic timers running while the GAME's Auto Pan does
# the panning. Each relic use does the safe dance: click the calibrated Auto
# Pan button OFF (colour-verified), use the relic, return to the pan slot,
# click Auto Pan back ON (colour-verified). Calibrate the button's position
# and BOTH state colours in the Calibrate tab.
TRACKER_RELICS     = False
AUTOPAN_BTN_PIXEL  = [0, 0]       # the Auto Pan button (calibrate)
AUTOPAN_ON_RGB     = [0, 0, 0]    # button colour when ON (calibrate)
AUTOPAN_OFF_RGB    = [0, 0, 0]    # button colour when OFF (calibrate)
AUTOPAN_TOL        = 40           # per-channel colour tolerance
AUTOPAN_SETTLE_MS  = 400          # wait after clicking the button
# AUTO PAN GUARD (opt-in): while tracking, periodically re-read the button;
# if it reads OFF on TWO consecutive checks (an instant misread can't trip
# it), click it back ON -- an accidental toggle can no longer silently kill
# a whole tracking session.
AUTOPAN_GUARD      = False
AUTOPAN_GUARD_SEC  = 5            # how often the guard re-reads the button
AUTOPAN_SHIFTLOCK  = False        # you play shift-locked: tap Shift to free
                                  # the cursor before clicking the button,
                                  # then tap Shift again to re-lock
AUTOPAN_FAST_RELOCK = False       # re-lock IMMEDIATELY after the click (the
                                  # lock snaps the cursor to centre anyway);
                                  # off = park at centre first, then re-lock
# AUTO PAN HEALTH KICK (opt-in, 0 = off): sometimes Auto Pan shows GREEN but
# has silently wedged -- nothing digs or pans. If the capacity bar shows NO
# activity (no rise, no drain) for AUTOPAN_STALL_SEC while the button reads
# ON, toggle it OFF and back ON to kick it awake.
AUTOPAN_STALL_SEC  = 0
AUTOPAN_RELOCK_DELAY_MS = 0   # custom gap between the button click and the
                              # shift re-lock tap (fast-relock path)
# EARNINGS TRACKER (opt-in, default OFF): OCR the on-screen money and shard
# totals (bottom-right HUD) every EARN_OCR_SEC using macOS Vision, credit the
# POSITIVE deltas to the run (sum-of-gains, so mid-run spending can't corrupt
# it), and report $ / shards per hour and per pan in stats + History. A value
# is accepted only after two consecutive identical reads (misreads can't
# inject garbage). Works in macro AND Tracker mode -> real build comparisons.
EARN_TRACK         = False
EARN_OCR_SEC       = 10
# FINDS TRACKER (opt-in): watch the bottom-right item pop-up stack ("Iridescent
# Dinosaur Skull  347 kg" / "Exotic"), log every find (modifier / name / weight
# / rarity), and estimate the value of KEPT items via prospecting_prices.json x
# SELL_BOOST_PCT -- auto-sold money is already measured by the money OCR; kept
# loot is what needs estimating. v2 is a FADE-DIRECTION tracker: a fast pixel
# sampler (FINDS_FAST_MS) sees how many cards are up and how solid each one is
# (cards fade IN as they arrive, OUT as they age), so arrivals are counted at
# sample speed even when several skulls land in one pan; a slower Vision OCR
# pass (FINDS_OCR_MS) attaches each card's identity. See FindsWatcher.
FINDS_TRACK        = False
FINDS_FAST_MS      = 40        # fast presence/opacity sample cadence (ms)
FINDS_OCR_MS       = 200       # min gap between identity OCR passes (ms)
FINDS_STACK_NEWEST = "bottom"  # where a new find card appears (bottom | top)
FINDS_MIN_CONF     = 0.30      # min OCR confidence for the OCR safety net to
                               # start a find on its own (fade/ghost guard)
FINDS_MIN_DWELL    = 3         # fast samples a band must live before it can
                               # count (animation flicker can't mint a find)
FINDS_EMPTY_CLEAR  = 3         # empty OCR passes before the safety net clears
FINDS_EMPTY_MS     = 700       # quiet ms (no bands) before the stack resets
FINDS_CARD_SEC     = 5         # how long one card stays on screen (s, incl.
                               # animations) -- re-sighting dedupe window
FINDS_WHITE_MIN    = 170       # text pixel: every RGB channel at least this
FINDS_DARK_MAX     = 105       # card-backing pixel: every channel at most this
FINDS_BAND_MIN     = 0.008     # min text-pixel row fraction to call a band
FINDS_DEBUG        = False     # verbose tracker diagnostics in the trace
SELL_BOOST_PCT     = 100    # your sell boost, in percent (100 = 1.0x)
FINDS_BANK_RARITY  = "Exotic"  # only value finds at/above this rarity as KEPT
                               # loot -- lower-rarity finds auto-sell and are
                               # already in the money counter (no double-count)
FIND_TL_PIXEL      = [0, 0] # find pop-up region corners (calibrate)
FIND_BR_PIXEL      = [0, 0]
MONEY_TL_PIXEL     = [0, 0]   # region corners; calibrate in the Calibrate tab
MONEY_BR_PIXEL     = [0, 0]
SHARDS_TL_PIXEL    = [0, 0]
SHARDS_BR_PIXEL    = [0, 0]
# LAND-CUE ASSIST (opt-in, default OFF): after a shake the dig-probe used to
# start from a momentum GUESS and nudge forward blindly when digs didn't
# register -- the single biggest telemetry cost (397 nudges / 40 runs). With
# the assist, if the 'Collect Deposit' cue isn't showing yet, hold W briefly
# until it confirms, THEN probe. The cue is used for POSITIONING only; the
# dig-probe (capacity bar) still verifies we're really on dirt.
LAND_CUE_ASSIST    = False
LAND_ASSIST_MAX_MS = 400  # W budget while waiting for the Deposit cue
MAX_DIGS_PER_VISIT = 4    # dig at most this many times to fill before giving up
LAND_SETTLE_MS     = 45   # after the land cue fires, hold W a touch longer to land
                          # FIRMLY on the dirt (prevents a land<->water flicker).
                          # Forward over-travel onto land is harmless; braking
                          # BACK toward the water is what caused the oscillation.
SHAKE_POLL_MS      = 30   # poll spacing while holding the shake
STUCK_TICKS        = 3    # identical (place, pan) reads in a row -> escalate
RECOVER_LIMIT      = 3    # recovery attempts on a deadlock before SAFE STOP
SHAKE_FAIL_LIMIT   = 5    # shakes that didn't empty (even if you keep MOVING
                          # between water/land) before SAFE STOP -- catches the
                          # case where the shake silently never works
SHAKE_GLITCH_LIMIT = 2    # after THIS many failed shakes, immediately try a quick
                          # click-to-empty break-out (the game's shake-glitch often
                          # just didn't register; clicking is low-risk and usually
                          # fixes it). Much faster than waiting for SHAKE_FAIL_LIMIT.
NO_PROGRESS_SEC    = 5    # if NOTHING works for this long (no pan emptied AND no dig
                          # registering -- e.g. the shake-glitch leaves us walking
                          # back and forth) -> quick click-to-empty break-out.
# Shake bail is CAPACITY-based: give up on a shake only if the pan is STILL
# COMPLETELY FULL after this long. A REAL shake has already drained to PARTIAL by
# now (so it reads not-full and is safe from this bail) -- only a shake that never
# started stays full. So this can be fairly short to react FAST when a shake fails
# to initiate (e.g. you clicked on land), without killing a real in-progress shake.
SHAKE_BAIL_MS      = 500
# SHAKE-START CONFIRM (opt-in, 0 = OFF): a faster, gentler layer UNDER the bail.
# If the pan is STILL COMPLETELY FULL this long after the clicks began, the shake
# never initiated (edge click / game glitch). Instead of waiting out the full bail
# window and losing the cycle, tap S a touch DEEPER and keep clicking, up to
# SHAKE_START_RETRIES times. Each retry pushes the bail window back so the retry
# gets a fair chance. Emits a 'shake_start_retry' telemetry event.
SHAKE_START_CONFIRM_MS = 0    # 0 = disabled (default; opt-in feature)
SHAKE_START_RETRIES    = 2    # deeper-tap retries per shake
SHAKE_RETRY_DEEPER_MS  = 70   # the S tap length (W is dropped around the tap)
# DRAIN-STALL (opt-in, 0 = OFF): a started shake whose bar STOPS draining
# mid-way means the game dropped it -- the old behavior clicked out the whole
# SHAKE_HOLD_MS timeout before noticing (the 'ran but didn't empty' fails).
# With this on, a frozen bar for SHAKE_STALL_MS ends the attempt immediately
# so the normal retry/recovery machinery gets it seconds sooner.
SHAKE_STALL_MS         = 0    # bar frozen this long (while started) = stall
# SMART BREAK-OUT: when the watchdog has recovered RECOVER_LIMIT times in a row and
# we're still stuck, escalate -- a shake is probably ACTIVE and locking movement
# (you can't walk mid-shake, but CLICKS still finish it). So click to finish it,
# then reposition, then let normal logic resume. Only SAFE STOP if break-out also
# fails BREAKOUT_LIMIT times.
BREAKOUT_LIMIT     = 2    # break-outs before SAFE STOP
BREAKOUT_SHAKE_MS  = 700  # when stuck + FULL, click this long to finish an active
                          # shake that's locking movement
BREAKOUT_REPOS_MS  = 160  # forward W reposition nudge during a break-out (gets you
                          # off the water edge if you keep landing too shallow)
# Each recovery SYSTEM can be turned off independently (in case one misbehaves or
# a player just doesn't want it). With all off, the macro only does the normal
# loop and still safe-stops via the per-situation guards if it truly can't progress.
RECOVER_ENABLED     = True   # the stuck-recovery jitter step
SHAKE_RETRY_ENABLED = True   # re-attempt a shake when stuck full+in-water
BREAKOUT_ENABLED    = True   # the last-resort break-out to escape a stuck loop
NO_FULL_LIMIT       = 12     # if the pan never reads FULL this many cycles in a row,
                             # stop and tell the user to re-calibrate the capacity pixel

# --- Treasure Chest Collection mode ------------------------------------------
# A separate, simple loop: NO shake. Dig briefly, then strafe sideways (right,
# then left, alternating) until the Collect/Deposit cue shows again, then dig.
TREASURE_MODE        = False
TREASURE_DIGS        = 1     # how many digs per chest before strafing on
TREASURE_DIG_MS      = 8     # quick dig click length (5-10 ms)
TREASURE_DIG_GAP_MS  = 12000 # delay between each dig click (slow chest dig animation)
TREASURE_MOVE_MAX_MS = 2500  # safety cap on the strafe before moving on
# SHARDS MODE (opt-in, SHARDS_DIG_CLICKS > 0): exact-click digging for builds
# where a known number of clicks fills the pan (shards farm: ONE). No probe
# re-digs, no bar-race double clicks: the FIRST click must prove it landed
# (the bar's left tip leaves gray = the fill STARTED) within
# SHARDS_CLICK_CONFIRM_MS; only a provably-dead click is retried. With
# SHARDS_ASSUME_FULL on, fill started = fill guaranteed: move on immediately
# and spend the animation time already walking back to the water.
SHARDS_DIG_CLICKS      = 0    # exact dig clicks per land visit (0 = off)
SHARDS_CLICK_CONFIRM_MS = 100 # bar must leave EMPTY within this after click 1
SHARDS_CLICK_RETRIES   = 3    # total clicks allowed while the bar never moves
SHARDS_ASSUME_FULL     = False # bar moved -> treat as full NOW, walk during
                               # the fill animation (one-click-fill builds)
SHARDS_GREEN_CONFIRM   = False # the dig skill-bar's green zone appearing also
                               # proves the click (frames earlier than the
                               # capacity bar, which can lag whole animations);
                               # needs the Perfect-dig green pixel calibrated
# --- GEODE MODE (opt-in, GEODE_MODE=True) ------------------------------------
# Fast-tap dig on a build with a VERY slow fill animation (e.g. 10% dig-speed
# geode shovels). The capacity bar lags the dig by a long beat, so the normal
# probe would time out and false-nudge ("dig failed") while the fill is merely
# still animating. Geode dig taps the dig GEODE_DIGS_TO_FILL times with a long
# per-dig wait (GEODE_DELAY_MS) that ENDS EARLY the instant the bar moves, and
# nudges ONLY when the FIRST dig of a land round shows no movement at all after
# that whole wait. Then it hands back to the NORMAL cycle -> walk to water +
# momentum shake (NOT treasure's L/R strafe).
GEODE_MODE           = False
GEODE_DIGS_TO_FILL   = 1     # dig taps to fill the pan
GEODE_DIG_MS         = 5     # quick dig hold (5-10 ms, like shards/treasure)
GEODE_DELAY_MS       = 1500  # max wait per dig for the slow fill animation --
                             # ends early if the bar moves (this is the anti-nudge)
GEODE_CONFIRM_FULL   = False # also wait for the bar to actually read FULL before
                             # shaking (off = trust the dig count and move on)
GEODE_START_MS       = 800   # after a click, how long to wait for the dig to
                             # actually START (green dig-bar shows / bar moves)
                             # before re-clicking -- the timer only runs once a
                             # dig is confirmed running
GEODE_START_TRIES    = 3     # re-click this many times if a dig won't start
GEODE_SHAKE_CHECK    = 3     # geode shake: rattle this many clicks between
                             # screen reads (>1 = smoother/faster + drains fuller)
GEODE_SHAKE_HOLD_MS  = 8000  # the geode shovel slows the SHAKE too, so keep
                             # shaking up to this long (until the pan empties);
                             # 0 = use the normal SHAKE_HOLD_MS. In geode mode the
                             # "still completely full -> bail" early-out is also
                             # suppressed so a slow shake is never cut off.
# Post-shake landing by DIG-PROBE (not by cue). After a shake the "Shake" cue can
# STICK and never flip to "Collect Deposit", so we don't wait for that cue. We
# trust the W-momentum carried us toward land and just DIG: a dig only fills on
# dirt, so the CAPACITY bar tells us if we're on land. Hit -> on land (pan now
# filling). Miss -> nudge forward and retry.
LAND_DIG_TRIES      = 5   # nudge-forward ROUNDS while searching for land
# Per round, re-dig IN PLACE this many times before deciding we're off-land and
# nudging W. A dig that simply didn't register (timing) is NOT the same as being
# in the water, so we don't walk away on the first miss -- this stops the jittery
# "nudge between digs" on multi-dig builds.
DIG_INPLACE_TRIES   = 3
# A dig "registered" (we're on land) if the capacity bar's FILL LEVEL RISES by at
# least this fraction. This works even when the pan was already PARTIAL (the old
# start-pixel check missed that, so it false-nudged W after the first dig).
CAP_RISE_FRAC       = 0.03
DIG_PROBE_MS        = 320 # wait this long for a probe-dig to register before
                          # calling it a MISS (a working dig sometimes fills the
                          # bar slowly -- too short and we nudge again too soon)
LAND_PROBE_NUDGE_MS = 90  # forward W nudge between failed probe-digs
PROBE_GAP_MS        = 80  # settle after a forward nudge, before the next dig
                          # (stops it clicking W twice in a row too fast)
PRE_DIG_SETTLE_MS   = 60  # VERY slight settle before the FIRST dig after a shake,
                          # so the dig doesn't fire slightly early (miss -> needless
                          # recovery nudge). Small; raise a touch if it still misses.
POST_SHAKE_SETTLE_MS = 150 # pause after the pan empties (let the shake animation
                          # + momentum settle you onto land) BEFORE the dig-probe.
                          # Without it the first dig often fires mid-glide and
                          # misses, needing an extra forward nudge. Tune up/down.
RECOVER_BACK_MS    = 160  # corrective nudge BUDGET during recovery (pulsed)
LIMBO_NUDGE_MS     = 200  # forward (toward land) probe BUDGET when NO cue (pulsed)
# Pulsed movement: forward/recovery moves are short taps with a cue check after
# EACH tap, so they stop the instant the target shows (no long blind holds).
BURST_ON_MS        = 11   # hold the key this long per tap...
BURST_OFF_MS       = 1    # ...release this long, then re-check the cue
# Live terminal log: print every decision + sub-step with timing so you can SEE
# what the macro is thinking (where it is, what it plans, how long each step
# took). Set False for a quiet run.
LOG_LIVE           = True

# --- RELICS (timed item use: solar mags, idols, etc.) ------------------------
# Every relic's "minutes" the macro PAUSES, switches to its hotbar slot, double-
# clicks (uses it), switches back to RELIC_RETURN_SLOT (the pan), and resumes.
# Add/remove/edit entries (the UI has a Relics tab). RELICS_ENABLED master toggle.
RELICS_ENABLED     = False        # off by default (turn on in the UI / config)
RELICS = [
    {"name": "Solar Magnifier", "minutes": 10, "slot": 5, "clicks": 2},
    {"name": "Infernal Idol",   "minutes": 10, "slot": 6, "clicks": 2},
]
RELIC_RETURN_SLOT  = 1     # hotbar slot to return to after using a relic (pan)
RELIC_SWITCH_MS    = 160   # wait after pressing a slot key before clicking
RELIC_CLICK_MS     = 20    # each relic click length
RELIC_CLICK_GAP_MS = 90    # gap between the relic clicks
RELIC_PRE_MS       = 120   # settle after releasing movement, before switching slot

# --- DISCORD WEBHOOK / NOTIFICATIONS -----------------------------------------
# Posts to WEBHOOK_URL on events (start, safe-stop, bag full, periodic stats).
# When WEBHOOK_URL is empty it falls back to SYNC_URL, the webhook every
# shipped build carries in its config, so notifications work out of the box.
# Renders on a plain Discord webhook as content + an embed (user/event/stats
# as embed fields, since Discord drops unknown JSON keys) AND still carries
# the raw "event"/"user"/"stats" fields for a custom relay bot.
WEBHOOK_ENABLED    = False
WEBHOOK_URL        = ""  # set in config only; no secret is ever baked into source
SYNC_URL           = ""  # injected into shipped configs; fallback delivery URL
WEBHOOK_SECRET     = ""  # set in config only; no secret is ever baked into source
WEBHOOK_USER       = ""     # a name/id your bot uses to know who to DM
WEBHOOK_STATS_MIN  = 60     # also send a stats update every N minutes (0 = off)
# Per-event notification toggles (which DMs you actually get). Recoveries are
# OFF by default because they can fire often; the rest are on.
NOTIFY_START       = True
NOTIFY_STOP        = True   # manual stop, auto-stop timer, bag-full
NOTIFY_STATS       = True
NOTIFY_SAFE_STOP   = True
NOTIFY_RECOVERIES  = False
NOTIFY_ERRORS      = True
NOTIFY_SCREENSHOT  = True   # attach a screenshot to safe-stop / recover / hard-stop / stats DMs
SHOT_TARGET_W      = 1280   # downscale screenshots to about this width before sending

# --- AUTO-STOP TIMER ---------------------------------------------------------
AUTOSTOP_ENABLED   = False
AUTOSTOP_MINUTES   = 60     # stop the macro after this many minutes of running
# Bag-full guard: stop after this many pans (0 = off). A simple proxy for a full
# inventory until proper count/colour reading is calibrated.
STOP_AFTER_PANS    = 0

# --- SAFE-STOP behaviour -----------------------------------------------------
# On a hazard/stuck, PAUSE and retry instead of hard-stopping, so an AFK run can
# heal itself. Hard-stop only after this many failed retries in a row.
SAFE_STOP_RETRY       = True
SAFE_STOP_RETRY_SEC   = 60
SAFE_STOP_MAX_RETRIES = 3

# --- Smart / experimental ----------------------------------------------------
# SMART_TIMING: trial-and-error auto-tuning. If shakes miss the water (or landing
# needs nudges) more than ADAPT_MISS_PCT of the time over a window, it nudges the
# relevant timing and KEEPS the change only if the miss rate drops next window.
SMART_TIMING       = False
ADAPT_WINDOW       = 12     # attempts per evaluation window
ADAPT_MISS_PCT     = 20     # only adjust above this miss %
ADAPT_STEP_MS      = 25     # how far to nudge a timing each step
# X_PATTERN: walk BACK on alternating 45-degree diagonals (S+A, then S+D, ...)
# instead of straight S, so each pass covers new ground -- helps when you keep
# falling short of the water on a straight line. Forward (to land) stays straight.
X_PATTERN          = False
X_STRAFE_MS        = 220   # X: hold the diagonal only THIS long each pass, then
                           #    finish STRAIGHT back (keeps depth + landing consistent
                           #    and drift small). 0 = old full-length diagonal.
X_RECENTER_MS      = 400   # X: once sideways drift exceeds this budget, strafe
                           #    straight back toward centre first. 0 = never recenter.

# --- Easy tuning (plain-language offsets; 0 = no change). The backend maps each
#     of these onto the real timing knobs in load_config(), so users can tune by
#     intent without learning every setting.
EASY_WATER_BACK_MS         = 0   # go this many ms FURTHER BACK into the water
EASY_LAND_FWD_MS           = 0   # go this many ms FURTHER FORWARD onto land
EASY_SHAKE_DELAY_MS        = 0   # wait this many ms longer before the shake starts
EASY_FIRST_DIG_DELAY_MS    = 0   # wait this many ms longer before the first dig
EASY_WATER_RETURN_DELAY_MS = 0   # wait this many ms before heading back to water

# --- WINDOW-RELATIVE CAPTURE (opt-in) ----------------------------------------
# When on, pixels are shifted by how far the Roblox window moved since you
# calibrated, so calibration survives the window being in a different spot.
# Default OFF = identical absolute-coordinate behaviour.
WINDOW_RELATIVE     = False
ROBLOX_TITLE        = "Roblox"
CALIB_WINDOW_ORIGIN = [0, 0]   # window top-left captured at calibration time
CALIB_WINDOW_RECT   = [0, 0, 0, 0]   # [x,y,w,h] of the game window at calibration
# Auto-calibrate from the live Roblox window at start using the ratio profile
# (each pixel as a fraction of the game window). ON by default: if PIXEL_RATIOS
# is present and Roblox is found, the macro positions every pixel itself, so the
# calibration travels across machines/resolutions and survives window moves.
AUTO_CALIBRATE      = True
PIXEL_RATIOS        = {}

# --- Detection sampling ------------------------------------------------------
SAMPLE_BOX        = 6     # NxN px box averaged around a watched pixel

# --- Fortune River recovery (Smart): on a SOFT stop, fast-travel back to
#     Fortune River, walk into the water, and resume. Pixels/colour below are
#     set in the app's Calibrate tab. -----------------------------------------
FR_RECOVERY        = False        # master toggle
FR_OPEN_SLOT       = 4            # hotbar slot that equips the fast-travel item
FR_PAN_SLOT        = 1            # hotbar slot for the pan (return to it after)
FR_OPEN_PIXEL      = [0, 0]       # optional click to open Fast Travel (0,0 = skip)
FR_HOME_PIXEL      = [0, 0]       # cursor rest position (screen centre) with shift-lock OFF
FR_MOVE_STEP       = 8            # max px per incremental relative mouse move
FR_DOUBLE_GAP_MS   = 120          # gap between the two mouse clicks (double-click to open)
FR_CLICK_SETTLE_MS = 300          # pause after a cursor move, before/after a click (ms)
FR_ACTION_GAP_MS   = 500          # pause between each step of the sequence (ms)
FR_OPEN_MS         = 600          # wait for the menu to appear (ms)
FR_TEXT_RGB        = [232, 120, 200]  # Fortune River row colour (pink, calibrate)
FR_TEXT_TOL        = 55           # colour match tolerance (per channel)
# STARFALL RIVER recovery: same Fast-Travel machinery + shared menu geometry
# (FR_SCAN_X / FR_BOX_* / home pixel); only the row colour and the post-warp
# walk differ (Starfall: hold A a beat, then S back until the Pan cue).
SR_RECOVERY        = False        # fast-travel to Starfall River on soft stop
SR_TEXT_RGB        = [0, 0, 0]    # Starfall row colour (calibrate)
SR_TEXT_TOL        = 55           # colour match tolerance (per channel)
SR_A_MAX_MS        = 6000         # cap on the TIMED A strafe to find the water
SR_D_PCT           = 50           # back off D for this %% of the timed A
SR_S_MAX_MS        = 4000         # max S walk back to the Pan cue
FR_SCAN_X          = 0            # x column to scan for the pink text
FR_BOX_TOP         = 0            # y of the top of the list box
FR_BOX_BOTTOM      = 0            # y of the bottom of the list box
FR_SCAN_STEP       = 3            # vertical scan step (px)
FR_SCAN_HOVER_MS   = 12           # dwell at each step as the cursor sweeps (ms)
FR_FIND_TRIES      = 8            # scroll passes before giving up
FR_OPEN_TRIES      = 3            # times to re-open the warp device if nothing is found
FR_SCROLL_STEPS    = 3            # wheel notches per scroll-down
FR_SCROLL_WAIT_MS  = 250          # settle after each scroll (ms)
FR_WARP_MS         = 2500         # wait after clicking for the teleport/load (ms)
FR_STRAFE_MS       = 10           # tiny D strafe after returning to the pan (ms)
FR_WALK_MAX_MS     = 6000         # max W walk to reach the water/dig spot (ms)
FR_END_A_MS        = 300          # hold A this long once on land, before restarting
FR_CROSS_CONFIRM   = 3            # consecutive cue reads to confirm water-cross / arrival

# --- Keys (WINDOWS hardware SCANCODES -- used with SendInput SCANCODE flag, the
#     most reliable way to drive Roblox on Windows). --------------------------
KEY_W = 0x11            # W
KEY_S = 0x1F            # S
KEY_A = 0x1E            # A
KEY_D = 0x20            # D
KEY_SHIFT = 0x2A        # left Shift (open Fast Travel)
# Hotbar slot number -> Windows scancode (digit row 1..0).
SLOT_KEYCODES = {1: 0x02, 2: 0x03, 3: 0x04, 4: 0x05, 5: 0x06,
                 6: 0x07, 7: 0x08, 8: 0x09, 9: 0x0A, 0: 0x0B}

# --- Hotkeys (Ctrl+K start/stop, Esc quit) -- polled via GetAsyncKeyState ----
# These are Windows VIRTUAL-KEY codes (a different namespace from the scancodes
# above): Ctrl=0x11, K=0x4B, Esc=0x1B.
VK_CONTROL = 0x11
VK_K       = 0x4B
VK_ESC     = 0x1B
TOGGLE_NAME = "Ctrl+K"

# Customisable hotkeys (set in the app Keybinds tab). Each is a combo dict:
# {ctrl, alt, shift, code} where code is a JS KeyboardEvent.code (e.g. "KeyK").
HOTKEY_TOGGLE   = {"ctrl": True,  "alt": False, "shift": False, "code": "KeyK"}
HOTKEY_SOFTSTOP = {"ctrl": True,  "alt": False, "shift": False, "code": "KeyJ"}
HOTKEY_QUIT     = {"ctrl": False, "alt": False, "shift": False, "code": "Escape"}
HOTKEY_POPOUT   = {"ctrl": True,  "alt": False, "shift": False, "code": "KeyP"}
HOTKEY_PAUSE    = {"ctrl": True,  "alt": False, "shift": False, "code": "KeyL"}
HOTKEY_RELIC_RESET = {"ctrl": True, "alt": False, "shift": False, "code": "KeyU"}
# RELIC placement/timing behaviour:
RELIC_ON_LAND      = False  # wait until ON LAND (Collect Deposit) to place a
                            # due relic -- placing from the water misplaces it
RELIC_LAND_MAX_S   = 45     # give up waiting for land after this and place
RELIC_RELATIVE     = True   # relic timers follow REAL time (the in-game buff
                            # keeps burning while the macro is paused). Off =
                            # timers freeze with the pause.

# ============================================================================
# Below here you normally don't need to edit.
# ============================================================================

try:
    import numpy as np
    import mss
    import ctypes
    from ctypes import wintypes
except ImportError as e:
    sys.exit(
        f"Missing dependency: {e}\n"
        "Install with:\n"
        "  pip install mss numpy"
    )

# Use the non-deprecated MSS class when available (falls back on old name).
_MSS = getattr(mss, "MSS", None) or mss.mss

# Make the process DPI-aware so screen capture (mss) and cursor coords line up
# in real pixels on high-DPI / scaled Windows displays.
try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)   # PER_MONITOR_AWARE
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

_user32 = ctypes.windll.user32


def _as_ref_list(spec):
    """Accept a single (r,g,b) tuple OR a list of them; return a list."""
    if len(spec) and isinstance(spec[0], (int, float)):
        return [tuple(spec)]
    return [tuple(c) for c in spec]


# ---- Display scale: with DPI-awareness set above, capture and cursor are both
#      in physical pixels, so the scale is 1.0 on Windows. -----------------------
def get_scale(sct):
    return 1.0


# ---- Window-relative capture (opt-in) ---------------------------------------
def find_roblox_rect():
    """Roblox game client area as (x, y, w, h) in physical px, or None. Scans all
    visible top-level windows (class WINDOWSCLIENT, or title containing 'Roblox'
    but not Studio) and picks the largest -- robust to title variations."""
    try:
        from ctypes import wintypes
        u = ctypes.windll.user32
        best = []

        @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
        def _cb(hwnd, _lp):
            try:
                if not u.IsWindowVisible(hwnd):
                    return True
                n = u.GetWindowTextLengthW(hwnd)
                tb = ctypes.create_unicode_buffer(n + 1)
                u.GetWindowTextW(hwnd, tb, n + 1)
                title = tb.value or ""
                cb = ctypes.create_unicode_buffer(256)
                u.GetClassNameW(hwnd, cb, 256)
                cls = cb.value or ""
                if not (cls == "WINDOWSCLIENT" or
                        ("Roblox" in title and "Studio" not in title)):
                    return True
                rc = wintypes.RECT()
                if not u.GetClientRect(hwnd, ctypes.byref(rc)):
                    return True
                w, h = rc.right - rc.left, rc.bottom - rc.top
                if w < 320 or h < 240:
                    return True
                pt = wintypes.POINT(0, 0)
                u.ClientToScreen(hwnd, ctypes.byref(pt))
                best.append((w * h, int(pt.x), int(pt.y), int(w), int(h)))
            except Exception:
                pass
            return True

        u.EnumWindows(_cb, 0)
        if best:
            best.sort(reverse=True)
            return best[0][1:]
        return None
    except Exception as e:
        print(f"[window] lookup failed: {e}")
        return None


def find_window_origin():
    """(x, y) of the Roblox client top-left, or None. (Back-compat wrapper.)"""
    r = find_roblox_rect()
    return (r[0], r[1]) if r else None


def apply_auto_calibrate():
    """Position every watched pixel from the LIVE Roblox window using the ratio
    profile. Runs at start when AUTO_CALIBRATE is on and PIXEL_RATIOS exist. This
    is what lets calibration work with zero clicking and survive window moves /
    different resolutions. Returns True if it placed the pixels."""
    if not AUTO_CALIBRATE or not PIXEL_RATIOS:
        return False
    rect = find_roblox_rect()
    if not rect:
        print("[autocal] Roblox window not found; using saved coordinates")
        return False
    x, y, w, h = rect
    g = globals()
    placed = 0
    for pk, fr in PIXEL_RATIOS.items():
        if pk in g and isinstance(fr, (list, tuple)) and len(fr) == 2:
            g[pk] = (int(round(x + fr[0] * w)), int(round(y + fr[1] * h)))
            placed += 1
    # recompute the capacity-bar width from the two bar-end ratios if present
    if "CAP_FULL_PIXEL" in PIXEL_RATIOS and "CAP_LEFT_PIXEL" in PIXEL_RATIOS:
        bw = int(round((PIXEL_RATIOS["CAP_FULL_PIXEL"][0]
                        - PIXEL_RATIOS["CAP_LEFT_PIXEL"][0]) * w))
        if bw > 20:
            g["CAP_BAR_WIDTH"] = bw
    g["CAP_START_PIXEL"] = (g["CAP_FULL_PIXEL"][0] - g["CAP_BAR_WIDTH"] + 12,
                            g["CAP_FULL_PIXEL"][1])
    print(f"[autocal] placed {placed} pixels from Roblox window "
          f"{w}x{h} at ({x},{y})")
    return True


def apply_window_offset():
    """If WINDOW_RELATIVE, shift the calibrated pixels by how far the Roblox
    window moved since calibration. No-op when off / not found / unmoved."""
    if not WINDOW_RELATIVE:
        return
    o = find_window_origin()
    if not o:
        print("[window] Roblox window not found; using saved coords as-is")
        return
    dx = o[0] - CALIB_WINDOW_ORIGIN[0]
    dy = o[1] - CALIB_WINDOW_ORIGIN[1]
    if dx == 0 and dy == 0:
        return
    g = globals()
    for pk in ("CAP_FULL_PIXEL", "DEPOSIT_PIX", "PAN_PIX", "SHAKE_PIX",
               "DIG_TRIGGER_PIXEL", "TERRAIN_PIXEL"):
        x, y = g[pk]
        g[pk] = (x + dx, y + dy)
    g["CAP_START_PIXEL"] = (g["CAP_FULL_PIXEL"][0] - g["CAP_BAR_WIDTH"] + 12,
                            g["CAP_FULL_PIXEL"][1])
    print(f"[window] shifted pixels by ({dx},{dy}) for window move")


# ---- High-precision timing --------------------------------------------------
def sleep_until(deadline):
    while True:
        remaining = deadline - time.perf_counter()
        if remaining <= 0:
            return
        if remaining > 0.002:
            time.sleep(remaining - 0.0015)
        else:
            while time.perf_counter() < deadline:
                pass
            return


def sleep_ms(ms):
    sleep_until(time.perf_counter() + ms / 1000.0)


# ---- live logging (timestamped, scrolling) ----------------------------------
_log_t0 = None


def log(msg):
    """Print a timestamped line so you can watch the macro's reasoning live."""
    if not LOG_LIVE:
        return
    global _log_t0
    now = time.perf_counter()
    if _log_t0 is None:
        _log_t0 = now
    print(f"[{now - _log_t0:7.2f}s] {msg}", flush=True)


# any of these events means the current cycle wasn't perfectly smooth
_DIRTY_EVENTS = {"shake_fail", "shake_start_retry", "nudge", "recover",
                 "break_out", "shake_glitch", "no_progress", "safe_stop",
                 "hard_stop", "fr_recover", "recenter"}


def emit_phase(name):
    """__PHASE__ <name> line: the app times each phase (dig / water / shake)
    for the per-phase analytics. Print-only; never affects the macro."""
    try:
        print("__PHASE__ " + name, flush=True)
    except Exception:
        pass


def emit_event(etype, reason="", where="", contents=""):
    """Emit a structured telemetry event (__EVENT__ <json>) the app collects into
    the run record: WHAT happened and WHY, so the analytics + Coach can explain
    each safe-stop / nudge / recovery. Best-effort; never affects the macro."""
    try:
        rec = {"type": etype, "reason": reason or "",
               "t": round(State.stats.runtime(), 1) if State.stats else 0.0}
        if where:
            rec["where"] = where
        if contents:
            rec["contents"] = contents
        if etype in _DIRTY_EVENTS:
            State.cycle_dirty = True         # this cycle wasn't clean
        print("__EVENT__ " + json.dumps(rec), flush=True)
    except Exception:
        pass


# ---- Input engine (Windows SendInput) ---------------------------------------
# Keys are sent as hardware SCANCODES (KEYEVENTF_SCANCODE) and mouse via
# MOUSEEVENTF_* -- the most reliable way to drive Roblox on Windows.
KEYEVENTF_KEYUP     = 0x0002
KEYEVENTF_SCANCODE  = 0x0008
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP   = 0x0004
MOUSEEVENTF_MOVE     = 0x0001
INPUT_MOUSE    = 0
INPUT_KEYBOARD = 1
ULONG_PTR = ctypes.wintypes.WPARAM


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", ctypes.wintypes.WORD), ("wScan", ctypes.wintypes.WORD),
                ("dwFlags", ctypes.wintypes.DWORD), ("time", ctypes.wintypes.DWORD),
                ("dwExtraInfo", ULONG_PTR)]


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", ctypes.wintypes.LONG), ("dy", ctypes.wintypes.LONG),
                ("mouseData", ctypes.wintypes.DWORD), ("dwFlags", ctypes.wintypes.DWORD),
                ("time", ctypes.wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class _INPUTunion(ctypes.Union):
    _fields_ = [("ki", _KEYBDINPUT), ("mi", _MOUSEINPUT)]


class _INPUT(ctypes.Structure):
    _fields_ = [("type", ctypes.wintypes.DWORD), ("u", _INPUTunion)]


def _send(inp):
    _user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(inp))


def key_down(code):
    inp = _INPUT(type=INPUT_KEYBOARD,
                 u=_INPUTunion(ki=_KEYBDINPUT(0, code, KEYEVENTF_SCANCODE, 0, 0)))
    _send(inp)


def key_up(code):
    inp = _INPUT(type=INPUT_KEYBOARD,
                 u=_INPUTunion(ki=_KEYBDINPUT(0, code,
                              KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP, 0, 0)))
    _send(inp)


def tap_key(code, ms=40):
    """Press and release a key (e.g. a hotbar number)."""
    if code is None:
        return
    key_down(code)
    sleep_ms(ms)
    key_up(code)


class _Point(ctypes.Structure):
    _fields_ = [("x", ctypes.wintypes.LONG), ("y", ctypes.wintypes.LONG)]


def _cursor_point():
    p = _Point()
    _user32.GetCursorPos(ctypes.byref(p))
    return p           # has .x / .y like the macOS point


def _mouse_btn(flag):
    inp = _INPUT(type=INPUT_MOUSE,
                 u=_INPUTunion(mi=_MOUSEINPUT(0, 0, 0, flag, 0, 0)))
    _send(inp)


def mouse_down():
    _mouse_btn(MOUSEEVENTF_LEFTDOWN)


def mouse_up():
    _mouse_btn(MOUSEEVENTF_LEFTUP)


def mouse_tap(ms):
    mouse_down()
    sleep_ms(ms)
    mouse_up()


def _drag_alive():
    """Nudge the mouse 0px to keep a held LMB 'alive' (Windows equivalent of the
    macOS drag keep-alive)."""
    inp = _INPUT(type=INPUT_MOUSE,
                 u=_INPUTunion(mi=_MOUSEINPUT(0, 0, 0, MOUSEEVENTF_MOVE, 0, 0)))
    _send(inp)


# ---- Cursor move / click-at / scroll / sample (Fortune River recovery) ------
MOUSEEVENTF_WHEEL = 0x0800


def move_cursor(x, y):
    _user32.SetCursorPos(int(x), int(y))


def click_at(x, y, ms=40):
    move_cursor(x, y)
    sleep_ms(30)
    mouse_tap(ms)


def scroll_down(steps=3):
    data = (-120 * abs(int(steps))) & 0xFFFFFFFF
    inp = _INPUT(type=INPUT_MOUSE,
                 u=_INPUTunion(mi=_MOUSEINPUT(0, 0, data, MOUSEEVENTF_WHEEL, 0, 0)))
    _send(inp)


def rgb_at(sct, x, y):
    """Mean (r,g,b) in a small box around a physical-pixel coord."""
    reg = {"left": int(x) - 2, "top": int(y) - 2, "width": 5, "height": 5}
    b, g, r = np.asarray(sct.grab(reg))[:, :, :3].reshape(-1, 3).mean(0)
    return r, g, b


def _rgb_match(rgb, target, tol):
    return all(abs(float(c) - float(tt)) <= tol for c, tt in zip(rgb, target))


def fr_reset_home():
    State.fr_cur = [int(FR_HOME_PIXEL[0]), int(FR_HOME_PIXEL[1])]


def _rel_move(dx, dy):
    inp = _INPUT(type=INPUT_MOUSE,
                 u=_INPUTunion(mi=_MOUSEINPUT(int(dx), int(dy), 0,
                              MOUSEEVENTF_MOVE, 0, 0)))
    _send(inp)


def fr_move_to(x, y):
    """Move the cursor to (x, y) using RELATIVE deltas from the calibrated home
    (screen centre where the cursor rests with shift-lock off), in small steps
    so pointer acceleration can't throw it off."""
    if State.fr_cur is None:
        fr_reset_home()
    tx, ty = int(x), int(y)
    cx, cy = State.fr_cur
    step = max(1, FR_MOVE_STEP)
    while cx != tx or cy != ty:
        sx = max(-step, min(step, tx - cx))
        sy = max(-step, min(step, ty - cy))
        _rel_move(sx, sy)
        cx += sx
        cy += sy
        sleep_ms(4)
    State.fr_cur = [tx, ty]


def hold_mouse(ms, stop_fn=None, confirm=2, min_ms=200):
    """Hold LMB up to ms, keeping the press 'alive'. If stop_fn is given, release
    early once it returns True for `confirm` reads in a row (but never before
    min_ms)."""
    mouse_down()
    start = time.perf_counter()
    end = start + ms / 1000.0
    hits = 0
    stopped = False
    while time.perf_counter() < end and State.running:
        _drag_alive()
        if stop_fn is not None and (time.perf_counter() - start) * 1000 >= min_ms:
            hits = hits + 1 if stop_fn() else 0
            if hits >= confirm:
                stopped = True
                break
        sleep_ms(16)
    mouse_up()
    return stopped     # True if stop_fn fired (pan emptied), False if timed out


def _drag_for(ms, stop_fn=None):
    """Keep an ALREADY-held LMB alive for up to ms. Returns True if stop_fn
    fired. (Caller does mouse_down/up around this.)"""
    end = time.perf_counter() + ms / 1000.0
    while time.perf_counter() < end and State.running:
        _drag_alive()
        if stop_fn is not None and stop_fn():
            return True
        sleep_ms(16)
    return False


# ---- Colour tests -----------------------------------------------------------
def is_green(r, g, b):
    """The dig skill-bar's GREEN zone (bright green, green channel dominant).
    Used as 'a dig animation is RUNNING' -- the bar only exists mid-dig."""
    return g >= 100 and g > r + 35 and g > b + 35


def is_white(r, g, b):
    return r >= WHITE_MIN and g >= WHITE_MIN and b >= WHITE_MIN


def is_yellow(r, g, b):
    return r >= YEL_MIN and g >= YEL_MIN and b <= min(r, g) - YEL_BLUE_GAP


def _unpack_cue_mask(m):
    """CUE_MASKS bits (base64 packed bools) -> HxW bool array, or None."""
    try:
        import base64
        raw = base64.b64decode(m["bits"])
        h, w = int(m["h"]), int(m["w"])
        bits = np.unpackbits(np.frombuffer(raw, dtype=np.uint8))[:h * w]
        return bits.reshape(h, w).astype(bool)
    except Exception:
        return None


def place_cue_masks():
    """Place each captured cue mask onto the LIVE window from its stored ratio
    (advanced cue matching). Runs once at start after the pixels are placed. If
    the window SIZE drifted from calibration the fixed-size mask would misalign,
    so that cue is skipped (falls back to the box check) and a recalibration
    reason is set for the app to flag."""
    global CUE_MASK_BOXES
    CUE_MASK_BOXES = {}
    if not ADVANCED_CUES or not CUE_MASKS:
        return
    rect = find_roblox_rect()
    if not rect:
        return
    x, y, w, h = rect
    for cue, m in CUE_MASKS.items():
        try:
            rl, rt, rw, rh = m["ratio"]
            bw, bh = int(round(rw * w)), int(round(rh * h))
            if abs(bw - int(m["w"])) > 2 or abs(bh - int(m["h"])) > 2:
                State.recal_reason = ("the Roblox window/resolution changed since "
                                      "calibration -- advanced cue matching is off "
                                      "until you re-calibrate")
                continue
            CUE_MASK_BOXES[cue] = {"left": int(round(x + rl * w)),
                                   "top": int(round(y + rt * h)),
                                   "width": int(m["w"]), "height": int(m["h"])}
        except Exception:
            continue


# ---- Capture + detection ----------------------------------------------------
class Detector:
    def __init__(self, sct):
        self.sct = sct
        self.dig_region = self._box(DIG_TRIGGER_PIXEL)
        self.cap_region = self._box(CAP_FULL_PIXEL)
        self.cap_start_region = self._box(CAP_START_PIXEL)
        self.deposit_region = self._box(DEPOSIT_PIX)
        self.pan_region = self._box(PAN_PIX)
        self.shake_region = self._box(SHAKE_PIX)
        self.terrain_region = self._box(TERRAIN_PIXEL)
        # one or more normalised reference colours per terrain (two-tone support)
        self._dirt = [self._chroma(c) for c in _as_ref_list(DIRT_RGB)]
        self._wet = [self._chroma(c) for c in _as_ref_list(WET_RGB)]
        l, t, w, h = TEXT_REGION
        self.text_region = {"left": l, "top": t, "width": w, "height": h}

    @staticmethod
    def _chroma(rgb):
        a = np.asarray(rgb, dtype=np.float64)
        s = a.sum()
        return a / s if s else a

    @staticmethod
    def _box(pixel):
        x, y = pixel
        h = SAMPLE_BOX
        return {"left": x - h // 2, "top": y - h // 2, "width": h, "height": h}

    def _rgb(self, region):
        img = np.asarray(self.sct.grab(region))[:, :, :3]   # BGRA -> BGR
        b, g, r = img.reshape(-1, 3).mean(0)
        return r, g, b

    def white_on_trigger(self):
        return is_white(*self._rgb(self.dig_region))

    def dig_bar_green(self):
        """True while the dig skill-bar's GREEN zone shows at the calibrated
        trigger pixel -- i.e. a dig animation is RUNNING right now. The bar
        only exists during a dig, so this is the earliest 'the dig
        registered' signal there is; the capacity bar can lag it by whole
        animations."""
        return is_green(*self._rgb(self.dig_region))

    def capacity_full(self):
        return is_yellow(*self._rgb(self.cap_region))

    def snapshot(self):
        """All sensors in ONE pass (5 grabs). Returns raw booleans:
        (on_land, in_water, shaking, pan_full, pan_empty). Position cues are
        mutually exclusive via the deposit-pixel guard, so the wide 'Collect
        Deposit' text can't masquerade as 'Pan'/'Shake'."""
        dep = self._cue("DEPOSIT", self.deposit_region)
        pan = self._cue("PAN", self.pan_region) and not dep
        shk = self._cue("SHAKE", self.shake_region) and not dep
        full = self.capacity_full()
        empty = self.pan_empty()
        return dep, pan, shk, full, empty

    def _cue_white(self, region):
        # count white-text pixels in the box (don't average -- thin text would
        # get diluted by the dark background and never pass the threshold).
        img = np.asarray(self.sct.grab(region))[:, :, :3].astype(np.int16)  # BGR
        b, g, r = img[:, :, 0], img[:, :, 1], img[:, :, 2]
        lo = np.minimum(np.minimum(r, g), b)
        hi = np.maximum(np.maximum(r, g), b)
        white = (lo >= CUE_WHITE_MIN) & ((hi - lo) <= CUE_WHITE_SPREAD)
        return float(white.mean()) >= CUE_WHITE_FRAC

    def _cue_mask_match(self, cue_key):
        """Advanced cue matching: True/False if this cue has a captured mask that
        is currently placed, else None (caller falls back to the box check)."""
        if not ADVANCED_CUES:
            return None
        box = CUE_MASK_BOXES.get(cue_key)
        m = CUE_MASKS.get(cue_key)
        if not box or not m:
            return None
        try:
            img = np.asarray(self.sct.grab(box))[:, :, :3].astype(np.int16)
            b, g, r = img[:, :, 0], img[:, :, 1], img[:, :, 2]
            lo = np.minimum(np.minimum(r, g), b)
            hi = np.maximum(np.maximum(r, g), b)
            white = (lo >= CUE_WHITE_MIN) & ((hi - lo) <= CUE_WHITE_SPREAD)
            mask = _unpack_cue_mask(m)
            if mask is None or mask.shape != white.shape or not mask.any():
                return None
            return float(white[mask].mean()) >= CUE_MASK_FRAC
        except Exception:
            return None

    def _cue(self, cue_key, region):
        """Mask match if available (advanced), else the plain white-box check.
        CUE_MASKS_ONLY (test mode) removes the box fallback so ONLY captured masks
        drive detection -- a cue with no usable mask then never fires."""
        r = self._cue_mask_match(cue_key)
        if r is not None:
            return r
        if ADVANCED_CUES and CUE_MASKS_ONLY:
            return False
        return self._cue_white(region)

    def on_deposit(self):
        """True when the 'Collect Deposit' cue shows (white) = on the land edge."""
        return self._cue("DEPOSIT", self.deposit_region)

    def on_pan(self):
        """True when the 'Pan' cue shows (white) = in the water. Excludes the
        wide 'Collect Deposit' text (its leftmost pixel) to avoid confusion."""
        return self._cue("PAN", self.pan_region) and not self._cue("DEPOSIT", self.deposit_region)

    def on_shake(self):
        """True when the 'Shake' cue shows (white) = the shake has initiated."""
        return self._cue("SHAKE", self.shake_region) and not self._cue("DEPOSIT", self.deposit_region)

    def cap_start_rgb(self):
        """Current colour at the start of the bar (for baseline comparison)."""
        return self._rgb(self.cap_start_region)

    def cap_changed(self, baseline):
        """True once the start of the bar differs from `baseline` (its empty
        colour captured just before the dig) -> the bar started filling."""
        r, g, b = self._rgb(self.cap_start_region)
        r0, g0, b0 = baseline
        return max(abs(r - r0), abs(g - g0), abs(b - b0)) > CAP_START_DELTA

    def cap_fill(self):
        """Fraction (0..1) of the WHOLE capacity bar that reads yellow = how full
        the pan is. Used to detect a dig REGISTERING (fill rises) even when the
        pan was already partially full (so the start-pixel didn't change)."""
        x, y = CAP_FULL_PIXEL
        region = {"left": x - CAP_BAR_WIDTH, "top": y - 10,
                  "width": CAP_BAR_WIDTH, "height": 20}
        img = np.asarray(self.sct.grab(region))[:, :, :3].astype(np.int16)
        b, g, r = img[:, :, 0], img[:, :, 1], img[:, :, 2]
        yellow = (r >= YEL_MIN) & (g >= YEL_MIN) & (b <= np.minimum(r, g) - YEL_BLUE_GAP)
        return float(yellow.mean())

    def pan_empty(self):
        """True when the WHOLE capacity bar has essentially no yellow left."""
        return self.cap_fill() < CAP_EMPTY_FRAC

    def on_wet(self):
        """True if the feet pixel's colour proportion is closer to a WET (lava/
        water) reference than to any DIRT reference. Chromaticity ignores
        brightness/white pulses; nearest-of-many handles two-tone ground."""
        c = self._chroma(self._rgb(self.terrain_region))
        dw = min(np.sum((c - w) ** 2) for w in self._wet)
        dd = min(np.sum((c - d) ** 2) for d in self._dirt)
        return dw < dd

    def on_dirt(self):
        return not self.on_wet()

    def wet_stable(self, n=TERRAIN_CONFIRM):
        """Majority vote over n quick reads -> filters single-frame glitches."""
        return sum(1 for _ in range(n) if self.on_wet()) > n // 2

    # ---- HUD text layer (white-pixel fraction -> prompt word) ----------------
    def text_fraction(self):
        img = np.asarray(self.sct.grab(self.text_region))[:, :, :3]  # BGR
        white = np.all(img >= TEXT_WHITE_MIN, axis=2)
        return float(white.mean())

    def text_state(self):
        """'pan' (liquid), 'shake', or 'deposit' (dirt) by amount of text."""
        f = self.text_fraction()
        if f <= TEXT_PAN_MAX:
            return "pan"
        if f <= TEXT_SHAKE_MAX:
            return "shake"
        return "deposit"

    def text_state_stable(self, n=3):
        from collections import Counter
        return Counter(self.text_state() for _ in range(n)).most_common(1)[0][0]


# ---- Global state -----------------------------------------------------------
class State:
    running = False
    recal_reason = ""        # non-empty -> the app shows a red "recalibrate" flag
    paused = False           # session PAUSE: stats/relics/earnings all kept
    relic_reset_pending = False   # (legacy flag; resets act directly now)
    relics_ref = None             # live RelicScheduler (listener/stdin access)
    relic_shift_pending = 0.0     # pause span to add to timers (non-relative)
    alive = True
    empty_fails = 0          # consecutive cycles the pan wouldn't empty
    shake_fails = 0          # consecutive shakes that didn't empty the pan
    land_fails = 0           # consecutive times the dig-probe couldn't find land
    breakouts = 0            # consecutive smart break-outs (escape a stuck loop)
    safe_retries = 0         # consecutive safe-stop pauses (retry, not hard-stop)
    want_reset = False       # supervisor resets itself after a safe-pause
    stop_reason = ""         # latest stop reason (manual/safe/auto/bag)
    water_fails = 0          # consecutive go_water tries that didn't reach water
    x_dir = 0                # X-pattern: which diagonal side to use next
    x_balance = 0.0          # X-pattern: running lateral balance (ms; +right/-left)
    no_full = 0              # consecutive dig cycles where the pan never read FULL
    cycle_dirty = False      # this cycle needed a retry/recovery (clean-cycle %)
    fill_digs = []           # DIG PIPELINE: digs-per-fill history (learning)
    trk_last = None          # TRACKER: previous fill sample
    trk_peak = 0.0           # TRACKER: high-water mark of the current pan
    trk_rise_t = 0.0         # TRACKER: last time the bar was rising
    trk_fall_t = 0.0         # TRACKER: last time the bar was draining
    trk_phase = ""           # TRACKER: last emitted phase
    earn = None              # EARNINGS: live OCR tracker (or None)
    finds = None             # FINDS: live OCR watcher (or None)
    dig_burst_t = 0.0        # registered-dig burst clock (fixes inflation)
    assume_full_until = 0.0  # SHARDS: treat capacity as FULL until this
    last_cycle_end = 0.0     # per-cycle duration tracking
    ap_next_check = 0.0      # AUTO PAN GUARD: next scheduled button read
    ap_off_streak = 0        # AUTO PAN GUARD: consecutive OFF reads
    ap_kick_grace = 0.0      # HEALTH KICK: activity deadline resets to this
    t_side = 0               # Treasure mode: 0 -> strafe D (right), 1 -> A (left)
    ad_shake_n = 0           # adaptive: shake attempts in the current window
    ad_shake_miss = 0
    ad_land_n = 0            # adaptive: land attempts in the current window
    ad_land_miss = 0
    ad_water_dir = 1         # hill-climb direction for the water-reach knob
    ad_water_prev = None
    ad_land_dir = 1          # hill-climb direction for the land-reach knob
    ad_land_prev = None
    stats = None             # SessionStats while running
    last_progress = 0.0      # perf_counter of the last real progress (pan emptied / dig hit)
    want_safe_stop = False   # manual soft-stop test keybind -> trip a safe stop
    detector = None          # live Detector (for Fortune River recovery)
    scale = 1.0              # screen scale (physical px / points) for cursor moves
    fr_cur = None            # tracked cursor pos during Fortune River recovery


class SessionStats:
    """Live counters for the current run (cycles, recoveries, runtime, ...)."""
    def __init__(self):
        self.start = time.perf_counter()
        self.cycles = 0       # pans emptied = completed cycles
        self.clean_cycles = 0 # cycles with ZERO retries/recoveries (consistency)
        self.digs = 0         # REGISTERED digs (bar-rise bursts)
        self.dig_clicks = 0   # dig clicks fired (attempts; >= digs)
        self.pauses = 0       # session pauses taken
        self.cycle_ms = []    # per-cycle durations (capped)
        self.finds_count = 0  # FINDS: items seen in the pop-up
        self.find_kg = 0.0    # FINDS: total weight collected
        self.best_kg = 0.0    # FINDS: heaviest single find
        self.by_rarity = {}   # FINDS: rarity -> count
        self.by_mod = {}      # FINDS: modifier -> count
        self.loot_value = 0.0 # FINDS: estimated value of logged finds
        self.finds_stack = 0  # FINDS: cards live in the stack right now
        self.finds_lowconf = 0 # FINDS: finds logged without a clean read
        self.money_earned = 0 # EARNINGS: summed positive money deltas
        self.shards_earned = 0
        self.recoveries = 0
        self.safe_stops = 0
        self.hard_stops = 0
        self.relics_used = 0
        self.pause_accum = 0.0   # total paused seconds (excluded from runtime)
        self.pause_started = None
        self.nudges = 0
        self.shake_misses = 0    # shakes that ran but didn't empty (fast-build misses)
        self.stop_reason = ""

    def runtime(self):
        rt = time.perf_counter() - self.start - self.pause_accum
        if self.pause_started is not None:       # currently paused
            rt -= time.perf_counter() - self.pause_started
        return max(0.0, rt)

    def as_dict(self):
        rt = self.runtime()
        hrs = rt / 3600.0
        return {"cycles": self.cycles, "recoveries": self.recoveries,
                "clean_cycles": self.clean_cycles,
                "clean_pct": (round(100.0 * self.clean_cycles / self.cycles, 1)
                              if self.cycles else 0),
                "digs": self.digs,
                "tracker": bool(TRACKER_MODE),
                "money_earned": self.money_earned,
                "shards_earned": self.shards_earned,
                "money_per_hr": (round(self.money_earned / hrs)
                                 if hrs > 0.0008 else 0),
                "shards_per_hr": (round(self.shards_earned / hrs, 1)
                                  if hrs > 0.0008 else 0),
                "money_per_pan": (round(self.money_earned / self.cycles)
                                  if self.cycles else 0),
                "shards_per_pan": (round(self.shards_earned / self.cycles, 2)
                                   if self.cycles else 0),
                "dig_clicks": self.dig_clicks,
                "digs_per_pan": (round(self.digs / self.cycles, 2)
                                 if self.cycles else 0),
                "clicks_per_pan": (round(self.dig_clicks / self.cycles, 2)
                                   if self.cycles else 0),
                "pauses": self.pauses,
                "cyc_mean_s": (round(sum(self.cycle_ms) / len(self.cycle_ms)
                                     / 1000.0, 2) if self.cycle_ms else 0),
                "cyc_p50_s": (round(sorted(self.cycle_ms)[len(self.cycle_ms)
                                    // 2] / 1000.0, 2) if self.cycle_ms else 0),
                "cyc_p95_s": (round(sorted(self.cycle_ms)[
                    min(len(self.cycle_ms) - 1,
                        int(0.95 * (len(self.cycle_ms) - 1)))] / 1000.0, 2)
                    if self.cycle_ms else 0),
                "cyc_last_s": (round(self.cycle_ms[-1] / 1000.0, 2)
                               if self.cycle_ms else 0),
                "finds_count": self.finds_count,
                "find_kg": round(self.find_kg, 1),
                "best_kg": round(self.best_kg, 1),
                "by_rarity": dict(self.by_rarity),
                "by_mod": dict(self.by_mod),
                "finds_stack": int(self.finds_stack),
                "finds_lowconf": int(self.finds_lowconf),
                "loot_value": int(self.loot_value),
                "loot_per_hr": (int(self.loot_value / hrs)
                                if hrs > 0.0008 else 0),
                "total_per_hr": ((round(self.money_earned / hrs)
                                  if hrs > 0.0008 else 0)
                                 + (int(self.loot_value / hrs)
                                    if hrs > 0.0008 else 0)),
                "runtime_s": int(rt),
                "pans_per_hr": round(self.cycles / hrs, 1) if hrs > 0.0008 else 0,
                "safe_stops": self.safe_stops, "hard_stops": self.hard_stops,
                "relics_used": self.relics_used, "nudges": self.nudges,
                "shake_misses": self.shake_misses,
                "stop_reason": self.stop_reason}


class _ARPool:
    """Per-iteration ObjC AUTORELEASE POOL for the OCR threads (macOS). The finds
    and earnings OCR run macOS Vision on BACKGROUND threads, which have no run
    loop to drain the thread's autorelease pool -- so every autoreleased NSData /
    VNImageRequestHandler / result (each holding an OCR image buffer) piles up
    for the WHOLE session. That was the multi-GB RAM leak. Wrapping each OCR call
    in this drains those objects immediately. No-op where pyobjc isn't present
    (Windows), so it's safe in both copies."""
    __slots__ = ("_p",)

    def __enter__(self):
        self._p = None
        if sys.platform == "darwin":
            try:
                from Foundation import NSAutoreleasePool
                self._p = NSAutoreleasePool.alloc().init()
            except Exception:
                self._p = None
        return self

    def __exit__(self, *a):
        self._p = None            # drop the only ref -> pool deallocs -> drains
        return False


class EarnTracker:
    """EARNINGS TRACKER (see constants). Background thread: OCR the money and
    shard HUD regions with macOS Vision; a value counts only when two
    reads 250ms apart AGREE (misreads don't repeat); positive deltas
    are credited to the run stats. Exits by
    itself when the run stops. Silently a no-op when disabled/uncalibrated,
    loudly a no-op when Vision is missing."""

    def __init__(self):
        self._stop = threading.Event()
        self._conf = {}          # name -> confirmed total
        self._down = {}          # name -> pending lower total (spend detect)
        self._miss = {}          # name -> consecutive failed reads

    def _regions(self):
        out = []
        for name, tl, br, field in (
                ("money", MONEY_TL_PIXEL, MONEY_BR_PIXEL, "money_earned"),
                ("shards", SHARDS_TL_PIXEL, SHARDS_BR_PIXEL, "shards_earned")):
            try:
                x0, y0, x1, y1 = int(tl[0]), int(tl[1]), int(br[0]), int(br[1])
            except Exception:
                continue
            if x1 - x0 >= 12 and y1 - y0 >= 8:
                out.append((name, {"left": x0, "top": y0, "width": x1 - x0,
                                   "height": y1 - y0}, field))
        return out

    def start(self):
        if not EARN_TRACK:
            return
        regs = self._regions()
        if not regs:
            log("[earn] EARN_TRACK is on but the money/shards regions aren't "
                "calibrated (Calibrate tab -> Money/Shards corners)")
            return
        try:
            import Vision, Foundation  # noqa: F401  (pyobjc-framework-Vision)
        except Exception:
            log("[earn] macOS Vision OCR not available -> earnings off "
                "(try: pip3 install pyobjc-framework-Vision)")
            return
        self._stop.clear()
        threading.Thread(target=self._run, args=(regs,), daemon=True).start()
        log("[earn] earnings tracker running (%s)"
            % ", ".join(n for n, _r, _f in regs))

    def stop(self):
        self._stop.set()

    def _run(self, regs):
        import mss
        with mss.mss() as sct:
            while not self._stop.is_set() and (State.running or State.paused):
                for name, reg, field in regs:
                    with _ARPool():
                        v = self._read_stable(sct, reg)
                    if v is None:
                        misses = self._miss.get(name, 0) + 1
                        self._miss[name] = misses
                        if misses == 3:
                            log("[earn] %s: OCR keeps reading nothing/unstable "
                                "-- check the region corners" % name)
                        continue
                    self._miss[name] = 0
                    conf = self._conf.get(name)
                    if conf is None:
                        self._conf[name] = v                  # baseline
                        log("[earn] %s baseline: %s" % (name, "{:,}".format(v)))
                    elif v > conf:
                        delta = v - conf
                        # a total can't (nearly) double between reads
                        if delta < max(conf, 10**6) and State.stats:
                            setattr(State.stats, field,
                                    getattr(State.stats, field) + delta)
                            log("[earn] %s +%s" % (name, "{:,}".format(delta)))
                        self._conf[name] = v
                        self._down[name] = None
                    elif v < conf:
                        # spending -- or a repeated misread. Demand a SECOND
                        # matching low read next cycle before re-baselining.
                        d = self._down.get(name)
                        if d is not None and abs(v - d) <= max(1, d // 1000):
                            self._conf[name] = v              # no credit
                            self._down[name] = None
                            log("[earn] %s re-baselined to %s (spent?)"
                                % (name, "{:,}".format(v)))
                        else:
                            self._down[name] = v
                self._stop.wait(max(2, EARN_OCR_SEC))

    def _read_stable(self, sct, reg):
        """Two reads 250ms apart must AGREE. The total is static on that
        timescale (gains land seconds apart), while an OCR misread almost
        never repeats identically -- so this filters garbage without ever
        blocking real values (the old 10s-apart equality rule could never
        confirm anything while actively earning)."""
        try:
            a = self._read(sct, reg)
        except Exception:
            return None
        if a is None:
            return None
        self._stop.wait(0.25)
        try:
            b = self._read(sct, reg)
        except Exception:
            return None
        return a if a == b else None

    @staticmethod
    def _read(sct, reg):
        """One region -> int, or None. Upscaled 3x before recognition (the
        HUD numbers are small); bottom-most text line wins (the gain pop-ups
        float ABOVE the total and carry a '+')."""
        img = sct.grab(reg)
        import mss.tools
        arr = np.frombuffer(img.rgb, dtype=np.uint8).reshape(
            img.height, img.width, 3)
        big = arr.repeat(3, axis=0).repeat(3, axis=1)
        png = mss.tools.to_png(big.tobytes(), (img.width * 3, img.height * 3))
        from Foundation import NSData
        import Vision
        data = NSData.dataWithBytes_length_(png, len(png))
        handler = Vision.VNImageRequestHandler.alloc().initWithData_options_(
            data, None)
        req = Vision.VNRecognizeTextRequest.alloc().init()
        try:
            req.setRecognitionLevel_(0)               # accurate
            req.setUsesLanguageCorrection_(False)
        except Exception:
            pass
        handler.performRequests_error_([req], None)
        best = best_y = None
        for obs in (req.results() or []):
            try:
                s = str(obs.topCandidates_(1)[0].string())
            except Exception:
                continue
            if "+" in s:
                continue                              # gain popup, not total
            digs = "".join(c for c in s if c.isdigit())
            if not digs:
                continue
            y = float(obs.boundingBox().origin.y)
            if best is None or y < best_y:            # Vision y-up: lowest line
                best, best_y = int(digs), y
        return best


_RARITIES = ("Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythic",
             "Exotic", "Divine", "Relic")
_RARITY_RANK = {r: i for i, r in enumerate(_RARITIES)}


def _rarity_at_least(r, floor):
    """True if rarity r is at least `floor` in the ladder. Unknown r -> False."""
    a = _RARITY_RANK.get((r or "").title())
    b = _RARITY_RANK.get((floor or "").title(), 0)
    return a is not None and a >= b
# Value-tier modifiers from the v2.6 model (Section 4). These are the ones
# that carry a price multiplier; "modifier_mult" in the price table sets each.
_MODIFIERS = {"Shiny", "Pure", "Glowing", "Scorching", "Irradiated",
              "Iridescent", "Cosmic", "Mutated", "Lunar", "Perfect"}


def _load_prices():
    """prospecting_prices.json (next to the config): user-editable table for
    valuing KEPT finds. {"per_kg": {item: $/kg}, "rarity_mult": {...},
    "modifier_mult": {...}}. Missing file/keys -> value 0 (still logged)."""
    try:
        with open(os.path.join(os.path.dirname(CONFIG_FILE),
                               "prospecting_prices.json")) as f:
            return json.load(f)
    except Exception:
        return {}


def _finds_row_signal(arr):
    """Per-row 'card text' signal over the finds box. A pixel counts as TEXT
    when it is bright like the white HUD lettering (every RGB channel >=
    FINDS_WHITE_MIN) AND sits within a few px of a DARK pixel (the card's
    translucent dark backing / the text outline, every channel <=
    FINDS_DARK_MAX). Plain terrain fails one of the two tests -- snow has no
    dark neighbours, caves have no bright text -- so the signal is ~0 unless a
    card is there, and it scales with the card's fade alpha: THIS is the
    opacity signal the tracker classifies on. No background-colour keying.
    arr: HxWx3 uint8 -> float32[H], each row's text-pixel fraction (0..1)."""
    bright = arr.min(axis=2) >= FINDS_WHITE_MIN
    # tier-coloured glyphs (Cosmic purple and friends) are vivid but not
    # white: very bright in some channel and bright on average also counts
    bright |= ((arr.max(axis=2) >= 220) & (arr.mean(axis=2) >= 135))
    dark = arr.max(axis=2) <= FINDS_DARK_MAX
    if not bright.any() or not dark.any():
        return np.zeros(arr.shape[0], np.float32)
    near = dark.copy()                      # dilate the dark mask horizontally
    for s in (1, 2, 3):
        near[:, s:] |= dark[:, :-s]
        near[:, :-s] |= dark[:, s:]
    sig = (bright & near).mean(axis=1).astype(np.float32)
    if sig.shape[0] >= 5:                   # soften 1px speckle
        sig = np.convolve(sig, np.ones(5, np.float32) / 5.0, mode="same")
    return sig


def _finds_bands(sig, pitch, band_min):
    """Segment a row signal into vertical CARD BANDS: contiguous runs that
    clear band_min, merged across the small gaps between a card's own text
    lines, split when one run clearly spans several card pitches (two cards
    touching). Returns bands TOP -> BOTTOM, positions as top-down fractions of
    the region: [{y0, y1, cy, op}] where op is the band's mean signal (the
    card's opacity proxy)."""
    h = int(sig.shape[0]) if hasattr(sig, "shape") else len(sig)
    if h == 0:
        return []
    on = sig >= band_min
    runs = []
    i = 0
    while i < h:
        if on[i]:
            j = i
            while j < h and on[j]:
                j += 1
            runs.append([i, j])
            i = j
        else:
            i += 1
    if not runs:
        return []
    p = pitch if pitch > 0 else 0.16
    gap = max(3, int(h * min(0.45 * p, 0.06)))
    merged = [runs[0]]
    for r in runs[1:]:
        if r[0] - merged[-1][1] <= gap:
            merged[-1][1] = r[1]
        else:
            merged.append(r)
    min_h = max(2, int(h * max(0.02, 0.18 * p)))
    bands = []
    for i0, i1 in merged:
        if i1 - i0 < min_h:
            continue
        n = 1
        if pitch > 0:                        # split a run of touching cards
            n = min(6, max(1, int(round((i1 - i0) / (h * pitch)))))
        step = (i1 - i0) / float(n)
        for k in range(n):
            a0 = int(i0 + k * step)
            a1 = max(a0 + 1, int(i0 + (k + 1) * step))
            seg = sig[a0:a1]
            bands.append({"y0": a0 / float(h), "y1": a1 / float(h),
                          "cy": (a0 + a1) / (2.0 * float(h)),
                          "op": float(seg.mean()) if len(seg) else 0.0})
    return bands


def _finds_align(tcys, bcys, pitch, tol):
    """Order-preserving best match between tracked-card centres and this
    frame's band centres, allowing one COMMON vertical shift (an insertion
    pushes the whole stack together, so every surviving card moves by the same
    amount). Tries candidate shifts taken from the pairwise offsets, greedily
    matches in stack order within tol, and scores each alignment on two
    physical laws: more matched cards is better, and cards only ever ENTER at
    the newest end -- an alignment leaving unmatched bands on the OLD side of
    a matched one would mean a card "spawned" mid-stack (implausible), so it
    scores down before the smaller shift wins a tie. Returns (pairs, shift):
    pairs = [(track_i, band_i), ...]; shift = how far the stack moved this
    tick (negative = pushed toward the OLD end)."""
    if not tcys or not bcys:
        return [], 0.0
    span = max(6.0 * pitch, 0.5)   # a whole stack can insert in one gap
    cands = {0.0}
    for t in tcys:
        for b in bcys:
            d = b - t
            if abs(d) <= span:
                cands.add(round(d, 3))
    best_pairs, best_shift, best_score = [], 0.0, None
    for sh in cands:
        pairs = []
        bi = 0
        for ti, t in enumerate(tcys):
            want = t + sh
            while bi < len(bcys) and bcys[bi] < want - tol:
                bi += 1
            if bi < len(bcys) and abs(bcys[bi] - want) <= tol:
                pairs.append((ti, bi))
                bi += 1
        bad = 0
        if pairs:
            top = max(bcys[bi] for _ti, bi in pairs)
            used = {bi for _ti, bi in pairs}
            bad = sum(1 for bi, b in enumerate(bcys)
                      if bi not in used and b < top)
        score = (len(pairs), -bad, -abs(sh))
        if best_score is None or score > best_score:
            best_score, best_pairs, best_shift = score, pairs, sh
    return best_pairs, best_shift


class FindsWatcher:
    """FINDS TRACKER v2 -- fade-direction stack tracker.

    The finds HUD is a vertical stack of notification cards: a new card fades
    IN (transparent -> solid) at the newest end and pushes older cards along;
    an old card fades OUT and leaves. At high luck several skulls land in ONE
    pan, faster than an OCR pass -- so counting must not wait on OCR.

    Two decoupled cadences:
      * FAST sampler (FINDS_FAST_MS): a cheap pixel pass (no OCR) turns the
        calibrated box into per-card BANDS with an opacity value each. Bands
        are matched frame-to-frame by position (allowing the whole stack to
        shift together), giving every card an opacity TRAJECTORY: rising =
        animating IN = NEW; falling = animating OUT = already counted.
        Arrivals are counted here, at sample speed.
      * IDENTITY OCR (>= FINDS_OCR_MS apart): Vision reads the same grabbed
        frame; the parsed cards (name / modifier / kg / rarity) are bound to
        the tracked bands by position and refine each find. Identity may lag;
        the count never does.

    Count reconciliation (every fast tick): insertions implied by the stack
    SHIFT are cross-checked against the arrivals actually seen; a shortfall
    mints an INFERRED find (low confidence, identity best-effort) so bursts
    cannot under-count -- while dwell, opacity floors and the OCR cross-check
    stop noise from inventing finds. Two identical drops are two bands = two
    arrivals = two finds, by construction. An OCR SAFETY NET (the previous
    release's sequence tracker) still counts any card the pixel sampler never
    saw, so a mis-tuned threshold degrades to the old behaviour, not to zero.
    Every find prints __FIND__ once (by id) and __FIND_UPD__ when reads settle
    to a better name/weight; run stats adjust by the delta, never twice."""

    def __init__(self):
        self._stop = threading.Event()
        self._lock = threading.Lock()  # guards _frame / _ocr_out handoff
        self._frame = None      # newest (ts, pixels, band snapshot) for OCR
        self._ocr_out = []      # finished identity passes for the fast thread
        self._tracks = []       # live cards, sorted oldest(top) -> newest
        self._next_id = 1       # public find id (emitted)
        self._next_key = 1      # internal track key
        self._pitch = 0.0       # learned card pitch (fraction of region h)
        self._plateau = 0.0     # learned solid-card opacity (EMA of peaks)
        self._ocr_pass_n = 0    # identity passes ingested
        self._ocr_empty = 0     # consecutive identity passes with no cards
        self._no_band_since = None
        self._unbound = []      # recent OCR cards no track claimed
        self._recent_dead = []  # (t, cy, rep) of cards that just left -- a
                                # trailing OCR read of one must not re-mint it
        self._old_end_births = 0
        self._blind_warned = False
        self._last_dbg = 0.0
        self._last_tick_t = None

    # ---- lifecycle ------------------------------------------------------
    def start(self):
        if not FINDS_TRACK:
            return
        tl, br = FIND_TL_PIXEL, FIND_BR_PIXEL
        try:
            x0, y0, x1, y1 = int(tl[0]), int(tl[1]), int(br[0]), int(br[1])
        except Exception:
            return
        if x1 - x0 < 20 or y1 - y0 < 10:
            log("[finds] FINDS_TRACK is on but the pop-up region isn't "
                "calibrated (Calibrate tab -> Find pop-up corners)")
            return
        try:
            import Vision, Foundation  # noqa: F401
        except Exception:
            log("[finds] macOS Vision OCR not available -> finds tracking off")
            return
        self.prices = _load_prices()
        self.ore_names = list((self.prices.get("per_kg") or {}).keys())
        self.reg = {"left": x0, "top": y0, "width": x1 - x0, "height": y1 - y0}
        self._stop.clear()
        threading.Thread(target=self._run_fast, daemon=True).start()
        threading.Thread(target=self._run_ocr, daemon=True).start()
        log("[finds] fade tracker running (sample %dms / ocr %dms)"
            % (max(20, int(FINDS_FAST_MS)), max(60, int(FINDS_OCR_MS))))

    def stop(self):
        self._stop.set()

    # ---- the two threads --------------------------------------------------
    def _run_fast(self):
        import mss
        period = max(0.02, float(FINDS_FAST_MS) / 1000.0)
        with mss.mss() as sct:
            while not self._stop.is_set() and (State.running or State.paused):
                t0 = time.perf_counter()
                try:
                    img = sct.grab(self.reg)
                    arr = np.frombuffer(img.rgb, dtype=np.uint8).reshape(
                        img.height, img.width, 3)
                    now = time.perf_counter()
                    with self._lock:            # identity results first: they
                        outs = self._ocr_out    # bind to the tracks as they
                        self._ocr_out = []      # stood when THAT frame was
                    for _ts, cards, snap in outs:      # grabbed
                        self._ingest_ocr(now, cards, snap)
                    bands = _finds_bands(_finds_row_signal(arr),
                                         self._pitch, FINDS_BAND_MIN)
                    if (FINDS_STACK_NEWEST or "bottom").lower() == "top":
                        bands = [{"y0": 1.0 - b["y1"], "y1": 1.0 - b["y0"],
                                  "cy": 1.0 - b["cy"], "op": b["op"]}
                                 for b in bands]
                        bands.sort(key=lambda b: b["cy"])
                    self._fast_tick(now, bands)
                    snap = [(t["key"], t["y0"], t["y1"], t["cy"])
                            for t in self._tracks
                            if t["miss"] == 0 and not t.get("synthetic")]
                    with self._lock:
                        self._frame = (now, arr, snap)
                except Exception:
                    pass
                self._stop.wait(
                    max(0.005, period - (time.perf_counter() - t0)))

    def _run_ocr(self):
        gap = max(0.06, float(FINDS_OCR_MS) / 1000.0)
        while not self._stop.is_set() and (State.running or State.paused):
            with self._lock:
                fr, self._frame = self._frame, None
            if fr is None:
                self._stop.wait(0.02)
                continue
            t0 = time.perf_counter()
            try:
                ts, arr, snap = fr
                with _ARPool():
                    cards = _cards_from_lines(_finds_ocr_array(arr),
                                              self.ore_names)
                if (FINDS_STACK_NEWEST or "bottom").lower() == "top":
                    for c in cards:
                        c["cy"] = 1.0 - c["cy"]
                    cards.sort(key=lambda c: c["cy"])
                with self._lock:
                    self._ocr_out.append((ts, cards, snap))
            except Exception:
                pass
            self._stop.wait(max(0.0, gap - (time.perf_counter() - t0)))

    # ---- adaptive floors --------------------------------------------------
    def _mint_floor(self):
        f = FINDS_BAND_MIN * 1.5
        if self._plateau > 0:
            f = max(f, 0.25 * self._plateau)
        return f

    def _leave_floor(self):
        f = FINDS_BAND_MIN * 0.75
        if self._plateau > 0:
            f = max(f, 0.10 * self._plateau)
        return f

    def _dedupe_s(self):
        """Re-sighting window: a same-identity card re-detected within one
        on-screen lifetime of an ABRUPT disappearance is the same card."""
        return max(2.0, float(FINDS_CARD_SEC)) + 1.5

    # ---- fast tick: track, classify, count, reconcile ----------------------
    def _fast_tick(self, now, bands):
        """One fast sample: associate bands to tracked cards (allowing a whole-
        stack shift), update each card's opacity trajectory, mint NEW arrivals
        (rising bands at the newest end), finalise leavers, and reconcile the
        positional count against the arrivals actually seen."""
        gap = (now - self._last_tick_t) if self._last_tick_t is not None \
            else 0.0
        self._last_tick_t = now
        p = self._pitch if self._pitch > 0 else 0.15
        tol = max(0.03, 0.4 * p)
        tracks = self._tracks
        pairs, shift = _finds_align([t["cy"] for t in tracks],
                                    [b["cy"] for b in bands], p, tol)
        matched_t = {ti for ti, _ in pairs}
        matched_b = {bi for _, bi in pairs}
        for ti, bi in pairs:
            self._feed_band(now, tracks[ti], bands[bi])

        # unmatched tracks: coast briefly (mid-life flicker), finalise leavers
        coast = max(3, int(600.0 / max(20.0, float(FINDS_FAST_MS))))
        keep, removed = [], 0
        for ti, t in enumerate(tracks):
            if ti in matched_t:
                keep.append(t)
                continue
            if t.get("synthetic"):
                if now - t.get("last_read_t", t["born"]) > 8.0:
                    self._finalize(t, now)
                    removed += 1
                else:
                    keep.append(t)
                continue
            t["miss"] += 1
            t["cy"] += shift               # ride along with the stack
            if t["miss"] > coast or (t["miss"] >= 2 and t.get("fading")
                                     and not t.get("inferred")):
                self._finalize(t, now)
                removed += 1
            else:
                keep.append(t)

        # unmatched bands: re-attach to a coasting/net card if one is close,
        # hand the band to a just-inferred card that was waiting for it, or
        # mint a brand-new arrival at the newest end
        newest = max((t["cy"] for t in keep if t["miss"] == 0),
                     default=None)   # only cards CONFIRMED this frame
        arrivals = 0
        for bi, b in enumerate(bands):
            if bi in matched_b:
                continue
            att = None
            for t in keep:
                if (t["miss"] > 0 or t.get("synthetic")) and \
                        abs(t["cy"] - b["cy"]) <= 0.6 * p and \
                        (att is None or abs(t["cy"] - b["cy"])
                         < abs(att["cy"] - b["cy"])):
                    att = t
            if att is None:
                for t in keep:
                    if t.get("inferred") and t["peak"] <= 0.0 \
                            and now - t["born"] < 1.5:
                        att = t
                        break
            if att is not None:
                att["synthetic"] = False
                att["miss"] = 0
                self._feed_band(now, att, b)
                continue
            orphan = (newest is not None and b["cy"] <= newest + 0.25 * p)
            t = self._new_track(now, b, orphan)
            keep.append(t)
            if not orphan:
                arrivals += 1
            elif all(b["cy"] < x["cy"] - 0.25 * p
                     for x in keep if x is not t):
                self._old_end_births += 1      # cards entering at the OLD end?
                if self._old_end_births == 3:
                    log("[finds] cards keep appearing at the OLD end -- if "
                        "counts run low, flip FINDS_STACK_NEWEST")
        keep.sort(key=lambda t: t["cy"])
        self._tracks = keep

        # splits: a slot whose card died and "came back" holds a NEW card --
        # finalise the old identity and restart the slot as a fresh arrival
        for t in list(self._tracks):
            b = t.pop("_split", None)
            if b is None:
                continue
            self._finalize(t, now)
            self._tracks.remove(t)
            nt = self._new_track(now, b, orphan=False)
            nt["rising"] = True            # it just rose off a dead valley
            nt["disrupt_t"] = now
            self._tracks.append(nt)
            arrivals += 1
            if FINDS_DEBUG:
                log("[finds] dbg slot rebirth at cy=%.2f -> new card"
                    % b["cy"])
        self._tracks.sort(key=lambda t: t["cy"])

        # mint: dwell + opacity floor + fade-direction (rising = arriving)
        min_dwell = max(1, int(FINDS_MIN_DWELL))
        for t in self._tracks:
            if t.get("minted") or t.get("orphan"):
                continue
            if t["seen_ticks"] < min_dwell or t["peak"] < self._mint_floor():
                continue
            if t.get("rising") or t["seen_ticks"] >= 2 * min_dwell:
                self._mint(t, now)

        # count reconciliation: if the stack shifted k slots but we saw fewer
        # arrivals (a card arrived AND started leaving between samples), the
        # difference is inferred so nothing is ever dropped silently
        k_shift = 0
        if self._pitch > 0 and len(pairs) >= 2 and shift < -0.5 * self._pitch \
                and gap > max(0.12, 2.5 * float(FINDS_FAST_MS) / 1000.0):
            k_shift = int(round(-shift / self._pitch))
        missed = min(3, k_shift - arrivals - removed)
        for _ in range(max(0, missed)):
            self._infer_find(now, k_shift, arrivals)

        # emit: a new card the moment it has an identity; after a fair chance
        # (2 OCR passes + 2.5s) even without one -- reconciliation promises
        # every counted card reaches the log
        for t in self._tracks:
            if not t.get("minted"):
                continue
            if t.get("emitted") is None:
                if t["reads"]:
                    self._emit(t, final=False)
                elif (now - t["mint_t"] > 2.5
                      and self._ocr_pass_n - t.get("mint_pass", 0) >= 2):
                    self._emit(t, final=False, force=True)

        # a long quiet spell with tracks still coasting -> the stack cleared
        if bands:
            self._no_band_since = None
        elif self._no_band_since is None:
            self._no_band_since = now
        elif (now - self._no_band_since) * 1000.0 >= max(200, FINDS_EMPTY_MS):
            for t in [t for t in self._tracks if not t.get("synthetic")]:
                self._finalize(t, now)
                self._tracks.remove(t)
            self._no_band_since = now
        self._stats_sync()
        if FINDS_DEBUG and now - self._last_dbg >= 1.0:
            self._last_dbg = now
            log("[finds] dbg bands=%d tracks=%d minted=%d shift=%+0.3f "
                "pitch=%.3f plat=%.4f"
                % (len(bands), len(self._tracks),
                   sum(1 for t in self._tracks if t.get("minted")),
                   shift, self._pitch, self._plateau))

    def _feed_band(self, now, t, b):
        """Fold one band observation into a track: position, opacity history,
        and the fade DIRECTION flags (rising = arriving, fading = leaving).
        A track that faded to a valley and then RISES again is two different
        cards -- a real card's fade-out never reverses -- so mark it for a
        split instead of letting the newcomer wear the dead card's identity."""
        if t.get("synthetic"):
            t["synthetic"] = False         # pixels see it now -> promoted
        if t.get("miss", 0) > 0:
            t["disrupt_t"] = now           # its band went away and came back
        ref = max(self._plateau, t["peak"], FINDS_BAND_MIN * 3.0)
        if t.get("fading") or t.get("valley") is not None:
            v = t.get("valley")
            t["valley"] = b["op"] if v is None else min(v, b["op"])
            if b["op"] > t["valley"] + 0.22 * ref:
                t["_split"] = dict(b)      # died and came back = a NEW card
                t["disrupt_t"] = now
        t["cy"], t["y0"], t["y1"], t["op"] = b["cy"], b["y0"], b["y1"], b["op"]
        t["ops"].append((now, b["op"]))
        del t["ops"][:-8]
        t["peak"] = max(t["peak"], b["op"])
        t["seen_ticks"] += 1
        t["miss"] = 0
        if len(t["ops"]) >= 3:
            if t["ops"][-1][1] - t["ops"][0][1] >= 0.18 * ref:
                t["rising"] = True
            a0, a1 = t["ops"][-3][1], t["ops"][-1][1]
            t["fading"] = (a1 < a0 - 0.05 * ref and a1 < 0.7 * t["peak"]
                           and t["peak"] > self._leave_floor())

    def _new_track(self, now, b, orphan):
        t = {"key": self._next_key, "cy": b["cy"], "y0": b["y0"],
             "y1": b["y1"], "op": b["op"], "ops": [(now, b["op"])],
             "peak": b["op"], "born": now, "seen_ticks": 1, "miss": 0,
             "rising": False, "fading": False, "minted": False,
             "orphan": orphan, "synthetic": False, "inferred": False,
             "ghost": False, "id": None, "mint_t": 0.0, "mint_pass": 0,
             "ocr_passes_alive": 0, "conf": 0.0, "last_read_t": now,
             "reads": [], "seen": 0, "emitted": None, "rep": None}
        self._next_key += 1
        return t

    def _mint(self, t, now):
        """A card is now COUNTED: it existed long enough, cleared the opacity
        floor, and either faded IN before our eyes or sat solid two dwells."""
        if t.get("minted"):
            return
        t["minted"] = True
        t["id"] = self._next_id
        self._next_id += 1
        t["mint_t"] = now
        t["mint_pass"] = self._ocr_pass_n
        if FINDS_DEBUG:
            log("[finds] dbg + card id=%d cy=%.3f peak=%.4f rising=%s"
                % (t["id"], t["cy"], t["peak"], t.get("rising")))

    def _infer_find(self, now, k_shift, arrivals):
        """The stack moved further than the arrivals we saw -- a card arrived
        and slipped away between samples. Mint it anyway (the shift is the
        witness), grab the freshest unclaimed OCR read as its identity if one
        exists, and flag it low-confidence."""
        base = max((t["cy"] for t in self._tracks), default=0.5)
        b = {"cy": min(0.99, base + (self._pitch or 0.15)),
             "y0": min(0.98, base + 0.5 * (self._pitch or 0.15)),
             "y1": 0.999, "op": 0.0}
        t = self._new_track(now, b, orphan=False)
        t["inferred"] = True
        t["ops"] = []
        t["peak"] = 0.0
        self._mint(t, now)
        for i in range(len(self._unbound) - 1, -1, -1):
            ts_u, c = self._unbound[i]
            if now - ts_u <= 2.0:
                self._add_read(t, c)
                del self._unbound[i]
                break
        self._tracks.append(t)
        self._tracks.sort(key=lambda x: x["cy"])
        emit_event("finds_infer",
                   reason="stack shifted %d, saw %d arrive" % (k_shift,
                                                               arrivals))
        log("[finds] reconciler: stack shifted %d but only %d seen arriving "
            "-> counted the missing card" % (k_shift, arrivals))

    # ---- identity ---------------------------------------------------------
    def _ingest_ocr(self, now, cards, snap):
        """Bind one identity pass to the tracked cards. Positions are matched
        against the band SNAPSHOT taken when this frame was grabbed (the stack
        may have shifted since). Cards no track claims feed the OCR safety
        net."""
        self._ocr_pass_n += 1
        for t in self._tracks:
            t["ocr_passes_alive"] = t.get("ocr_passes_alive", 0) + 1
        cys = sorted(c["cy"] for c in cards)
        for a, b in zip(cys, cys[1:]):     # card pitch: kg-anchor spacing
            d = b - a
            if 0.055 <= d <= 0.45:
                self._pitch = d if self._pitch <= 0 \
                    else 0.7 * self._pitch + 0.3 * d
        bykey = {t["key"]: t for t in self._tracks}
        lim = 0.5 * (self._pitch if self._pitch > 0 else 0.15)
        leftovers = []
        for c in cards:
            tt = None
            for key, y0, y1, cy in snap:            # containment first
                if y0 - 0.02 <= c["cy"] <= y1 + 0.02:
                    cand = bykey.get(key)
                    if cand is not None and (
                            tt is None or abs(cand["cy"] - c["cy"])
                            < abs(tt["cy"] - c["cy"])):
                        tt = cand
            if tt is None:                          # else nearest live track
                for t in self._tracks:
                    if t.get("orphan"):
                        continue
                    d = abs(t["cy"] - c["cy"])
                    if d <= lim and (tt is None
                                     or d < abs(tt["cy"] - c["cy"])):
                        tt = t
            if tt is not None:
                self._add_read(tt, c)
                if tt.get("synthetic"):
                    tt["cy"] = c["cy"]
            else:
                leftovers.append(c)
        for t in self._tracks:          # an orphan band with its own distinct
            if t.get("orphan") and t.get("seen", 0) >= 2:   # identity is a
                rep = t.get("rep")      # real card, not a re-surfacing of one
                if rep and not any(x is not t and x.get("rep")
                                   and _card_same(x["rep"], rep)
                                   for x in self._tracks):
                    t["orphan"] = False
        for c in self._ocr_fallback(now, leftovers, had_any=bool(cards)):
            self._unbound.append((now, dict(c)))   # claimed by NOTHING -> the
        del self._unbound[:-8]                     # reconciler may adopt one
        # identity-divergence fork: when a counted track's fresh reads
        # consistently show a DIFFERENT card (an occupant change the pixels
        # never saw -- instant eviction, missed hand-off), do NOT let the
        # majority flip rewrite the counted find. Freeze it as it stands,
        # remember it as abruptly-departed, and restart the band as a new
        # card -- which the re-sighting merge can reunite with a dead entry
        # if it is one we already counted.
        for t in self._tracks:
            em = t.get("emitted")
            reads = t.get("reads") or []
            if not em or em.get("name") == "Unknown" or len(reads) < 4:
                continue
            if now - t.get("disrupt_t", -1e9) > 1.5:
                continue    # no pixel evidence of a hand-off -> no fork (a
                            # real hand-off always shows one: the old card
                            # slides/fades, so its band dips or drops out;
                            # the row-freeze above already stops rewrites)
            tail = reads[-2:]
            if len(tail) < 2:
                continue
            ke = float(em.get("kg", 0) or 0)

            def _dis(rn, rk):
                if rn != em["name"]:
                    return True
                return rk > 0 and ke > 0 and abs(rk - ke) > 0.25 * max(rk, ke)

            if not all(_dis(rn, rk) for rn, _rm, rk, _rc in tail):
                continue
            ref0 = {"name": tail[0][0], "mod": tail[0][1], "kg": tail[0][2]}
            if not all(_card_same(ref0, {"name": rn, "mod": rm, "kg": rk})
                       for rn, rm, rk, _rc in tail[1:]):
                continue
            self._recent_dead.append(
                (now, t["cy"], {"name": em["name"], "mod": em.get("mod", ""),
                                "kg": em.get("kg", 0.0)}, False,
                 t.get("id"), dict(em)))
            del self._recent_dead[:-12]
            emit_event("finds_fork",
                       reason="%s -> %s" % (em["name"], tail[-1][0]))
            if FINDS_DEBUG:
                log("[finds] dbg identity fork at cy=%.2f: %s -> %s"
                    % (t["cy"], em["name"], tail[-1][0]))
            t["reads"] = list(tail)
            t["seen"] = len(tail)
            t["conf"] = max(float(r[3]) for r in tail)
            t["emitted"] = None
            t["minted"] = False
            t["id"] = None
            t["mint_pass"] = self._ocr_pass_n
            self._mint(t, now)
        for t in self._tracks:              # settle / first-emit on new reads
            if t.get("minted") and t["reads"]:
                self._emit(t, final=False)
        self._stats_sync()

    def _ocr_fallback(self, now, cur, had_any):
        """OCR SAFETY NET -- the previous release's sequence tracker, run only
        on cards the band tracker did NOT claim. If the pixel sampler is blind
        for this user's rendering, counting degrades to exactly the old
        behaviour instead of to zero; when the sampler works this stays
        dormant."""
        syn = [t for t in self._tracks if t.get("synthetic")]
        if not had_any:
            self._ocr_empty += 1
            if self._ocr_empty >= max(2, FINDS_EMPTY_CLEAR) and syn:
                for t in syn:
                    self._finalize(t, now)
                    self._tracks.remove(t)
            return []
        self._ocr_empty = 0
        if not cur:
            return []
        live = [t for t in self._tracks if not t.get("synthetic")]
        p = self._pitch if self._pitch > 0 else 0.15
        lim = 0.8 * p
        self._recent_dead = [d for d in self._recent_dead
                             if now - d[0] <= self._dedupe_s()]
        cur = [c for c in cur if not any(
            abs(t["cy"] - c["cy"]) <= lim
            or (abs(t["cy"] - c["cy"]) <= 2.0 * lim
                and any(_card_same({"name": rn, "mod": rm, "kg": rk}, c)
                        for rn, rm, rk, _rc in t["reads"][-8:]))
            for t in live)
            and not any(d[2] and _card_same(d[2], c)
                        and abs(d[1] - c["cy"]) <= p
                        for d in self._recent_dead)]
        if not cur:                    # (a trailing read of a card that JUST
            return []                  # left must not re-mint it as new)
        prev = syn                          # oldest -> newest already
        best_s, best_score = 0, -1
        for s in range(len(prev) + 1):
            ov = min(len(prev) - s, len(cur))
            score = sum(1 for i in range(ov)
                        if prev[s + i].get("rep")
                        and _card_same(prev[s + i]["rep"], cur[i]))
            score = score * 100 + ov - s
            if score > best_score:
                best_score, best_s = score, s
        s = best_s
        ov = min(len(prev) - s, len(cur))
        for t in prev[:s]:                  # dropped off the front -> done
            self._finalize(t, now)
            self._tracks.remove(t)
        for i in range(ov):                 # still there -> another read
            self._add_read(prev[s + i], cur[i])
            prev[s + i]["cy"] = cur[i]["cy"]
        fresh, stray = 0, []
        for j in range(ov, len(cur)):       # new tail -> new finds
            c = cur[j]
            if c["conf"] < FINDS_MIN_CONF:
                stray.append(c)             # too faint to start a find, but
                continue                    # real enough for the reconciler
            t = self._new_track(now, {"cy": c["cy"], "y0": c["cy"] - 0.05,
                                      "y1": c["cy"] + 0.05, "op": 0.0},
                                orphan=False)
            t["synthetic"] = True
            t["ops"] = []
            t["peak"] = 0.0
            self._mint(t, now)
            self._add_read(t, c)
            self._tracks.append(t)
            fresh += 1
        if fresh:
            self._tracks.sort(key=lambda t: t["cy"])
            if not self._blind_warned and not any(
                    not t.get("synthetic") for t in self._tracks):
                self._blind_warned = True
                log("[finds] counting via the OCR net only -- the pixel "
                    "sampler sees no bands; tune FINDS_WHITE_MIN / "
                    "FINDS_DARK_MAX if this persists")
        return stray

    def _add_read(self, tc, card):
        tc["reads"].append((card["name"], card["mod"], card["kg"],
                            card.get("conf", 1.0)))
        if len(tc["reads"]) > 30:
            tc["reads"] = tc["reads"][-30:]
        tc["seen"] += 1
        if tc["seen"] == 1 and not tc.get("synthetic") \
                and tc.get("peak", 0.0) > 0:
            pk = tc["peak"]                # band + identity = a real, solid
            self._plateau = pk if self._plateau <= 0 \
                else 0.7 * self._plateau + 0.3 * pk    # card: learn from it
        tc["conf"] = max(tc.get("conf", 0.0), float(card.get("conf", 0.0)))
        tc["last_read_t"] = time.perf_counter()
        tc["rep"] = {"name": card["name"], "mod": card["mod"],
                     "kg": card["kg"]}       # frame-matching representative

    def _resolve(self, tc):
        """Best (name, mod, kg, rarity) from a card's accumulated reads:
        majority ore name, majority non-blank modifier, MODE weight."""
        from collections import Counter
        reads = tc["reads"]
        names = [n for n, _m, _k, _c in reads if n]
        if not names:
            return None
        name = Counter(names).most_common(1)[0][0]
        kgs = [k for n, _m, k, _c in reads if k > 0 and n == name]
        kg0 = Counter(round(k, 1) for k in kgs).most_common(1)[0][0] \
            if kgs else 0.0
        mods = [m for n, m, k, _c in reads
                if m and n == name and (k <= 0 or kg0 <= 0
                                        or abs(k - kg0) <= 0.12 * kg0)]
        mod = Counter(mods).most_common(1)[0][0] if mods else ""
        kgs = [k for _n, _m, k, _c in reads if k > 0]
        if kgs:
            c = Counter(round(k, 1) for k in kgs)
            top = c.most_common()
            best_n = top[0][1]
            tied = sorted(v for v, n in top if n == best_n)
            kg = tied[len(tied) // 2]
        else:
            kg = 0.0
        rarity = (self.prices.get("rarity_of") or {}).get(name, "")
        return name, mod, kg, rarity

    def _finalize(self, t, now):
        """A card left the stack (or the run is wrapping up): lock in its best
        identity. A never-minted card with real reads still counts -- losing
        it would be the silent drop this tracker exists to prevent."""
        if not t.get("minted") and t.get("reads") and not t.get("orphan"):
            self._mint(t, now)
        if t.get("minted"):
            self._emit(t, final=True, force=True)
        if t.get("rep") or t.get("emitted"):
            # how it died matters: a card SEEN fading to nothing is gone for
            # good (clean); one that vanished abruptly (camera swing washing
            # out the signal, a false split, a coast timeout) may be
            # re-detected and must not be counted twice
            clean = bool(t.get("fading")) and                 t.get("op", 0.0) <= 1.5 * self._leave_floor()
            self._recent_dead.append(
                (now, t["cy"], dict(t["rep"]) if t.get("rep") else None,
                 clean,
                 t.get("id") if t.get("emitted") is not None else None,
                 t.get("emitted")))
            del self._recent_dead[:-12]
        if t.get("reads") and t.get("peak", 0.0) > 0.0 \
                and not t.get("synthetic"):
            pk = t["peak"]                  # a read+band card was truly solid:
            self._plateau = pk if self._plateau <= 0 \
                else 0.7 * self._plateau + 0.3 * pk

    def _stats_sync(self):
        st = State.stats
        if st is not None:
            st.finds_stack = sum(1 for t in self._tracks if t.get("minted"))

    # ---- emit / value -----------------------------------------------------
    def _emit(self, tc, final, force=False):
        """Emit (or update) one find. Counts once per card id; when its best
        value changes (more reads, or on departure) it re-states with the same
        id and the run stats are adjusted by the delta so totals stay exact.
        force=True also emits a counted card whose text was never readable
        ('Unknown', $0, low confidence) -- the reconciliation promise is that
        every card we counted reaches the log."""
        r = self._resolve(tc)
        if r is None:
            if not force or not tc.get("minted") or tc.get("ghost") \
                    or tc.get("emitted") is not None:
                return
            # scanned-and-empty twice with a weak band = a ghost, not a find
            # (a shift-corroborated INFERRED card is exempt: two independent
            # signals already vouched for it)
            if (not tc.get("inferred")) and tc.get("ocr_passes_alive", 0) >= 2 \
                    and (self._plateau <= 0
                         or tc.get("peak", 0.0) < 0.5 * self._plateau):
                tc["ghost"] = True
                emit_event("finds_ghost", reason="band with no readable text")
                if FINDS_DEBUG:
                    log("[finds] dbg ghost dropped (id=%s peak=%.4f)"
                        % (tc.get("id"), tc.get("peak", 0.0)))
                return
            r = ("Unknown", "", 0.0, "")
        name, mod, kg, rarity = r
        value = self._value(name, mod, rarity, kg)
        prevrec = tc.get("emitted")
        if prevrec is None and not final and not force \
                and tc.get("seen", 0) < 2:
            return    # let the identity settle one more read: the re-sighting
                      # check below needs the modifier present to match safely
        if prevrec is None and name != "Unknown":
            # RE-SIGHTING check -- smart new-vs-old, not just position: this
            # "new" card may be one we already counted whose pixel signal was
            # washed out mid-life (the camera pans behind a translucent card)
            # or that a false split re-detected. Same identity (name, weight
            # within 2%, modifier agrees) + died ABRUPTLY (never seen fading
            # out) + lifetimes that do NOT overlap + within one card lifetime
            # -> the SAME skull: update the original find, don't recount.
            # Genuine enchant duplicates coexist on screen, so their
            # lifetimes overlap and the merge is blocked.
            for i in range(len(self._recent_dead) - 1, -1, -1):
                dt_, _dcy, drep, dclean, did, dem = self._recent_dead[i]
                if did is None or dclean:
                    continue
                if not (-0.1 <= tc.get("born", 0.0) - dt_
                        <= self._dedupe_s()):
                    continue
                ident = dem or drep
                if not ident or ident.get("name") != name:
                    continue
                # a re-scan reads the SAME text -- require the weight to
                # match exactly and the modifier to MATCH exactly, and give
                # the new track two reads to settle first (its modifier may
                # lag one read behind)
                if tc.get("seen", 0) < 2:
                    continue
                if round(float(ident.get("kg", 0) or 0), 1) != round(kg, 1):
                    continue
                if mod != ident.get("mod", ""):
                    continue
                tc["id"] = did
                tc["emitted"] = prevrec = dem
                del self._recent_dead[i]
                emit_event("finds_resight",
                           reason="same card re-detected -> merged")
                log("[finds] re-sighted an already-counted card -> "
                    "updating find #%s, not recounting" % did)
                break
        if prevrec and (prevrec["name"], prevrec["mod"], round(prevrec["kg"], 1)) \
                == (name, mod, round(kg, 1)) and not final:
            return                             # nothing changed
        if prevrec is not None and prevrec.get("name") != "Unknown":
            pk = float(prevrec.get("kg", 0) or 0)
            if name != prevrec.get("name") or (
                    pk > 0 and kg > 0
                    and abs(kg - pk) > 0.25 * max(kg, pk)):
                return    # an emitted find NEVER rewrites into a different
                          # card (back-to-back skulls used to overwrite each
                          # other); the divergence fork below decides whether
                          # a new card took this slot instead
        st = State.stats
        mmul = (self.prices.get("modifier_mult") or {}).get(mod, 1.0) if mod else 1.0
        conf = round(float(tc.get("conf", 0.0)), 2)
        lc = bool(name == "Unknown" or conf < 0.30)
        rec = {"id": tc["id"],
               "t": round(State.stats.runtime(), 1) if State.stats else 0,
               "mod": mod, "name": name, "kg": kg, "rarity": rarity,
               "value": int(value), "mmul": float(mmul), "conf": conf}
        if prevrec is None:
            if st is not None:
                st.finds_count += 1
                st.find_kg += kg
                st.best_kg = max(st.best_kg, kg)
                st.by_rarity[rarity or "?"] = st.by_rarity.get(rarity or "?", 0) + 1
                st.by_mod[mod or "plain"] = st.by_mod.get(mod or "plain", 0) + 1
                st.loot_value += value
                if lc:
                    st.finds_lowconf += 1
            print("__FIND__ " + json.dumps(rec), flush=True)
            log("[finds] %s%s %skg %s%s%s"
                % ((mod + " ") if mod else "", name, kg, rarity,
                   (" ~$%s" % f"{int(value):,}") if value else "",
                   " (low conf)" if lc else ""))
        else:
            if st is not None:                 # correct the totals by the delta
                st.find_kg += kg - prevrec["kg"]
                st.best_kg = max(st.best_kg, kg)
                st.loot_value += value - prevrec["value_f"]
                if (prevrec["rarity"] or "?") != (rarity or "?"):
                    st.by_rarity[prevrec["rarity"] or "?"] = max(
                        0, st.by_rarity.get(prevrec["rarity"] or "?", 1) - 1)
                    st.by_rarity[rarity or "?"] = st.by_rarity.get(rarity or "?", 0) + 1
                if (prevrec["mod"] or "plain") != (mod or "plain"):
                    st.by_mod[prevrec["mod"] or "plain"] = max(
                        0, st.by_mod.get(prevrec["mod"] or "plain", 1) - 1)
                    st.by_mod[mod or "plain"] = st.by_mod.get(mod or "plain", 0) + 1
                if lc != prevrec.get("lc", False):
                    st.finds_lowconf = max(
                        0, st.finds_lowconf + (1 if lc else -1))
            print("__FIND_UPD__ " + json.dumps(rec), flush=True)
        tc["emitted"] = {"name": name, "mod": mod, "kg": kg,
                         "rarity": rarity, "value_f": float(value), "lc": lc}

    def _value(self, name, mod, rarity, kg):
        """Estimated sale value of one KEPT find (v2.6 money model):
            per_kg * kg * modifier_mult * rarity_mult * (1 + SellBoost/100)
        Only finds at/above FINDS_BANK_RARITY are valued -- lower ones auto-sell
        and are already counted by the money reader, so valuing them here would
        double-count. per_kg is the literal wiki base $/kg (what ONE item sells
        for) -- never the model's aggregate-scaled value."""
        p = self.prices or {}
        # bank rarity floor: below it -> auto-sold -> already in the money OCR
        eff_rarity = rarity or (p.get("rarity_of") or {}).get(name, "")
        if not _rarity_at_least(eff_rarity, FINDS_BANK_RARITY):
            return 0.0
        per = (p.get("per_kg") or {}).get(name, 0)
        if not per:
            return 0.0
        rmul = float((p.get("rarity_mult") or {}).get(eff_rarity, 1.0))
        mmul = float((p.get("modifier_mult") or {}).get(mod, 1.0)) if mod else 1.0
        bank = float((p.get("bank_mult") or {}).get(name, 1.0))
        sb = (p.get("per_item_sell_boost") or {}).get(name)
        sb = float(sb) if sb is not None else float(SELL_BOOST_PCT)
        return float(per) * kg * rmul * mmul * bank * (1.0 + sb / 100.0)

def _best_match(s, options, cutoff=0.6):
    """Nearest string in `options` by difflib ratio, or None below cutoff."""
    import difflib
    s = (s or "").strip().lower()
    if not s or not options:
        return None
    best, score = None, cutoff
    for o in options:
        r = difflib.SequenceMatcher(None, s, o.lower()).ratio()
        if r >= score:
            best, score = o, r
    return best


def _snap_name(raw, ore_names):
    """Snap an OCR'd item string to (canonical_name, modifier).
    Ores are 1-2 words; modifiers are a leading word. Tries the last two
    words and the last word against the ore list, and the first word against
    the modifier list -- so 'Irradlatod Divoscrur Shall' -> (Dinosaur Skull,
    Irradiated) even with heavy OCR noise."""
    words = (raw or "").split()
    if not words:
        return None, ""
    # ore name: best of last-2-words and last-1-word
    cands = []
    if len(words) >= 2:
        cands.append(" ".join(words[-2:]))
    cands.append(words[-1])
    if len(words) >= 3:
        cands.append(" ".join(words[-3:]))
    name = None
    for c in cands:
        m = _best_match(c, ore_names, cutoff=0.55)
        if m:
            name = m
            break
    if name is None:
        name = raw.strip().title()          # unknown ore: keep cleaned raw
    # modifier: first word vs the known tiers
    mod = ""
    if len(words) > 1:
        mm = _best_match(words[0], list(_MODIFIERS), cutoff=0.6)
        if mm:
            mod = mm
    return name, mod


_KG_RE = __import__("re").compile(r"(\d[\d,\. ]*)\s*k\s*g", __import__("re").I)


def _finds_ocr_array(arr):
    """OCR one grabbed finds-region frame (HxWx3 uint8, RGB) with position +
    confidence per text line -- the same pixels the fast sampler measured, so
    one grab feeds both the opacity signal and the identity OCR.

    Returns [{t, cy, conf, h}] where cy is the line's vertical centre as a
    TOP-DOWN normalised fraction (0 = top of region, 1 = bottom), conf is the
    recognition confidence (0..1 -> a fade/freshness proxy: a bright new card
    reads with high confidence, a faded one lower), h is the line height
    (normalised). Everything is LOCATION-based inside the calibrated box -- no
    dependence on the terrain colour behind the cards."""
    import mss.tools
    h, w = int(arr.shape[0]), int(arr.shape[1])
    big = arr.repeat(3, axis=0).repeat(3, axis=1)     # 3x upscale (readable)
    png = mss.tools.to_png(big.tobytes(), (w * 3, h * 3))
    from Foundation import NSData
    import Vision
    data = NSData.dataWithBytes_length_(png, len(png))
    handler = Vision.VNImageRequestHandler.alloc().initWithData_options_(
        data, None)
    req = Vision.VNRecognizeTextRequest.alloc().init()
    try:
        req.setRecognitionLevel_(0)          # accurate (small HUD text)
        req.setUsesLanguageCorrection_(False)
    except Exception:
        pass
    handler.performRequests_error_([req], None)
    out = []
    for obs in (req.results() or []):
        try:
            cand = obs.topCandidates_(1)[0]
            bb = obs.boundingBox()           # normalised, origin BOTTOM-left
            oy, hh = float(bb.origin.y), float(bb.size.height)
            cy = 1.0 - (oy + hh / 2.0)       # -> top-down fraction
            conf = float(getattr(cand, "confidence", lambda: 1.0)()) \
                if callable(getattr(cand, "confidence", None)) \
                else float(getattr(obs, "confidence", 1.0))
            out.append({"t": str(cand.string()), "cy": cy, "conf": conf,
                        "h": hh})
        except Exception:
            continue
    out.sort(key=lambda d: d["cy"])          # top -> bottom
    return out


def _cards_from_lines(lines, ore_names):
    """Group OCR lines into ITEM CARDS in the finds stack. Each card carries a
    weight ('NNN kg'), a name and (usually) a rarity word on nearby lines; the
    stack holds several fading cards at once, so we anchor on each 'kg' line
    (exactly one per card) and attach the nearest name/rarity lines to it.

    Returns cards ordered TOP -> BOTTOM: each {name, mod, kg, rarity, cy, conf}.
    A card whose weight can't be read this frame is skipped (it's read on other
    frames while it lingers in the stack)."""
    if not lines:
        return []
    hs = [d["h"] for d in lines if d["h"] > 0]
    line_h = sorted(hs)[len(hs) // 2] if hs else 0.05
    win = max(2.6 * line_h, 0.12)            # a card spans ~2-3 text lines
    rar_low = {r.lower(): r for r in _RARITIES}
    cards = []
    for d in lines:
        t = (d["t"] or "").strip()
        if "$" in t or t.startswith("+"):
            continue
        m = _KG_RE.search(t)
        if not m:
            continue
        try:
            kg = float(m.group(1).replace(",", "").replace(" ", ""))
        except ValueError:
            continue
        if kg <= 0 or kg > 100000:
            continue
        cy = d["cy"]
        # name: text before 'kg' on this line, else nearest wordy line ABOVE
        inline = _KG_RE.sub("", t).strip(" -\u00b7:")
        name_txt, rarity = "", ""
        if sum(c.isalpha() for c in inline) >= 3 \
                and inline.lower() not in rar_low:
            name_txt = inline
        best_name_d = 9.0
        best_rar_d = 9.0
        for e in lines:
            dy = abs(e["cy"] - cy)
            if dy > win:
                continue
            et = (e["t"] or "").strip()
            low = et.lower()
            if low in rar_low and dy < best_rar_d:
                rarity, best_rar_d = rar_low[low], dy
            elif not name_txt or e["cy"] <= cy:
                clean = _KG_RE.sub("", et).strip(" -\u00b7:")
                if (sum(c.isalpha() for c in clean) >= 3
                        and clean.lower() not in rar_low
                        and "$" not in clean and not clean.startswith("+")):
                    # prefer the line just above the kg (dy small, above)
                    score = dy + (0.0 if e["cy"] <= cy else 0.5)
                    if score < best_name_d:
                        name_txt, best_name_d = clean, score
        if not name_txt:
            continue
        name, mod = _snap_name(name_txt, ore_names)
        if not name:
            continue
        if not rarity:
            rarity = ""              # filled from the price table later by name
        cards.append({"name": name, "mod": mod, "kg": kg, "rarity": rarity,
                      "cy": cy, "conf": d["conf"]})
    cards.sort(key=lambda c: c["cy"])        # top -> bottom
    return cards


def _card_same(a, b):
    """Fuzzy equality of two card reads (same physical card across frames):
    same ore name, weight within 12%, and modifier agrees (or one is blank)."""
    if a["name"] != b["name"]:
        return False
    ka, kb = a["kg"], b["kg"]
    if ka > 0 and kb > 0 and abs(ka - kb) > 0.12 * max(ka, kb):
        return False
    if a["mod"] and b["mod"] and a["mod"] != b["mod"]:
        return False
    return True


# which per-event toggle gates each event name
_EVENT_FLAG = {
    "start": "NOTIFY_START",
    "stop": "NOTIFY_STOP", "autostop": "NOTIFY_STOP", "bag_full": "NOTIFY_STOP",
    "stats": "NOTIFY_STATS",
    "safe_stop": "NOTIFY_SAFE_STOP",
    "recovery": "NOTIFY_RECOVERIES",
    "error": "NOTIFY_ERRORS",
}


def _grab_screenshot_b64():
    """Grab the screen, downscale, and return a base64 PNG (or None). Used to
    attach a picture to Discord alerts so you can see what happened remotely."""
    try:
        import base64
        import mss.tools
        with _MSS() as sct:
            raw = sct.grab(sct.monitors[1])
        arr = np.asarray(raw)                      # (h, w, 4) BGRA
        h, w = arr.shape[0], arr.shape[1]
        scale = max(1, int(round(w / float(SHOT_TARGET_W or w))))
        small = arr[::scale, ::scale]
        rgb = small[:, :, (2, 1, 0)].tobytes()     # BGR(A) -> RGB
        png = mss.tools.to_png(rgb, (small.shape[1], small.shape[0]))
        return base64.b64encode(png).decode("ascii")
    except Exception as e:
        print("[webhook] screenshot failed: %s" % e)
        return None


def _webhook_payload(event, message, stats=None):
    """Build the notification payload: content + a Discord embed carrying the
    user/event/stats (plain webhooks drop unknown JSON keys, so anything a
    relay bot or the owner needs to SEE must live in the embed), plus the raw
    fields for a custom relay reading the POST body directly."""
    st = stats or {}
    fields = [{"name": "User", "value": str(WEBHOOK_USER or "(not set)")[:100],
               "inline": True},
              {"name": "Event", "value": str(event)[:60], "inline": True}]
    bits = []
    if st.get("cycles") is not None:
        bits.append("%s pans" % st.get("cycles"))
    if st.get("pans_per_hr"):
        bits.append("%s/hr" % st.get("pans_per_hr"))
    if st.get("runtime_s"):
        bits.append("%dm" % int(int(st.get("runtime_s") or 0) / 60))
    if st.get("recoveries") is not None:
        bits.append("%s rec" % st.get("recoveries"))
    if bits:
        fields.append({"name": "Stats", "value": " / ".join(bits)[:200],
                       "inline": True})
    embed = {"title": "Prospectors Plus", "description": str(message)[:1500],
             "color": 0xC2924C, "fields": fields}
    return {"username": "Prospectors Plus", "content": str(message)[:1900],
            "embeds": [embed], "event": event, "user": WEBHOOK_USER,
            "stats": st}


def _webhook_send(url, payload, img_b64=None):
    """Deliver a payload to a webhook URL, blocking. Attaches the screenshot
    as a real multipart file upload (attachment://shot.png) so it renders in
    Discord. Retries once without SSL verification because the bundled macOS
    Python often ships without certificates. Returns (ok, error_string)."""
    import ssl as _ssl
    try:
        if img_b64:
            payload["screenshot"] = img_b64          # the bot decodes + attaches it
            payload["screenshot_format"] = "png"
        data = json.dumps(payload).encode("utf-8")
        headers = {"Content-Type": "application/json",
                   "User-Agent": "ProspectorsPlus/1.0"}
        if WEBHOOK_SECRET:
            headers["x-macro-secret"] = WEBHOOK_SECRET
        req = urllib.request.Request(url, data=data, headers=headers)
        try:
            urllib.request.urlopen(req, timeout=8)
        except Exception as e1:
            if getattr(e1, "code", None):          # a real HTTP rejection
                return False, "HTTP %s" % e1.code
            urllib.request.urlopen(req, timeout=8,
                                   context=_ssl._create_unverified_context())
        return True, ""
    except Exception as e:
        return False, str(e)


def post_webhook(event, message, stats=None, shot=False):
    """Fire a notification (non-blocking). Uses WEBHOOK_URL, or SYNC_URL when
    that is empty, so shipped builds notify without extra setup. Honours the
    per-event NOTIFY_* toggles so users get only the DMs they want."""
    url = (WEBHOOK_URL or "").strip()
    if not WEBHOOK_ENABLED or not url:
        if WEBHOOK_ENABLED and not url:
            print("[webhook] no WEBHOOK_URL set -- user notification dropped "
                  "(owner analytics never uses this path)")
        return
    flag = _EVENT_FLAG.get(event)
    if flag and not globals().get(flag, True):
        return
    payload = _webhook_payload(event, message, stats)
    img = _grab_screenshot_b64() if (shot and NOTIFY_SCREENSHOT) else None
    if img:
        payload["screenshot"] = img            # legacy relay-bot field

    def _send():
        ok, err = _webhook_send(url, payload, img)
        if not ok:
            print(f"[webhook] failed: {err}")

    threading.Thread(target=_send, daemon=True).start()


def release_all():
    try:
        key_up(KEY_W)
        key_up(KEY_S)
        mouse_up()
    except Exception:
        pass


def fortune_river_recover():
    """SOFT-STOP recovery: fast-travel back to Fortune River, walk into the
    water, and resume the normal loop. Returns True if it found the row and
    reached the dig spot, False if the Fortune River entry was never located
    (the caller then hard-stops)."""
    det = State.detector
    if det is None:
        return False
    sct = det.sct
    top = min(FR_BOX_TOP, FR_BOX_BOTTOM)
    bot = max(FR_BOX_TOP, FR_BOX_BOTTOM)
    found = False
    for open_try in range(max(1, FR_OPEN_TRIES)):
        if not State.running:
            return False
        log("FR-recover: opening Fast Travel (try %d) ..." % (open_try + 1))
        release_all()
        # switch to the fast-travel hotbar slot, then DOUBLE-CLICK to open the menu
        tap_key(SLOT_KEYCODES.get(FR_OPEN_SLOT), 40)
        sleep_ms(FR_ACTION_GAP_MS)
        mouse_tap(40)
        sleep_ms(FR_DOUBLE_GAP_MS)
        mouse_tap(40)
        sleep_ms(FR_OPEN_MS)
        tap_key(KEY_SHIFT, 60)                        # exit shift-lock so the mouse can move
        sleep_ms(FR_ACTION_GAP_MS)
        fr_reset_home()                               # cursor is now at the screen centre
        if FR_OPEN_PIXEL and (FR_OPEN_PIXEL[0] or FR_OPEN_PIXEL[1]):
            fr_move_to(FR_OPEN_PIXEL[0], FR_OPEN_PIXEL[1])
            sleep_ms(FR_CLICK_SETTLE_MS)
            mouse_tap(50)
            sleep_ms(FR_OPEN_MS)
        for attempt in range(max(1, FR_FIND_TRIES)):
            if not State.running:
                return False
            fr_move_to(FR_SCAN_X, top)                # go to the x column, top of box
            sleep_ms(FR_CLICK_SETTLE_MS)
            y = top
            while y <= bot:                           # sweep the cursor DOWN the column
                fr_move_to(FR_SCAN_X, y)
                sleep_ms(FR_SCAN_HOVER_MS)
                if _rgb_match(rgb_at(sct, FR_SCAN_X, y), FR_TEXT_RGB, FR_TEXT_TOL):
                    sleep_ms(FR_CLICK_SETTLE_MS)
                    mouse_tap(60)
                    sleep_ms(FR_CLICK_SETTLE_MS)
                    found = True
                    log("FR-recover: found Fortune River at y=%d" % y)
                    break
                y += max(1, FR_SCAN_STEP)
            if found:
                break
            scroll_down(FR_SCROLL_STEPS)              # only scroll after a full sweep finds nothing
            sleep_ms(FR_SCROLL_WAIT_MS)
        if found:
            break
        # nothing found in a full pass -> the menu probably did not open; re-lock and retry
        tap_key(KEY_SHIFT, 60)
        sleep_ms(FR_ACTION_GAP_MS)
    if not found:
        log("FR-recover: Fortune River row NOT found -- hard stop")
        return False
    sleep_ms(FR_WARP_MS)                              # wait for teleport/load
    tap_key(SLOT_KEYCODES.get(FR_PAN_SLOT), 60)       # back to the pan
    sleep_ms(FR_ACTION_GAP_MS)
    tap_key(KEY_SHIFT, 60)                            # re-enter shift-lock before digging
    sleep_ms(FR_ACTION_GAP_MS)
    tap_key(KEY_D, max(1, FR_STRAFE_MS))              # tiny strafe to line up
    sleep_ms(FR_ACTION_GAP_MS)
    key_down(KEY_W)                                   # walk forward ACROSS the water
    # 1) must reach the WATER first (sustained Pan cue) -- proves we left the
    #    spawn shore and are genuinely crossing, not still on the near shore
    in_water = wait_until(det.on_pan, FR_WALK_MAX_MS, confirm=FR_CROSS_CONFIRM)
    # 2) ONLY after crossing the water do we accept the next shore's Collect cue
    if in_water:
        wait_until(det.on_deposit, FR_WALK_MAX_MS, confirm=FR_CROSS_CONFIRM)
    else:
        log("FR-recover: never saw the water (Pan) -- check walk direction")
    key_up(KEY_W)
    if FR_END_A_MS > 0:
        tap_key(KEY_A, FR_END_A_MS)                  # final A nudge before restarting
    log("FR-recover: reached the dig spot -- resuming")
    return True



def starfall_river_recover():
    """SOFT-STOP recovery for STARFALL RIVER. Identical Fast-Travel machinery
    to Fortune River (shared menu geometry + timings), matching the Starfall
    row by ITS calibrated colour. Post-warp walk: strafe A until the Pan cue
    while TIMING it, back off D for SR_D_PCT%% of that time (centres you on
    the strip), then S until the Pan cue again -- that's the dig spot."""
    det = State.detector
    if det is None:
        return False
    if not any(SR_TEXT_RGB):
        log("SR-recover: Starfall row colour not calibrated (Calibrate tab)")
        return False
    sct = det.sct
    top = min(FR_BOX_TOP, FR_BOX_BOTTOM)
    bot = max(FR_BOX_TOP, FR_BOX_BOTTOM)
    found = False
    for open_try in range(max(1, FR_OPEN_TRIES)):
        if not State.running:
            return False
        log("SR-recover: opening Fast Travel (try %d) ..." % (open_try + 1))
        release_all()
        tap_key(SLOT_KEYCODES.get(FR_OPEN_SLOT), 40)
        sleep_ms(FR_ACTION_GAP_MS)
        mouse_tap(40)
        sleep_ms(FR_DOUBLE_GAP_MS)
        mouse_tap(40)
        sleep_ms(FR_OPEN_MS)
        tap_key(KEY_SHIFT, 60)                    # exit shift-lock (free mouse)
        sleep_ms(FR_ACTION_GAP_MS)
        fr_reset_home()
        if FR_OPEN_PIXEL and (FR_OPEN_PIXEL[0] or FR_OPEN_PIXEL[1]):
            fr_move_to(FR_OPEN_PIXEL[0], FR_OPEN_PIXEL[1])
            sleep_ms(FR_CLICK_SETTLE_MS)
            mouse_tap(50)
            sleep_ms(FR_OPEN_MS)
        for attempt in range(max(1, FR_FIND_TRIES)):
            if not State.running:
                return False
            fr_move_to(FR_SCAN_X, top)
            sleep_ms(FR_CLICK_SETTLE_MS)
            y = top
            while y <= bot:
                fr_move_to(FR_SCAN_X, y)
                sleep_ms(FR_SCAN_HOVER_MS)
                if _rgb_match(rgb_at(sct, FR_SCAN_X, y), SR_TEXT_RGB,
                              SR_TEXT_TOL):
                    sleep_ms(FR_CLICK_SETTLE_MS)
                    mouse_tap(60)
                    sleep_ms(FR_CLICK_SETTLE_MS)
                    found = True
                    log("SR-recover: found Starfall River at y=%d" % y)
                    break
                y += max(1, FR_SCAN_STEP)
            if found:
                break
            scroll_down(FR_SCROLL_STEPS)
            sleep_ms(FR_SCROLL_WAIT_MS)
        if found:
            break
        tap_key(KEY_SHIFT, 60)                    # re-lock and retry the open
        sleep_ms(FR_ACTION_GAP_MS)
    if not found:
        log("SR-recover: Starfall River row NOT found -- hard stop")
        return False
    sleep_ms(FR_WARP_MS)                          # teleport / world load
    tap_key(SLOT_KEYCODES.get(FR_PAN_SLOT), 60)   # back to the pan
    sleep_ms(FR_ACTION_GAP_MS)
    tap_key(KEY_SHIFT, 60)                        # re-enter shift-lock
    sleep_ms(FR_ACTION_GAP_MS)
    key_down(KEY_A)                               # strafe toward the river,
    _t0 = time.perf_counter()                     # TIMING the distance
    saw_a = wait_until(det.on_pan, SR_A_MAX_MS, confirm=FR_CROSS_CONFIRM)
    a_ms = (time.perf_counter() - _t0) * 1000.0
    key_up(KEY_A)
    if not saw_a:
        log("SR-recover: A-strafe never saw the water -- check the warp facing")
        return False
    sleep_ms(FR_ACTION_GAP_MS)
    back = max(1, int(a_ms * SR_D_PCT / 100.0))
    tap_key(KEY_D, back)                          # back off a fraction of it
    log("SR-recover: water after %.0fms of A -> D back %dms" % (a_ms, back))
    sleep_ms(FR_ACTION_GAP_MS)
    key_down(KEY_S)                               # into the water at the spot
    in_water = wait_until(det.on_pan, SR_S_MAX_MS, confirm=FR_CROSS_CONFIRM)
    key_up(KEY_S)
    if not in_water:
        log("SR-recover: never saw the water (Pan) -- tune SR A/S lengths")
        return False
    log("SR-recover: in the water at the dig spot -- resuming")
    return True


def safe_stop(reason, hard=False):
    """A hazard/stuck was detected. By DEFAULT pause and retry shortly instead of
    hard-stopping (so an AFK run recovers itself); only hard-stop after
    SAFE_STOP_MAX_RETRIES failed retries in a row."""
    release_all()
    State.empty_fails = State.shake_fails = State.land_fails = State.breakouts = 0
    if State.stats:
        State.stats.safe_stops += 1
    emit_event("hard_stop" if hard else "safe_stop", reason)

    if SR_RECOVERY and not hard:
        try:
            ok = starfall_river_recover()
        except Exception as e:
            log("SR-recover error: %s" % e)
            ok = False
        if ok:
            State.safe_retries = 0
            State.want_reset = True
            emit_event("sr_recover", "success after: %s" % reason)
            print("\n*** STARFALL RIVER RECOVERY: %s -> resumed ***" % reason)
            post_webhook("safe_stop",
                         "\U0001f30a Starfall River recovery (%s) -> resumed"
                         % reason,
                         State.stats.as_dict() if State.stats else None,
                         shot=True)
            return
    if FR_RECOVERY and not hard:
        try:
            ok = fortune_river_recover()
        except Exception as e:
            log("FR-recover error: %s" % e)
            ok = False
        if ok:
            State.safe_retries = 0
            State.want_reset = True
            emit_event("fr_recover", "success after: %s" % reason)
            print("\n*** FORTUNE RIVER RECOVERY: %s -> resumed ***" % reason)
            post_webhook("safe_stop",
                         "\U0001f9ed Fortune River recovery (%s) -> resumed" % reason,
                         State.stats.as_dict() if State.stats else None, shot=True)
            return
        emit_event("fr_recover", "failed after: %s" % reason)

    def _beep(hand=False):
        try:
            import winsound
            winsound.MessageBeep(winsound.MB_ICONHAND if hand
                                 else winsound.MB_ICONASTERISK)
        except Exception:
            try:
                subprocess.Popen(["afplay", globals().get("ALERT_SOUND", "")])
            except Exception:
                print("\a", end="", flush=True)

    if SAFE_STOP_RETRY and State.safe_retries < SAFE_STOP_MAX_RETRIES and not hard:
        State.safe_retries += 1
        msg = (f"{reason} - retrying in {SAFE_STOP_RETRY_SEC}s "
               f"(attempt {State.safe_retries}/{SAFE_STOP_MAX_RETRIES})")
        print(f"\n*** SAFE PAUSE: {msg} ***")
        post_webhook("safe_stop", f"⚠️ Safe-paused: {msg}",
                     State.stats.as_dict() if State.stats else None, shot=True)
        _beep(False)
        end = time.perf_counter() + SAFE_STOP_RETRY_SEC
        while time.perf_counter() < end and State.running and State.alive:
            time.sleep(0.2)
        State.want_reset = True
        return
    State.running = False
    State.safe_retries = 0
    State.stop_reason = "safe-stop"
    if State.stats:
        State.stats.hard_stops += 1
        State.stats.stop_reason = "safe-stop"
    print(f"\n*** HARD STOP: {reason} ***  (Ctrl+K to resume, Esc to quit)")
    post_webhook("stop", f"🛑 Hard-stopped: {reason}",
                 State.stats.as_dict() if State.stats else None, shot=True)
    _beep(True)


def append_history(stats, reason):
    """Append a finished run's summary to run_history.json (kept to last 100) so
    the user can review past runs after the app/macro closes."""
    try:
        import datetime
        path = os.path.join(_DATA_DIR, "run_history.json")
        hist = []
        if os.path.exists(path):
            try:
                hist = json.load(open(path))
            except Exception:
                hist = []
        d = stats.as_dict() if stats else {}
        d["reason"] = reason
        d["ended"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        hist.append(d)
        with open(path, "w") as f:
            json.dump(hist[-100:], f, indent=2)
    except Exception as e:
        print("[history] save failed:", e)


# ---- Smart adaptive timing (trial & error; opt-in) --------------------------
def smart_adapt():
    """Hill-climb two timings from real miss rates. Direction defaults to MORE
    distance (go deeper into the water / further onto land); if a step makes the
    miss rate worse next window, it reverses. No-op unless SMART_TIMING."""
    if not SMART_TIMING:
        return
    g = globals()
    if State.ad_shake_n >= ADAPT_WINDOW:
        rate = 100.0 * State.ad_shake_miss / max(1, State.ad_shake_n)
        if rate > ADAPT_MISS_PCT:
            if State.ad_water_prev is not None and rate > State.ad_water_prev:
                State.ad_water_dir *= -1
            nv = max(0, min(600, g["WATER_EXTRA_BACK_MS"]
                            + State.ad_water_dir * ADAPT_STEP_MS))
            g["WATER_EXTRA_BACK_MS"] = nv
            log(f"[smart] shake miss {rate:.0f}% -> WATER_EXTRA_BACK_MS={nv}ms")
        State.ad_water_prev = rate
        State.ad_shake_n = State.ad_shake_miss = 0
    if State.ad_land_n >= ADAPT_WINDOW:
        rate = 100.0 * State.ad_land_miss / max(1, State.ad_land_n)
        if rate > ADAPT_MISS_PCT:
            if State.ad_land_prev is not None and rate > State.ad_land_prev:
                State.ad_land_dir *= -1
            nv = max(0, min(600, g["LAND_SETTLE_MS"]
                            + State.ad_land_dir * ADAPT_STEP_MS))
            g["LAND_SETTLE_MS"] = nv
            log(f"[smart] land miss {rate:.0f}% -> LAND_SETTLE_MS={nv}ms")
        State.ad_land_prev = rate
        State.ad_land_n = State.ad_land_miss = 0


def _adapt_shake(emptied):
    if not SMART_TIMING:
        return
    State.ad_shake_n += 1
    if not emptied:
        State.ad_shake_miss += 1
    smart_adapt()


def _adapt_land(missed):
    if not SMART_TIMING:
        return
    State.ad_land_n += 1
    if missed:
        State.ad_land_miss += 1
    smart_adapt()


# ---- Cycle parts ------------------------------------------------------------
def dig_once(detector):
    """One dig. PERFECT=False -> quick click; PERFECT=True -> release on green.
    The hold length is DIG_CLICK_MS, which the UI auto-fills from DIG_SPEED
    (so the scaling is done once, in the UI, not again here)."""
    if State.stats:
        State.stats.dig_clicks += 1  # attempts; REGISTERED digs counted on rise
    if not PERFECT:
        mouse_down()
        sleep_ms(DIG_CLICK_MS)
        mouse_up()
        return
    # PERFECT: hold LMB and release when the white line crosses the green pixel
    mouse_down()
    deadline = time.perf_counter() + DIG_MAX_MS / 1000.0
    while State.running and time.perf_counter() < deadline:
        if detector.white_on_trigger():
            break
        # poll as fast as possible; the line can move quickly
    if RELEASE_DELAY_MS:
        sleep_ms(RELEASE_DELAY_MS)
    mouse_up()


def dig_until_started(detector):
    """Dig once, then wait until the cap bar STARTS filling so we move at the
    right moment. Proceeds anyway after CAP_START_MS. (No nudging.)"""
    baseline = detector.cap_start_rgb()             # empty-bar colour pre-dig
    dig_once(detector)
    wait_until(lambda: detector.cap_changed(baseline), CAP_START_MS, confirm=1)
    return True


def wait_until(cond, max_ms, confirm=1, min_ms=0):
    """Poll cond() until it is True for `confirm` reads in a row, or max_ms
    elapses. Ignores reads during the first `min_ms` (lets you clear the
    boundary / startup tint pulse before detection counts)."""
    start = time.perf_counter()
    deadline = start + max_ms / 1000.0
    gate = start + min_ms / 1000.0
    hits = 0
    while State.running and time.perf_counter() < deadline:
        if time.perf_counter() < gate:
            continue
        if cond():
            hits += 1
            if hits >= confirm:
                return True
        else:
            hits = 0
    return False


def pulse_until(key, cond, max_ms, confirm=1):
    """Move in short TAPS (BURST_ON_MS held, BURST_OFF_MS released) and re-check
    cond() after every tap. Stops the instant cond is True for `confirm` taps in
    a row, or when max_ms of total budget is spent. No long blind key-holds, so
    it can't sail past the target between sensor reads."""
    deadline = time.perf_counter() + max_ms / 1000.0
    hits = 0
    while State.running and time.perf_counter() < deadline:
        key_down(key); sleep_ms(BURST_ON_MS); key_up(key)
        sleep_ms(BURST_OFF_MS)
        if cond():
            hits += 1
            if hits >= confirm:
                return True
        else:
            hits = 0
    return False


def walk_back(detector):
    key_down(KEY_S)                 # back up
    if USE_TERRAIN_DETECT:
        wait_until(detector.on_wet, WALK_BACK_MAX_MS,
                   confirm=TERRAIN_CONFIRM, min_ms=WALK_BACK_MIN_MS)
    else:
        sleep_ms(WALK_BACK_MS)
    key_up(KEY_S)


def momentum_and_shake(detector):
    key_down(KEY_W)                 # walk forward; momentum carries onto dirt
    mouse_tap(SHAKE_START_MS)       # tap LMB to start the shake animation
    if USE_TERRAIN_DETECT:
        wait_until(detector.on_dirt, MOMENTUM_MAX_MS,
                   confirm=TERRAIN_CONFIRM, min_ms=MOMENTUM_MIN_MS)
    else:
        remaining = MOMENTUM_W_MS - SHAKE_START_MS
        if remaining > 0:
            sleep_ms(remaining)
    key_up(KEY_W)


def shake_empty():
    mouse_down()
    sleep_ms(SHAKE_HOLD_MS)
    mouse_up()


def recover_to_dirt(detector):
    """Drifted into the liquid -> walk forward until back on dirt."""
    key_down(KEY_W)
    wait_until(detector.on_dirt, RECOVER_MAX_MS, confirm=TERRAIN_CONFIRM)
    key_up(KEY_W)


def timed_empty(detector=None):
    """CUE-DRIVEN empty (no fixed-time movement):
       1) hold S until the PAN cue shows (you're in the water),
       2) CLICK to initiate -> short gap -> HOLD to shake until the CAPACITY is
          empty (the cue stays stuck on 'Shake', so empty is the 'done' signal),
       3) hold W until the COLLECT DEPOSIT cue shows (back on land).
    Returns False if the shake never initiated (Collect Deposit + full)."""
    if detector is None:
        return True
    # 1) walk back until the PAN cue (in the water), then BRAKE the backward
    #    glide with a short forward W tap so we stop at the water edge.
    key_down(KEY_S)
    reached = wait_until(detector.on_pan, PAN_BACK_MAX_MS, confirm=WALK_BACK_CONFIRM)
    key_up(KEY_S)
    if reached and WALK_BACK_BRAKE_MS > 0:
        key_down(KEY_W); sleep_ms(WALK_BACK_BRAKE_MS); key_up(KEY_W)
    if not State.running: return True
    # 2) shake: CLICK to initiate -> gap -> HOLD until the capacity empties
    mouse_tap(SHAKE_CLICK_MS)
    sleep_ms(SHAKE_INIT_GAP_MS)
    mouse_down()
    started = False
    init_deadline = time.perf_counter() + SHAKE_INIT_MS / 1000.0
    end = time.perf_counter() + SHAKE_HOLD_MS / 1000.0
    while time.perf_counter() < end and State.running:
        if not SHAKE_PLAIN_HOLD:
            _drag_alive()
        if not started and detector.on_shake():
            started = True
        if detector.pan_empty():
            break
        if (not started and time.perf_counter() > init_deadline
                and detector.on_deposit() and detector.capacity_full()):
            mouse_up()
            return False                    # shake never initiated -> retry
        sleep_ms(40)
    mouse_up()
    if not State.running: return True
    # 3) walk forward until the COLLECT DEPOSIT cue (back on land)
    key_down(KEY_W)
    wait_until(detector.on_deposit, DEPOSIT_MAX_MS, confirm=1)
    key_up(KEY_W)
    return True


def run_empty(detector):
    """Empty the pan and VERIFY it actually emptied (capacity = ground truth).
    If not (e.g. the shake didn't reach the water), back up further and retry.
    After EMPTY_RETRIES failures, count it; STUCK_LIMIT in a row -> SAFE STOP.
    Returns True on a confirmed empty."""
    for attempt in range(EMPTY_RETRIES + 1):
        if not State.running:
            return False
        if attempt > 0:
            # previous try didn't empty -> walk back further to reach the water
            key_down(KEY_S); sleep_ms(RETRY_BACK_MS * attempt); key_up(KEY_S)
            sleep_ms(GAP_MS)
        ok = timed_empty(detector)          # False = shake never initiated
        if ok and (detector is None or detector.pan_empty()):
            State.empty_fails = 0
            return True                     # confirmed empty
    # exhausted retries -> the pan still reads full
    State.empty_fails += 1
    if State.empty_fails >= STUCK_LIMIT:
        safe_stop("pan won't empty -- not reaching the water?")
    return False


def empty_sequence(detector):
    if not USE_TERRAIN_DETECT:
        timed_empty(detector)               # pure-timed; stops when pan empties
        return
    walk_back(detector)
    if not State.running: return
    sleep_ms(GAP_MS)
    momentum_and_shake(detector)
    if not State.running: return
    sleep_ms(GAP_MS)
    shake_empty()
    sleep_ms(AFTER_EMPTY_MS)


# ============================================================================
# ROBUST SUPERVISOR  --  fused cue + capacity state machine
# ============================================================================
# Places (from the HUD cue) and pan contents (from the capacity bar).
LAND, WATER, SHAKING, LIMBO = "LAND", "WATER", "SHAKING", "LIMBO"
P_FULL, P_EMPTY, P_PARTIAL = "FULL", "EMPTY", "PARTIAL"
Situation = namedtuple("Situation", "where contents dep pan shk full empty")


def sense_stable(det):
    """Fuse the two sensor layers into one Situation, voting out single-frame
    flicker when SENSE_VOTES > 1. Cheap (5 grabs per vote)."""
    dc = pc = sc = fc = ec = 0
    for _ in range(SENSE_VOTES):
        dep, pan, shk, full, empty = det.snapshot()
        dc += dep; pc += pan; sc += shk; fc += full; ec += empty
    half = SENSE_VOTES / 2.0
    dep, pan, shk = dc > half, pc > half, sc > half
    full, empty = fc > half, ec > half
    where = LAND if dep else WATER if pan else SHAKING if shk else LIMBO
    contents = P_FULL if full else (P_EMPTY if empty else P_PARTIAL)
    return Situation(where, contents, dep, pan, shk, full, empty)


def plan_label(s):
    """The action the supervisor WOULD take for situation s (for logs/monitor).
    Capacity is primary. FULL + in-water(Pan cue) -> shake; FULL elsewhere -> go
    to the water. NOT full -> DIG-PROBE to find land (we ignore the stuck cue)."""
    if s.full:
        return "SHAKE" if s.pan else "go WATER (S back)"
    return "DIG-probe (find land)"


# ---- verified action primitives (each confirms its own result) --------------
def do_dig(det):
    """Dig until the capacity bar reads FULL (your build: ~1 dig). Verifies the
    dig REGISTERED (bar started) and re-digs if it didn't. Bails after
    MAX_DIGS_PER_VISIT so a non-registering dig can't loop forever."""
    t0 = time.perf_counter()
    for i in range(MAX_DIGS_PER_VISIT):
        if not State.running:
            return
        baseline = det.cap_start_rgb()
        dig_once(det)
        started = wait_until(lambda: det.cap_changed(baseline),
                             CAP_START_MS, confirm=1)
        if det.capacity_full() or wait_until(det.capacity_full, DIG_FILL_MS,
                                             confirm=1):
            log(f"    dig#{i+1}: started={started} -> FULL "
                f"({(time.perf_counter()-t0)*1000:.0f}ms)")
            return                       # full -> done
        log(f"    dig#{i+1}: started={started} not full yet, re-dig")
    log("    dig: left PARTIAL after max digs")
    # left partial -> the supervisor will take us to water and shake it out


def go_water(det):
    """HOLD S until the PAN cue (in the water), then keep holding a touch longer
    (WATER_EXTRA_BACK_MS) to walk a little FARTHER in before the shake -- the cue
    can fire right at the edge, where the shake sometimes misses."""
    emit_phase("water")
    t0 = time.perf_counter()
    # If we overshot far onto land (dig carried us forward), a fixed short S
    # budget can't reach the water -> walk back FARTHER on each consecutive miss.
    budget = PAN_BACK_MAX_MS * (1 + min(State.water_fails, 4))

    # X-pattern AUTO-RECENTER: if past diagonal passes have drifted us too far to
    # one side, strafe STRAIGHT back toward centre first (pure A/D, no S -> corrects
    # sideways without changing depth). Keeps us on the good dig strip.
    if X_PATTERN and X_RECENTER_MS > 0 and abs(State.x_balance) > X_RECENTER_MS:
        corr = KEY_A if State.x_balance > 0 else KEY_D
        applied = min(abs(State.x_balance), X_RECENTER_MS * 2.0)   # cap one correction
        tap_key(corr, max(1, int(applied * 0.7)))   # pure strafe ~faster than diagonal
        State.x_balance += (-applied if State.x_balance > 0 else applied)
        emit_event("recenter", "drifted %dms off centre -> strafe back" % int(applied))
        log(f"    X-recenter: strafe {'A' if corr == KEY_A else 'D'} "
            f"{int(applied*0.7)}ms (balance now {State.x_balance:.0f})")

    # pick this pass's diagonal side (bias toward the side that reduces drift)
    side = sgn = None
    if X_PATTERN:
        if State.x_balance > 0:
            side, sgn = KEY_A, -1
        elif State.x_balance < 0:
            side, sgn = KEY_D, +1
        else:
            side, sgn = (KEY_D, +1) if State.x_dir == 0 else (KEY_A, -1)
            State.x_dir ^= 1

    tb = time.perf_counter()
    key_down(KEY_S)
    reached = False
    if side is not None:
        # Hold the diagonal only BRIEFLY (X_STRAFE_MS), then release the side key and
        # finish the walk-back STRAIGHT. A short diagonal covers a little new ground
        # without throwing off the straight-W forward leg (which was landing us in
        # the water) or the depth (which the PAN cue + WATER_EXTRA_BACK_MS govern).
        key_down(side)
        diag_ms = min(X_STRAFE_MS, budget) if X_STRAFE_MS > 0 else budget
        reached = wait_until(det.on_pan, diag_ms, confirm=WALK_BACK_CONFIRM)
        key_up(side)                     # released -> no mid-walk kink
        State.x_balance += sgn * (time.perf_counter() - tb) * 1000.0
    if not reached:                      # continue STRAIGHT back for the remainder
        rem = budget - (time.perf_counter() - tb) * 1000.0
        if rem > 0:
            reached = wait_until(det.on_pan, rem, confirm=WALK_BACK_CONFIRM)
    if reached and WATER_EXTRA_BACK_MS > 0:
        sleep_ms(WATER_EXTRA_BACK_MS)    # keep holding S -> a bit deeper in
    key_up(KEY_S)
    State.water_fails = 0 if reached else State.water_fails + 1
    log(f"    S back: reached_PAN={reached} (+{WATER_EXTRA_BACK_MS}ms deeper, "
        f"budget {budget}ms) ({(time.perf_counter()-t0)*1000:.0f}ms)")


def do_shake(det):
    """THE MOMENTUM TECHNIQUE. Hold W (glide toward land) and rattle RAPID CLICKS
    to shake. macOS does NOT sustain a synthetic held press in Roblox, so a hold
    silently does nothing -- clicks DO register, so we click fast and keep going
    until the pan empties (a slower shake just takes more clicks). W carries you
    onto land WHILE the pan drains; we drop W when the Collect Deposit cue shows.
    Stop when the CAPACITY reads empty (capacity is the truth; the Shake cue
    sticks). Bails only if the pan stays COMPLETELY FULL past SHAKE_BAIL_MS."""
    emit_phase("shake")
    State.assume_full_until = 0.0        # the pan is about to drain for real
    # GEODE shake: the geode shovel slows the SHAKE too, so the normal caps quit
    # before the pan empties. Give it a much longer run and suppress the
    # early "still completely full -> bail" (a slow shake legitimately stays full
    # a while) -- it keeps clicking until the pan actually empties.
    _sh_geode = GEODE_MODE and GEODE_SHAKE_HOLD_MS > 0
    _sh_hold  = GEODE_SHAKE_HOLD_MS if _sh_geode else SHAKE_HOLD_MS
    _sh_bail  = GEODE_SHAKE_HOLD_MS if _sh_geode else SHAKE_BAIL_MS
    _sh_stall = SHAKE_STALL_MS * 4 if _sh_geode else SHAKE_STALL_MS
    _sh_check = GEODE_SHAKE_CHECK if (_sh_geode and GEODE_SHAKE_CHECK > 1) else 1
    _empty_frac = CAP_EMPTY_FRAC * 0.5 if _sh_geode else CAP_EMPTY_FRAC
    t0 = time.perf_counter()
    if SHAKE_START_DELAY_MS > 0:
        sleep_ms(SHAKE_START_DELAY_MS)       # start later (we walked farther back)
    w_down = False
    if SHAKE_MOMENTUM_W:
        key_down(KEY_W); w_down = True       # momentum toward land
        if SHAKE_W_LEAD_MS > 0:
            # MOMENTUM PRE-ROLL (opt-in): glide toward land for EXACTLY this
            # long BEFORE the first click, so built-up speed carries you onto
            # land while the pan drains. Pure clockwork on purpose: the cues
            # carry no information here (the sticky Shake cue lingers right
            # through the glide -- a cue-based cutoff fires instantly and
            # randomly, which is exactly the mistimed-click bug this line
            # replaced). No screen reads, no early exits: the same glide,
            # every cycle. Overshoot recovery already exists (a click that
            # lands on shore trips the shake-start-confirm deeper-S retry).
            emit_phase("glide")      # HUD: HOLD W momentum pre-roll
            sleep_ms(SHAKE_W_LEAD_MS)
            t0 = time.perf_counter()
            emit_phase("shake")      # HUD: clicks start NOW (glide over)
    started = emptied = bailed = on_land = False
    clicks = 0
    fixed = SHAKE_CLICKS > 0                  # exact-count mode (no extra click)
    end = time.perf_counter() + _sh_hold / 1000.0
    start_retries = 0                         # SHAKE-START CONFIRM (opt-in)
    stalled = False                           # DRAIN-STALL (opt-in)
    _stall_fill = 2.0
    _stall_t = time.perf_counter()
    confirm_at = t0 + SHAKE_START_CONFIRM_MS / 1000.0
    bail_at = t0 + _sh_bail / 1000.0
    while State.running and (clicks < SHAKE_CLICKS if fixed
                             else time.perf_counter() < end):
        mouse_tap(SHAKE_CLICK_MS)            # one shake click (rattle)
        clicks += 1
        # GEODE: rattle fast and only READ the screen every Nth click. The
        # per-click sensor grabs (2-4 screen reads each) are what made the slow
        # shake stutter -- down, pause, down. Sensing less often also lets it
        # drain a touch past the first 'empty' read, so it won't stop with a
        # sliver of capacity still showing.
        if _sh_check > 1 and not fixed and (clicks % _sh_check):
            sleep_ms(SHAKE_CLICK_GAP_MS)
            continue
        if not started and det.on_shake():
            started = True
            _stall_t = time.perf_counter()   # stall clock runs from the start
            log(f"    shake STARTED ({(time.perf_counter()-t0)*1000:.0f}ms)")
        _f = det.cap_fill()                  # ONE grab -> reused for empty + stall
        if not fixed and _f < _empty_frac:   # auto mode: stop when empty
            emptied = True
            break
        # DRAIN-STALL (opt-in, SHAKE_STALL_MS > 0): the shake started but the
        # bar has frozen mid-drain -> the game dropped it. Fail FAST so the
        # retry/recovery path re-shakes now instead of waiting out the timeout.
        if SHAKE_STALL_MS > 0 and not fixed and started:
            if _f < _stall_fill - 0.005:
                _stall_fill = _f             # still draining
                _stall_t = time.perf_counter()
            elif (time.perf_counter() - _stall_t) * 1000.0 > _sh_stall:
                stalled = True
                log("    shake STALLED mid-drain -> fail fast")
                break
        if w_down and det.on_deposit():      # reached land -> stop gliding...
            key_up(KEY_W); w_down = False     # ...but keep clicking to finish
            on_land = True
        # SHAKE-START CONFIRM (opt-in, SHAKE_START_CONFIRM_MS > 0): still
        # COMPLETELY FULL past the confirm window = the clicks never started a
        # real shake (edge click / glitch). Micro-retry NOW: drop W, tap S a
        # touch deeper (edge clicks are the usual cause), re-hold W and keep
        # clicking -- ~150ms instead of losing the bail window + a whole cycle.
        # Disarms itself the moment the bar drains or the Shake cue shows.
        if (SHAKE_START_CONFIRM_MS > 0 and not fixed and not started
                and start_retries < SHAKE_START_RETRIES
                and time.perf_counter() > confirm_at
                and det.capacity_full()):
            start_retries += 1
            emit_event("shake_start_retry",
                       "no shake start in %dms -- deeper S tap, retry %d/%d"
                       % (SHAKE_START_CONFIRM_MS, start_retries,
                          SHAKE_START_RETRIES))
            log(f"    shake not starting -> deeper S retry "
                f"#{start_retries}/{SHAKE_START_RETRIES}")
            if w_down:
                key_up(KEY_W); w_down = False
            tap_key(KEY_S, SHAKE_RETRY_DEEPER_MS)
            if SHAKE_MOMENTUM_W:
                key_down(KEY_W); w_down = True
            _now = time.perf_counter()
            confirm_at = _now + SHAKE_START_CONFIRM_MS / 1000.0
            bail_at = _now + _sh_bail / 1000.0
            end = max(end, _now + 0.6)
        # CAPACITY-based bail (auto mode only): give up if the pan is STILL FULL
        # well past a real shake's duration (no drain at all = no shake).
        if (not fixed and time.perf_counter() > bail_at
                and det.capacity_full()):
            bailed = True
            break                            # truly not shaking
        sleep_ms(SHAKE_CLICK_GAP_MS)
    if fixed:
        emptied = det.pan_empty()            # did exactly N clicks -> read result
    if w_down:
        key_up(KEY_W)
    if emptied:
        State.shake_fails = 0
        State.breakouts = 0              # healthy progress -> clear escalation
        State.safe_retries = 0
        State.no_full = 0                # a pan emptied -> capacity pixel is fine
        State.water_fails = 0
        if State.stats:
            State.stats.cycles += 1      # a pan emptied = one completed cycle
            if not State.cycle_dirty:
                State.stats.clean_cycles += 1   # zero retries/recoveries
            _nc = time.perf_counter()
            if State.last_cycle_end:
                _cd = (_nc - State.last_cycle_end) * 1000.0
                if 300 < _cd < 120000:
                    State.stats.cycle_ms.append(_cd)
                    if len(State.stats.cycle_ms) > 600:
                        del State.stats.cycle_ms[:len(State.stats.cycle_ms) - 600]
            State.last_cycle_end = _nc
        State.cycle_dirty = False        # the next cycle starts clean
        State.last_progress = time.perf_counter()
        emit_phase("settle")             # HUD: momentum carries you onto land
        sleep_ms(POST_SHAKE_SETTLE_MS)   # let momentum/animation settle onto land
    else:
        State.shake_fails += 1
        if State.stats:
            State.stats.shake_misses += 1
        emit_event("shake_fail", ("shake never started (glitch)" if not started
                                  else "shake stalled mid-drain (game dropped it)"
                                  if stalled else "shake ran but pan didn't empty"))
    _adapt_shake(emptied)
    dur = (time.perf_counter() - t0) * 1000
    log(f"    shake done: started={started} emptied={emptied} "
        f"reached_land={on_land} bail={bailed} retries={start_retries} "
        f"fails={State.shake_fails} ({dur:.0f}ms)")


def go_land(det):
    """HOLD W forward (smooth) until the COLLECT DEPOSIT cue shows, then hold a
    touch longer (LAND_SETTLE_MS) to sit FIRMLY on the dirt. No S brake -- braking
    back toward the water is what made it bounce land<->water instead of digging."""
    t0 = time.perf_counter()
    key_down(KEY_W)
    reached = wait_until(det.on_deposit, DEPOSIT_MAX_MS, confirm=1)
    if reached and LAND_SETTLE_MS > 0:
        sleep_ms(LAND_SETTLE_MS)         # settle firmly onto land (forward)
    key_up(KEY_W)
    log(f"    W fwd to land: reached_DEPOSIT={reached} "
        f"({(time.perf_counter()-t0)*1000:.0f}ms)")


def _note_dig_registered():
    """Count a REGISTERED dig (the bar actually rose). Rise reads within
    350ms belong to the same dig's animation -> one burst = one dig. Fixes
    the inflated counter (clicks that never registered used to count)."""
    now = time.perf_counter()
    if now - State.dig_burst_t > 0.35:
        if State.stats:
            State.stats.digs += 1
    State.dig_burst_t = now


def _wait_fill_smart(det):
    """SMART FILL WAIT (see constants): wait for FULL, but stop the moment the
    bar STOPS RISING below full -- then the caller digs again immediately."""
    deadline = time.perf_counter() + DIG_SMART_CAP_MS / 1000.0
    last = det.cap_fill()
    last_rise = time.perf_counter()
    while State.running and time.perf_counter() < deadline:
        if det.capacity_full():
            return True
        f = det.cap_fill()
        now = time.perf_counter()
        if f > last + 0.005:                  # still climbing (fill animation)
            _note_dig_registered()
            last, last_rise = f, now
        elif now - last_rise > DIG_PLATEAU_MS / 1000.0:
            log("    fill: bar plateaued below FULL -> dig again now")
            return det.capacity_full()        # settled short -> re-dig NOW
    return det.capacity_full()


def _pipeline_target():
    """Learned digs-per-fill (median of the last completed fills). 0 = the
    pipeline is off or still learning (first 3 fills run the normal loop)."""
    if not DIG_PIPELINE or len(State.fill_digs) < 3:
        return 0
    h = sorted(State.fill_digs)
    return h[len(h) // 2]


def _pipeline_learn(digs, ok):
    """Feed the learner. A pipeline shortfall clears the history so a build
    change (or lag streak) relearns instead of repeating the mistake."""
    if not ok:
        State.fill_digs = []
        return
    State.fill_digs.append(int(digs))
    if len(State.fill_digs) > 8:
        del State.fill_digs[:len(State.fill_digs) - 8]


def fill_to_full(det):
    """Once we're confirmed on land, dig until the capacity bar reads FULL. We do
    NOT assume a dig count -- we watch the bar, so builds that need 2, 3, ... digs
    all work. The probe already did dig #1; we wait for it to fill, then top up
    with more PERFECT digs as needed (capped by MAX_DIGS_TO_FILL)."""
    digs = 1                                  # the probe dig already happened
    # DIG PIPELINE (opt-in): we know how many digs a fill takes -- fire the
    # follow-ups on the dig-animation rhythm, smart-wait only after the LAST.
    n_target = _pipeline_target()
    if n_target > 1:
        gap = (DIG_PIPELINE_GAP_MS if DIG_PIPELINE_GAP_MS > 0
               else int(190000.0 / max(1.0, DIG_SPEED)) + 25)
        while digs < n_target and State.running:
            sleep_ms(gap)                     # let the current anim finish
            dig_once(det)
            digs += 1
        if DIG_FILL_SMART:
            _wait_fill_smart(det)
        else:
            wait_until(det.capacity_full, DIG_FILL_MS, confirm=1)
        if det.capacity_full():
            log(f"    filled in {digs} dig(s) (pipelined)")
            _pipeline_learn(digs, True)
            return True
        log("    pipeline came up short -> normal top-up (relearning)")
        _pipeline_learn(digs, False)
    for i in range(MAX_DIGS_TO_FILL):
        if det.capacity_full():
            log(f"    filled in {digs} dig(s)")
            if DIG_PIPELINE:
                _pipeline_learn(digs, True)
            return True
        if not State.running:
            return False
        if i > 0:
            dig_once(det)                     # another PERFECT dig (release on green)
            digs += 1
        if DIG_FILL_SMART:
            _wait_fill_smart(det)             # motion-aware (opt-in)
        else:
            wait_until(det.capacity_full, DIG_FILL_MS, confirm=1)
    log(f"    fill: still not full after {digs} digs -> proceed anyway")
    return det.capacity_full()

def _shards_dig(det):
    """SHARDS EXACT-CLICK DIG (opt-in, SHARDS_DIG_CLICKS > 0): click the dig
    EXACTLY N times -- no probe re-digs, no bar-race double clicks (a fast
    build's fill animation starts after the probe window used to close, so
    the old probe sometimes fired click #2 while click #1 was still landing).
    The FIRST click must prove it registered: the bar leaves EMPTY (left tip
    no longer gray) within SHARDS_CLICK_CONFIRM_MS. Only a provably-dead
    click is retried. If the pan wasn't empty on entry (recovery leftovers),
    the proof is a fill RISE instead. With SHARDS_ASSUME_FULL on we don't
    wait for FULL at all: fill started = fill guaranteed -> return now and
    spend the animation time walking; act() treats the pan as full until the
    animation deadline (State.assume_full_until) passes, and do_shake clears
    it."""
    gap = int(190000.0 / max(1.0, DIG_SPEED)) + 25   # dig-animation rhythm
    tries = max(1, SHARDS_CLICK_RETRIES)
    for rnd in range(LAND_DIG_TRIES):
        if not State.running:
            return False
        if rnd == 0 and PRE_DIG_SETTLE_MS > 0:
            sleep_ms(PRE_DIG_SETTLE_MS)
        before = det.cap_fill()
        if det.pan_empty():
            bar_proof = lambda: not det.pan_empty()
        else:                            # partial pan (recovery) -> need rise
            bar_proof = lambda: (det.cap_fill() > before + CAP_RISE_FRAC
                                 or det.capacity_full())
        proof = bar_proof
        if SHARDS_GREEN_CONFIRM and not det.dig_bar_green():
            # the dig skill-bar POPPING UP proves the dig is running -- frames
            # earlier than the capacity bar (which can lag by 2-3 whole
            # animations on a busy game). Armed per-visit only when the spot
            # is NOT already green, so green terrain can't fake a dig.
            proof = (lambda bp=bar_proof:
                     det.dig_bar_green() or bp())
        confirmed = False
        for t in range(tries):
            if not State.running:
                return False
            dig_once(det)
            if wait_until(proof, max(30, SHARDS_CLICK_CONFIRM_MS), confirm=1):
                confirmed = True
                break
            log(f"    shards: click {t+1}/{tries} never moved the bar"
                + (" -> retry" if t + 1 < tries else ""))
        if confirmed:
            State.land_fails = 0
            State.breakouts = 0          # healthy progress -> clear escalation
            State.safe_retries = 0
            _note_dig_registered()
            State.last_progress = time.perf_counter()
            _adapt_land(rnd > 0)
            for _k in range(1, SHARDS_DIG_CLICKS):
                sleep_ms(gap)            # follow-ups ride the dig rhythm
                dig_once(det)
            if SHARDS_ASSUME_FULL:
                State.assume_full_until = time.perf_counter() + 1.2
                log(f"    shards: fill started (round {rnd+1}) -> assumed "
                    f"FULL, moving on now")
                return True
            wait_until(det.capacity_full, max(600, DIG_FILL_MS), confirm=1)
            log(f"    shards: filled ({SHARDS_DIG_CLICKS} click(s), "
                f"round {rnd+1})")
            return True
        log(f"    shards: bar never moved (round {rnd+1}) -> nudge W fwd")
        emit_event("nudge", "shards dig: bar never moved -- nudging forward")
        if State.stats:
            State.stats.nudges += 1
        key_down(KEY_W); sleep_ms(LAND_PROBE_NUDGE_MS); key_up(KEY_W)
        sleep_ms(PROBE_GAP_MS)
    State.land_fails += 1
    _adapt_land(True)
    log(f"    shards dig: no land after {LAND_DIG_TRIES} rounds "
        f"(land_fails={State.land_fails})")
    if State.land_fails >= STUCK_LIMIT:
        safe_stop("shards dig can't find land after shaking")
    return False


def emit_geode_timer(ms, label=""):
    """__GEODE__ marker -> drives the live delay countdown in the HUD + Run page.
    ms>0 starts/refreshes the countdown; ms=0 clears it."""
    try:
        print("__GEODE__ " + json.dumps({"ms": int(ms), "label": label}), flush=True)
    except Exception:
        pass


def _geode_wait(ms, label, det):
    """FIXED wait for the slow geode fill animation to fully COMPLETE before the
    next dig (same idea as treasure's dig gap). It does NOT end the instant the
    bar twitches -- the geode is not ready to be dug again until the whole
    animation finishes, so ending early makes the next dig silently miss. Bails
    only on Stop or a real FULL read, streams a live countdown, and keeps the
    no-progress watchdog quiet the whole time (a running geode animation IS
    progress -- without this the 1-5s watchdog fires a bogus break-out mid-fill)."""
    ms = max(0, int(ms))
    emit_geode_timer(ms, label)
    end = time.perf_counter() + ms / 1000.0
    try:
        while State.running and time.perf_counter() < end:
            if det is not None and det.capacity_full():
                break
            State.last_progress = time.perf_counter()   # animation = progress
            left = (end - time.perf_counter()) * 1000.0
            sleep_ms(int(min(120.0, max(15.0, left))))
    finally:
        emit_geode_timer(0)


def _geode_dig(det):
    """GEODE DIG (opt-in, GEODE_MODE): fast-tap dig on a build with a VERY slow
    fill animation (e.g. 10% dig-speed geode shovels). Each dig: click, briefly
    look for the GREEN dig-bar (or a capacity move) so the timer can start
    promptly, then WAIT the full GEODE_DELAY_MS animation, then judge by the
    CAPACITY -- if the bar rose the dig registered (keep going / stop at FULL); if
    a whole dig+animation moved NOTHING, we're off land -> nudge forward. A
    missing green NEVER nudges on its own (that caused the false-nudge + break-out
    cascade). GEODE_DIGS_TO_FILL = 0 means dig until the bar reads FULL (auto);
    >0 means exactly that many. Done -> normal cycle: walk to water + momentum
    shake (NOT treasure's strafe)."""
    n_target = max(0, GEODE_DIGS_TO_FILL)
    hold     = max(1, GEODE_DIG_MS)
    delay    = max(50, GEODE_DELAY_MS)
    startwin = max(120, GEODE_START_MS)
    hard_cap = n_target if n_target > 0 else 30
    for rnd in range(LAND_DIG_TRIES):
        if not State.running:
            return False
        if rnd == 0 and PRE_DIG_SETTLE_MS > 0:
            sleep_ms(PRE_DIG_SETTLE_MS)
        digs = 0
        while State.running and digs < hard_cap:
            before    = det.cap_fill()
            was_empty = det.pan_empty()
            if State.stats:
                State.stats.dig_clicks += 1
            mouse_tap(hold)
            # green (if the dig trigger pixel is calibrated) confirms the dig
            # started + starts the timer promptly; if it doesn't show we still
            # wait the animation and judge by capacity, so it never false-nudges.
            wait_until(lambda _b=before, _e=was_empty:
                       det.dig_bar_green()
                       or (_e and not det.pan_empty())
                       or det.cap_fill() > _b + CAP_RISE_FRAC
                       or det.capacity_full(), startwin, confirm=1)
            _geode_wait(delay, "geode fill %d%s" % (
                digs + 1, ("/%d" % n_target) if n_target > 0 else ""), det)
            if det.cap_fill() > before + CAP_RISE_FRAC or det.capacity_full():
                digs += 1
                State.land_fails = 0
                State.breakouts  = 0
                State.safe_retries = 0
                _note_dig_registered()
                State.last_progress = time.perf_counter()
                if det.capacity_full():
                    break
            else:
                break                        # full dig + animation moved nothing
        if digs == 0:
            log(f"    geode: no fill after a full dig+animation (round {rnd + 1}) "
                f"-> nudge W fwd")
            emit_event("nudge", "geode dig: no fill after the animation -- nudging forward to find land")
            if State.stats:
                State.stats.nudges += 1
            key_down(KEY_W); sleep_ms(LAND_PROBE_NUDGE_MS); key_up(KEY_W)
            sleep_ms(PROBE_GAP_MS)
            _adapt_land(True)
            continue
        _adapt_land(rnd > 0)
        if GEODE_CONFIRM_FULL and not det.capacity_full():
            wait_until(det.capacity_full, max(delay, DIG_FILL_MS), confirm=1)
        if not det.capacity_full():
            # trust the count: hold 'full' briefly so the walk-back shakes
            # instead of re-digging while the bar still lags
            State.assume_full_until = time.perf_counter() + 2.0
        log(f"    geode: {digs} dig(s) done (round {rnd + 1}) -> walk to shake")
        return True
    State.land_fails += 1
    _adapt_land(True)
    log(f"    geode dig: no land after {LAND_DIG_TRIES} rounds "
        f"(land_fails={State.land_fails})")
    if State.land_fails >= STUCK_LIMIT:
        safe_stop("geode dig can't find land after shaking")
    return False


def return_and_dig(det):
    """Post-shake landing WITHOUT trusting the cue (it can stick on 'Shake').
    We trust the W-momentum put us near land and DIG as a probe -- a dig only
    fills on dirt, so the CAPACITY tells us the truth. A dig registers if the bar
    FILL RISES. We re-dig IN PLACE a few times before assuming we're off-land and
    nudging W (so a single non-registering dig can't cause a jittery nudge)."""
    emit_phase("dig")
    State.no_full += 1
    if State.no_full >= NO_FULL_LIMIT:
        # We keep digging/nudging but the capacity bar NEVER reads full -- almost
        # always a mis-calibrated capacity pixel (common when auto-calibrate's
        # ratios don't match this PC's Roblox GUI scale). Stop loudly instead of
        # walking forward forever, and tell the user exactly what to fix.
        safe_stop("the pan never reads FULL -- the Capacity bar pixel looks "
                  "mis-calibrated. Open Calibrate and re-set the Capacity bar "
                  "(or Auto-calibrate with Roblox open).", hard=True)
        return False
    if GEODE_MODE:
        return _geode_dig(det)           # GEODES: slow-animation, count-based dig
    if SHARDS_DIG_CLICKS > 0:
        return _shards_dig(det)          # SHARDS exact-click mode (see above)
    # LAND-CUE ASSIST (opt-in, default OFF): put ourselves ON the dirt before
    # probing. PULSED taps only (pulse_until re-checks after every tap) -- a
    # held W here flew PAST the deposit whenever the cue didn't confirm,
    # because 'Collect Deposit' only shows NEAR a deposit. If the cue never
    # shows, the taps cover very little ground and the normal probe takes over.
    if LAND_CUE_ASSIST and LAND_ASSIST_MAX_MS > 0 and not det.on_deposit():
        _got = pulse_until(KEY_W, det.on_deposit, LAND_ASSIST_MAX_MS)
        log(f"    land-assist (pulsed): deposit_cue={_got}")
    for rnd in range(LAND_DIG_TRIES):
        if not State.running:
            return False
        if rnd == 0 and PRE_DIG_SETTLE_MS > 0:
            sleep_ms(PRE_DIG_SETTLE_MS)      # let the landing settle before dig #1
        prev_before = None
        for t in range(DIG_INPLACE_TRIES):
            if not State.running:
                return False
            before = det.cap_fill()          # fill level BEFORE the dig
            if prev_before is not None and (
                    before > prev_before + CAP_RISE_FRAC
                    or det.capacity_full()):
                # LATE RISE: the PREVIOUS dig registered after its probe
                # window closed (slow fill animation at high dig speed) --
                # count it instead of burning another dig. This is what made
                # 'Max digs to fill = 1' sometimes dig twice.
                log("    dig-probe: previous dig registered late -> "
                    "counting it, no extra dig")
                hit = True
            else:
                dig_once(det)
                hit = wait_until(lambda: det.cap_fill() > before
                                 + CAP_RISE_FRAC or det.capacity_full(),
                                 DIG_PROBE_MS, confirm=1)
            prev_before = before
            if hit:
                State.land_fails = 0
                State.breakouts = 0          # healthy progress -> clear escalation
                State.safe_retries = 0
                log(f"    dig-probe HIT (round {rnd+1}.{t+1}) -> on land, filling")
                _note_dig_registered()
                State.last_progress = time.perf_counter()
                _adapt_land(rnd > 0)         # needed nudges to land = a miss
                fill_to_full(det)            # dig until FULL (dynamic # of digs)
                return True
        # none of the in-place digs registered -> probably off land -> nudge fwd
        log(f"    no dig registered (round {rnd+1}) -> nudge W fwd")
        emit_event("nudge", "no dig registered, nudging forward to find land")
        if State.stats: State.stats.nudges += 1
        key_down(KEY_W); sleep_ms(LAND_PROBE_NUDGE_MS); key_up(KEY_W)
        sleep_ms(PROBE_GAP_MS)               # settle before the next round
    State.land_fails += 1
    _adapt_land(True)
    log(f"    dig-probe: no land after {LAND_DIG_TRIES} rounds "
        f"(land_fails={State.land_fails})")
    if State.land_fails >= STUCK_LIMIT:
        safe_stop("dig-probe can't find land after shaking")
    return False


def act(det, s):
    """Capacity-primary decision. The cue is only trusted for 'am I in the water'
    (Pan), since the Shake/Deposit cues glitch. FULL + Pan -> shake; FULL else ->
    go to water; NOT full -> dig-probe to find land + refill."""
    full = s.full
    if (not full and time.perf_counter() < State.assume_full_until
            and ((SHARDS_DIG_CLICKS > 0 and SHARDS_ASSUME_FULL) or GEODE_MODE)):
        full = True                      # SHARDS: one-click fill in flight --
                                         # the bar is still animating but the
                                         # fill is guaranteed
    if full:
        if s.pan:
            do_shake(det)                # FULL and in the water -> shake it out
        else:
            if EASY_WATER_RETURN_DELAY_MS > 0:
                sleep_ms(EASY_WATER_RETURN_DELAY_MS)
            go_water(det)                # FULL on land -> walk back to the water
    else:
        return_and_dig(det)              # empty -> DIG (probe) to find land


def recover(det, s):
    """Stronger corrective when stuck on the SAME situation for STUCK_TICKS.
    Recovery moves are JITTERED (short taps) so they can't sail past the target,
    even though the normal legs hold smoothly."""
    if State.stats:
        State.stats.recoveries += 1
        post_webhook("recovery", "🛠️ Recovering (got stuck, correcting)",
                     State.stats.as_dict(), shot=True)
    if s.full and s.pan:
        emit_event("recover", "full & in water, pan won't empty, re-shaking",
                   s.where, s.contents)
        if SHAKE_RETRY_ENABLED:
            do_shake(det)                # full in water, won't empty -> shake again
    elif s.full:
        # full but not in water -> jitter S back toward the water
        emit_event("recover", "full on land, jitter back to the water", s.where, s.contents)
        if State.stats: State.stats.nudges += 1
        pulse_until(KEY_S, det.on_pan, RECOVER_BACK_MS)
    else:
        # empty, can't land -> jitter forward, then re-probe with a dig next tick
        emit_event("recover", "empty, can't find land, jitter forward", s.where, s.contents)
        if State.stats: State.stats.nudges += 1
        pulse_until(KEY_W, det.capacity_full, RECOVER_BACK_MS)


def break_out(det, s):
    """Last-resort escape when normal recovery keeps failing on the SAME spot.
    The usual cause is a shake that's ACTUALLY animating (so movement is locked --
    every 'go water' reports it couldn't move). You can't walk mid-shake, but
    HOLDING the mouse still finishes it, so we hold to drain it, then reposition
    forward to get off the water edge. After this we reset the counters and let
    normal logic try again ('do as if it was normal'). Returns True if it emptied."""
    log("    ** BREAK-OUT: click to finish any active shake, then reposition **")
    emit_event("break_out", "stuck at %s/%s, forcing an escape" % (s.where, s.contents),
               s.where, s.contents)
    if s.full:
        end = time.perf_counter() + BREAKOUT_SHAKE_MS / 1000.0
        while time.perf_counter() < end and State.running:
            mouse_tap(SHAKE_CLICK_MS)
            if det.pan_empty():
                log("    break-out: clicks finished the shake -> pan empty")
                return True
            sleep_ms(SHAKE_CLICK_GAP_MS)
    # still stuck -> reposition forward (off the edge / onto land) for next try
    log("    break-out: reposition W fwd")
    key_down(KEY_W); sleep_ms(BREAKOUT_REPOS_MS); key_up(KEY_W)
    return False


def _autopan_state():
    """Auto Pan button state by colour: True=on, False=off, None=unknown/
    uncalibrated (callers then leave it alone)."""
    det = State.detector
    x, y = AUTOPAN_BTN_PIXEL
    if det is None or not (x or y) \
            or not any(AUTOPAN_ON_RGB) or not any(AUTOPAN_OFF_RGB):
        return None
    rgb = rgb_at(det.sct, x, y)
    if _rgb_match(rgb, AUTOPAN_ON_RGB, AUTOPAN_TOL):
        return True
    if _rgb_match(rgb, AUTOPAN_OFF_RGB, AUTOPAN_TOL):
        return False
    return None


def _autopan_set(want_on):
    """Click the Auto Pan button until it READS the wanted state (max 3
    clicks, colour-verified each time). Cursor is parked back at the home
    pixel afterwards so relic clicks can't hit the button by accident.
    With AUTOPAN_SHIFTLOCK: taps Shift to exit shift-lock first (frees the
    cursor), and taps Shift again once parked back at centre.
    Returns True if we actually toggled it (caller restores afterwards)."""
    cur = _autopan_state()
    if cur is None or cur == want_on:
        return False
    if AUTOPAN_SHIFTLOCK:
        tap_key(KEY_SHIFT, 60)                    # exit shift-lock
        sleep_ms(FR_ACTION_GAP_MS)
    for _ in range(3):
        click_at(AUTOPAN_BTN_PIXEL[0], AUTOPAN_BTN_PIXEL[1], 50)
        sleep_ms(AUTOPAN_SETTLE_MS)
        if _autopan_state() == want_on:
            break
    else:
        log("[tracker] Auto Pan button never read on=%s -- check its "
            "colour calibration" % want_on)
    if AUTOPAN_SHIFTLOCK and AUTOPAN_FAST_RELOCK:
        if AUTOPAN_RELOCK_DELAY_MS > 0:
            sleep_ms(AUTOPAN_RELOCK_DELAY_MS)     # custom click -> shift gap
        tap_key(KEY_SHIFT, 60)                    # re-lock right after the click
        sleep_ms(FR_ACTION_GAP_MS)                # (lock snaps cursor to centre)
    else:
        if FR_HOME_PIXEL and (FR_HOME_PIXEL[0] or FR_HOME_PIXEL[1]):
            move_cursor(FR_HOME_PIXEL[0], FR_HOME_PIXEL[1])   # park off the button
        sleep_ms(FR_CLICK_SETTLE_MS)
        if AUTOPAN_SHIFTLOCK:
            if AUTOPAN_RELOCK_DELAY_MS > 0:
                sleep_ms(AUTOPAN_RELOCK_DELAY_MS) # custom centre -> shift gap
            tap_key(KEY_SHIFT, 60)                # re-enter shift-lock at centre
            sleep_ms(FR_ACTION_GAP_MS)
    return True


class RelicScheduler:
    """Timed relic use (solar mags, idols, ...). Every relic's interval, PAUSE
    the cycle, switch to its hotbar slot, double-click to use it, switch back to
    the pan slot, and resume. Checked between supervisor ticks (a safe boundary);
    the self-healing supervisor re-senses afterwards, so this can't corrupt the
    cycle. Entirely additive: does nothing unless RELICS_ENABLED."""
    def __init__(self):
        self.reset()

    def reset(self):
        now = time.perf_counter()
        # schedule each relic's first fire one interval from the start
        self.next = {}
        for i, r in enumerate(RELICS):
            self.next[i] = now + r.get("minutes", 10) * 60.0

    def maybe_fire(self):
        if not RELICS_ENABLED or not State.running:
            return
        if State.relic_shift_pending:            # non-relative pause catch-up
            for _k in self.next:
                if self.next[_k] is not None:
                    self.next[_k] += State.relic_shift_pending
            log("=== RELIC timers shifted +%.0fs (paused, non-relative) ==="
                % State.relic_shift_pending)
            State.relic_shift_pending = 0.0
        now = time.perf_counter()
        for i, r in enumerate(RELICS):
            due = self.next.get(i)
            if due is not None and now >= due:
                if RELIC_ON_LAND and State.detector is not None:
                    _land = True
                    try:
                        _land = State.detector.on_deposit()
                    except Exception:
                        pass
                    if not _land and now - due < RELIC_LAND_MAX_S:
                        continue                 # due, but wait for LAND first
                    if not _land:
                        log("=== RELIC: no land for %ds -- placing anyway ==="
                            % RELIC_LAND_MAX_S)
                self._fire(r)
                self.next[i] = time.perf_counter() + r.get("minutes", 10) * 60.0

    def reset_one(self, i):
        """Restart ONE relic's timer at its full interval (hotkey Ctrl+Shift+N)."""
        try:
            r = RELICS[i]
        except (IndexError, TypeError):
            return
        self.next[i] = time.perf_counter() + float(r.get("minutes", 10)) * 60.0
        log("=== RELIC '%s' timer RESET to full ===" % r.get("name", i + 1))

    def set_left(self, i, secs):
        """Set ONE relic's remaining time exactly (Run-tab setter). After it
        fires, the standard interval resumes automatically."""
        try:
            r = RELICS[i]
        except (IndexError, TypeError):
            return
        secs = max(0.0, float(secs))
        self.next[i] = time.perf_counter() + secs
        log("=== RELIC '%s' timer set to %d:%02d ==="
            % (r.get("name", i + 1), int(secs) // 60, int(secs) % 60))

    def remaining(self):
        """[{name, left_s}] for the live timer display (stats line / pill)."""
        if not RELICS_ENABLED:
            return []
        now = time.perf_counter()
        out = []
        for i, r in enumerate(RELICS):
            due = self.next.get(i)
            if due is not None:
                out.append({"name": r.get("name", "relic %d" % (i + 1)),
                            "left_s": max(0, int(due - now))})
        return out

    def _fire(self, r):
        slot = int(r.get("slot", 0))
        clicks = int(r.get("clicks", 2))
        log(f"=== RELIC: use {r.get('name','relic')} (slot {slot}) ===")
        release_all()
        _toggled = False
        if TRACKER_MODE and TRACKER_RELICS:
            _toggled = _autopan_set(False)   # pause the game's Auto Pan
        sleep_ms(RELIC_PRE_MS)
        tap_key(SLOT_KEYCODES.get(slot))         # switch to the relic slot
        sleep_ms(RELIC_SWITCH_MS)
        for _ in range(max(1, clicks)):          # use it (double-click)
            if not State.running:
                break
            mouse_tap(RELIC_CLICK_MS)
            sleep_ms(RELIC_CLICK_GAP_MS)
        sleep_ms(RELIC_SWITCH_MS)
        tap_key(SLOT_KEYCODES.get(RELIC_RETURN_SLOT))   # back to the pan
        sleep_ms(RELIC_SWITCH_MS)
        if _toggled:
            _autopan_set(True)               # resume the game's Auto Pan
            State.ap_kick_grace = time.perf_counter()   # fresh stall window
        if State.stats: State.stats.relics_used += 1
        log("=== RELIC done -> resuming ===")


def treasure_tick(det):
    """TREASURE CHEST mode (no shake): dig briefly, then strafe sideways -- D,
    then A, alternating -- until the Collect/Deposit cue appears again, then dig.
    Reuses the Deposit pixel (calibrate it on the 'Collect' prompt)."""
    release_all()
    for _i in range(max(1, TREASURE_DIGS)):   # do N digs (let the slow dig finish)
        if not State.running:
            return
        mouse_tap(TREASURE_DIG_MS)            # quick dig / open the chest
        if TREASURE_DIG_GAP_MS > 0:
            sleep_ms(TREASURE_DIG_GAP_MS)
    if State.stats:
        State.stats.cycles += 1
    if not State.running:
        return
    side = KEY_D if State.t_side == 0 else KEY_A
    State.t_side ^= 1                         # alternate L/R each chest
    # Hold the side key: first move OFF this spot (until the Pan cue), then KEEP
    # holding until the next Collect cue -- so we can't re-trigger on the same spot.
    key_down(side)
    left = wait_until(det.on_pan, TREASURE_MOVE_MAX_MS, confirm=1)
    reached = wait_until(det.on_deposit, TREASURE_MOVE_MAX_MS, confirm=1)
    key_up(side)
    log(f"    treasure: {TREASURE_DIGS} dig(s), held {'D' if side == KEY_D else 'A'} "
        f"(pan={left} -> collect={reached})")


def _tracker_phase(name):
    if State.trk_phase != name:
        State.trk_phase = name
        emit_phase(name)


def tracker_tick(det):
    """TRACKER MODE: watch-only (see constants). Counts the game's own
    auto-pan through the same detector the macro uses. No input, ever."""
    f = det.cap_fill()
    now = time.perf_counter()
    if State.trk_last is None:
        State.trk_last, State.trk_peak = f, f
        sleep_ms(TRACKER_POLL_MS)
        return
    df = f - State.trk_last
    if df > 0.015:                                   # bar rising
        if now - State.trk_rise_t > 0.30:            # new rise burst = a dig
            if State.stats:
                State.stats.digs += 1
            _tracker_phase("dig")
        State.trk_rise_t = now
        if f > State.trk_peak:
            State.trk_peak = f
    elif df < -0.015:                                # bar draining = shaking
        if now - State.trk_fall_t > 0.30:
            _tracker_phase("shake")
        State.trk_fall_t = now
    if f <= CAP_EMPTY_FRAC and State.trk_peak >= 0.35:
        if State.stats:
            State.stats.cycles += 1                  # one pan emptied
            State.stats.clean_cycles += 1            # game pans have no retries
            _nc = time.perf_counter()
            if State.last_cycle_end:
                _cd = (_nc - State.last_cycle_end) * 1000.0
                if 300 < _cd < 120000:
                    State.stats.cycle_ms.append(_cd)
                    if len(State.stats.cycle_ms) > 600:
                        del State.stats.cycle_ms[:len(State.stats.cycle_ms) - 600]
            State.last_cycle_end = _nc
        State.trk_peak = 0.0
        State.last_progress = now
    # AUTO PAN GUARD (opt-in): catch an accidental Auto Pan toggle and undo
    # it. Two consecutive OFF reads required; the relic dance can't be
    # interrupted (it runs between ticks, never concurrently with this).
    if AUTOPAN_GUARD and AUTOPAN_GUARD_SEC > 0 and now >= State.ap_next_check:
        State.ap_next_check = now + AUTOPAN_GUARD_SEC
        _st = _autopan_state()
        if _st is False:
            State.ap_off_streak += 1
            if State.ap_off_streak >= 2:
                log("[tracker] Auto Pan found OFF -> turning it back ON")
                emit_event("autopan_guard", "auto pan was off -- re-enabled")
                _autopan_set(True)
                State.ap_off_streak = 0
        else:
            State.ap_off_streak = 0
    # AUTO PAN HEALTH KICK (opt-in): button GREEN but the bar has been dead
    # (no rise, no drain) for AUTOPAN_STALL_SEC -> Auto Pan wedged; cycle it.
    if AUTOPAN_STALL_SEC > 0:
        _last_act = max(State.trk_rise_t, State.trk_fall_t, State.ap_kick_grace)
        if now - _last_act > AUTOPAN_STALL_SEC:
            if _autopan_state() is True:
                log("[tracker] Auto Pan shows ON but nothing moved for %ds "
                    "-> restarting it" % AUTOPAN_STALL_SEC)
                emit_event("autopan_kick",
                           "green but idle %ds -- toggled off/on"
                           % AUTOPAN_STALL_SEC)
                _autopan_set(False)
                sleep_ms(AUTOPAN_SETTLE_MS)
                _autopan_set(True)
            State.ap_kick_grace = time.perf_counter()   # full fresh window
    State.trk_last = f
    sleep_ms(TRACKER_POLL_MS)


class Supervisor:
    """Tick-based brain. Re-senses, acts, and watches for deadlock. Reset on
    every start so a fresh run can't inherit a stale stuck-count."""
    def __init__(self):
        self.reset()

    def reset(self):
        self.last_sig = None
        self.same = 0
        self.recoveries = 0
        State.shake_fails = 0
        State.land_fails = 0
        State.breakouts = 0
        State.x_balance = 0.0
        State.no_full = 0
        State.cycle_dirty = False
        State.fill_digs = []
        State.dig_burst_t = 0.0
        State.last_cycle_end = 0.0
        State.assume_full_until = 0.0
        State.trk_last = None
        State.trk_peak = 0.0
        State.trk_phase = ""
        State.ap_next_check = 0.0
        State.ap_off_streak = 0
        State.ap_kick_grace = time.perf_counter()
        State.last_progress = time.perf_counter()

    def tick(self, det):
        if State.want_reset:           # fresh slate after a safe-pause
            self.reset()
            State.want_reset = False
        release_all()                  # clear any stray held key/mouse (anti-drift)
        s = sense_stable(det)
        sig = (s.where, s.contents)
        if s.full:
            State.no_full = 0            # capacity 'full' detected -> detection OK
        if sig == self.last_sig:
            self.same += 1
        else:
            self.same, self.last_sig, self.recoveries = 0, sig, 0
        cue = f"{'D' if s.dep else '-'}{'P' if s.pan else '-'}{'S' if s.shk else '-'}"
        cap = f"{'F' if s.full else '-'}{'E' if s.empty else '-'}"
        # SHAKE-GLITCH FAST PATH: the game sometimes fails to register a shake and
        # the normal stuck-watchdog misses it (we bounce water<->land, so the
        # signature keeps changing and `same` never builds up). After just a few
        # failed shakes, do a quick CLICK-TO-EMPTY break-out right away -- it's
        # low-risk (worst case it just starts a shake/dig) and usually clears the
        # glitch. Only SAFE STOP if even the break-out keeps failing.
        if SHAKE_GLITCH_LIMIT > 0 and State.shake_fails >= SHAKE_GLITCH_LIMIT:
            if BREAKOUT_ENABLED and State.breakouts < BREAKOUT_LIMIT:
                State.breakouts += 1
                emit_event("shake_glitch", "shake didn't register x%d, quick recovery"
                           % State.shake_fails)
                log(f"** shake not registering x{State.shake_fails} "
                    f"-> quick break-out #{State.breakouts} **")
                if break_out(det, s):
                    State.breakouts = 0
                State.shake_fails = 0
                self.same = 0
                self.recoveries = 0
                self.last_sig = None
                return
            safe_stop(f"shake not emptying after {State.shake_fails} tries")
            return
        # NO-PROGRESS fast path: the shake-glitch can leave the macro THINKING all
        # is well while it just walks back and forth (nothing actually completing).
        # If nothing has worked (no pan emptied AND no dig registered) for
        # NO_PROGRESS_SEC, do a quick click-to-empty break-out -- low risk, usually
        # clears it. Safe-stop only if break-out keeps failing.
        if (BREAKOUT_ENABLED and NO_PROGRESS_SEC > 0 and State.last_progress
                and time.perf_counter() - State.last_progress > NO_PROGRESS_SEC):
            State.breakouts += 1
            emit_event("no_progress", "nothing completed for %ds, click-to-empty recovery"
                       % NO_PROGRESS_SEC)
            log(f"** no progress for {NO_PROGRESS_SEC}s -> break-out #{State.breakouts} (click to empty) **")
            if State.breakouts > BREAKOUT_LIMIT:
                safe_stop("no progress -- stuck (shake glitch?)")
                return
            break_out(det, s)
            State.last_progress = time.perf_counter()
            State.shake_fails = 0
            self.same = 0
            self.recoveries = 0
            self.last_sig = None
            return
        if self.same < STUCK_TICKS:
            log(f"{s.where:7}/{s.contents:7} cue[{cue}] cap[{cap}] "
                f"-> {plan_label(s)}")
            act(det, s)
        elif RECOVER_ENABLED and self.recoveries < RECOVER_LIMIT:
            self.recoveries += 1
            log(f"{s.where:7}/{s.contents:7} cue[{cue}] cap[{cap}] "
                f"** STUCK x{self.same}, RECOVER #{self.recoveries} **")
            recover(det, s)
            self.same = 0
        elif BREAKOUT_ENABLED:
            # recovered enough and still stuck -> SMART BREAK-OUT: finish any active
            # (movement-locking) shake by clicking + reposition, then reset and let
            # normal logic try again. SAFE STOP only if the break-out keeps failing.
            State.breakouts += 1
            log(f"{s.where:7}/{s.contents:7} cue[{cue}] cap[{cap}] "
                f"** BREAK-OUT #{State.breakouts} (recovery loop) **")
            if State.breakouts > BREAKOUT_LIMIT:
                safe_stop(f"stuck at {s.where}/{s.contents} after break-outs")
                return
            if break_out(det, s):
                State.breakouts = 0          # progress -> clear the escalation
            # reset the watchdog so normal logic gets a fresh attempt next tick
            self.same = 0
            self.recoveries = 0
            self.last_sig = None
        else:
            # recovery systems are all disabled -> just retry the normal action.
            # The per-situation guards (shake/land fail limits) still safe-stop if
            # it genuinely can't make progress.
            log(f"{s.where:7}/{s.contents:7} cue[{cue}] cap[{cap}] "
                f"** STUCK x{self.same} (recovery off) -> retry **")
            act(det, s)
            self.same = 0


def loop_step(detector):
    # Without terrain detection we can't reason about position: fall back to the
    # simple linear loop (dig, and empty when the capacity bar fills).
    if not USE_TERRAIN_DETECT:
        # MANUAL: do a fixed number of digs, then empty. No capacity detection
        # for the dig phase -- you told it how many digs fill the pan.
        if MANUAL_DIG:
            # ERROR CHECK: if the pan is ALREADY full (e.g. a previous empty
            # failed), don't dig (it does nothing) -- empty it first.
            if detector.capacity_full():
                run_empty(detector)
                return
            # dig the required number of times
            for i in range(DIGS_PER_CYCLE):
                if not State.running: return
                # dig, then move the moment the bar STARTS (no wait for full).
                dig_until_started(detector)
                if i < DIGS_PER_CYCLE - 1:
                    sleep_ms(BETWEEN_DIGS_MS)
            run_empty(detector)             # empty + VERIFY (retries / safe-stop)
            return
        # AUTO: dig until the capacity bar reads full (uses detection).
        if detector.capacity_full():        # already full (incl. failed empty)
            empty_sequence(detector)
            sleep_ms(RETRY_GAP_MS)
            return
        dig_once(detector)
        if not State.running: return
        sleep_ms(CAP_CHECK_MS)              # brief settle so the dig registers
        if detector.capacity_full():
            empty_sequence(detector)        # full -> walk back NOW (no extra wait)
        else:
            sleep_ms(BETWEEN_DIGS_MS)       # not full -> normal between-dig pause
        return

    # Terrain-aware state machine: decide from (where am I) x (is the pan full).
    wet = detector.wet_stable()
    # Second layer: the HUD prompt is slow but authoritative about position, so
    # let it correct the fast colour read when it clearly says dirt vs liquid.
    if USE_TEXT_LAYER:
        t = detector.text_state_stable()
        if t == "deposit":
            wet = False         # prompt says "Collect Deposit" -> on dirt
        elif t == "pan":
            wet = True          # prompt says "Pan" -> in the liquid
        # "shake" -> mid-animation, keep the colour read
    full = detector.capacity_full()

    if wet and full:
        # In the liquid holding a full pan -> shake it empty, then get to dirt.
        shake_empty()
        sleep_ms(AFTER_EMPTY_MS)
        recover_to_dirt(detector)
    elif wet and not full:
        # Drifted into the liquid with an empty pan -> walk back to dirt.
        recover_to_dirt(detector)
    elif full:
        # On dirt with a full pan -> run the optimized empty sequence. If it
        # doesn't actually empty, next loop sees "full on dirt" again and retries.
        empty_sequence(detector)
    else:
        # On dirt with room in the pan -> dig.
        dig_once(detector)
        if not State.running: return
        sleep_ms(BETWEEN_DIGS_MS)


# ---- Hotkey listener --------------------------------------------------------
# Hotkeys via GetAsyncKeyState polling (no third-party lib; doesn't conflict with
# our synthetic input). Ctrl+K toggles start/stop, Esc quits. Returns an object
# with .start() so main() can use it just like the macOS pynput listener.
import threading as _threading


def _key_pressed(vk):
    return bool(_user32.GetAsyncKeyState(vk) & 0x8000)


def _code_to_vk_win(code):
    code = code or ""
    if code.startswith("Key") and len(code) == 4:
        return ord(code[3].upper())
    if code.startswith("Digit") and len(code) == 6:
        return ord(code[5])
    if code == "Escape":
        return 0x1B
    if code == "Space":
        return 0x20
    if code.startswith("F") and code[1:].isdigit():
        n = int(code[1:])
        if 1 <= n <= 12:
            return 0x70 + (n - 1)
    return None


def _hk_label(spec):
    spec = spec or {}
    p = []
    if spec.get("ctrl"):
        p.append("Ctrl")
    if spec.get("alt"):
        p.append("Alt")
    if spec.get("shift"):
        p.append("Shift")
    c = spec.get("code", "")
    if c.startswith("Key"):
        p.append(c[3:])
    elif c.startswith("Digit"):
        p.append(c[5:])
    else:
        p.append(c)
    return "+".join(p)


def engine_pause():
    """Session PAUSE: freeze all inputs but keep the session alive -- stats,
    relic timers, earnings, telemetry all survive. Resume picks up mid-run."""
    if State.paused or not State.running:
        return
    State.paused = True
    State.running = False                # every verb aborts instantly
    if State.stats:
        State.stats.pause_started = time.perf_counter()
        State.stats.pauses += 1
    release_all()
    print("[PAUSED] session paused -- stats, relic timers and earnings all "
          "kept; press the pause key to resume", flush=True)


def engine_resume():
    if not State.paused:
        return
    span = 0.0
    if State.stats and State.stats.pause_started is not None:
        span = time.perf_counter() - State.stats.pause_started
        State.stats.pause_accum += span
        State.stats.pause_started = None
    if not RELIC_RELATIVE and span > 0:
        State.relic_shift_pending += span    # timers were frozen with the pause
    State.paused = False
    State.last_progress = time.perf_counter()    # don't trip no-progress
    State.running = True
    print("[RUNNING] resumed from pause (stats & timers kept)", flush=True)


class _HotkeyPoller:
    def start(self):
        _threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        binds = [("toggle", HOTKEY_TOGGLE), ("soft", HOTKEY_SOFTSTOP),
             ("quit", HOTKEY_QUIT), ("popout", HOTKEY_POPOUT),
             ("pause", HOTKEY_PAUSE), ("rreset", HOTKEY_RELIC_RESET)]
        prev = {"toggle": False, "soft": False, "quit": False, "pause": False,
                "rreset": False}
        while State.alive:
            ctrl = _key_pressed(0x11)
            alt = _key_pressed(0x12)
            shift = _key_pressed(0x10)
            # Ctrl+Shift+1..9 -> reset THAT relic's timer alone
            for _d in range(1, 10):
                _k = "d%d" % _d
                _dn = ctrl and shift and _key_pressed(0x30 + _d)
                if _dn and not prev.get(_k):
                    if State.relics_ref is not None:
                        State.relics_ref.reset_one(_d - 1)
                prev[_k] = _dn
            for name, spec in binds:
                vk = _code_to_vk_win((spec or {}).get("code", ""))
                if vk is None:
                    prev[name] = False
                    continue
                down = (_key_pressed(vk)
                        and bool(spec.get("ctrl")) == ctrl
                        and bool(spec.get("alt")) == alt
                        and bool(spec.get("shift")) == shift)
                if down and not prev[name]:
                    if name == "quit":
                        print("[QUIT]")
                        State.running = False
                        State.alive = False
                        release_all()
                        return
                    if name == "toggle":
                        if State.paused:         # toggling out of pause = resume
                            engine_resume()
                        else:
                            State.running = not State.running
                            print(f"[{'RUNNING' if State.running else 'STOPPED'}]")
                            if not State.running:
                                release_all()
                    elif name == "pause":
                        (engine_resume() if State.paused else engine_pause())
                    elif name == "rreset":
                        if State.relics_ref is not None:
                            State.relics_ref.reset()
                        print("[RELIC TIMERS RESET]")
                    elif name == "soft":
                        State.want_safe_stop = True
                        print("[MANUAL SOFT-STOP]")
                    elif name == "popout":
                        print("__POPOUT__", flush=True)
                prev[name] = down
            time.sleep(0.03)


def make_listener():
    return _HotkeyPoller()


# ---- Calibration ------------------------------------------------------------
def calibrate():
    print("CALIBRATE -- hover a target, read PIXEL/RGB, Ctrl+C to quit.")
    print("  GREEN end of dig bar      -> DIG_TRIGGER_PIXEL")
    print("  RIGHT END of capacity bar -> CAP_FULL_PIXEL (gray empty / YELLOW full)")
    print("  GROUND at your feet       -> TERRAIN_PIXEL, then read RGB while")
    print("                               standing on DIRT (->DIRT_RGB) and in")
    print("                               WATER/LAVA (->WET_RGB)\n")
    with _MSS() as sct:
        scale = get_scale(sct)
        full = sct.monitors[1]
        try:
            while True:
                p = _cursor_point()
                px = int(p.x * scale)
                py = int(p.y * scale)
                box = {"left": px - 3, "top": py - 3, "width": 6, "height": 6}
                box["left"] = max(full["left"],
                                  min(box["left"], full["left"] + full["width"] - 6))
                box["top"] = max(full["top"],
                                 min(box["top"], full["top"] + full["height"] - 6))
                img = np.asarray(sct.grab(box))[:, :, :3]
                b, g, r = img.reshape(-1, 3).mean(0)
                tags = ""
                if is_white(r, g, b):  tags += " WHITE"
                if is_yellow(r, g, b): tags += " YELLOW"
                if g >= 110 and (g - r) >= 40 and (g - b) >= 40: tags += " GREEN"
                print(f"\rPIXEL=({px:>5},{py:>5})  RGB=({int(r):>3},{int(g):>3},"
                      f"{int(b):>3})  scale {scale:.2f} [{tags.strip()}]      ",
                      end="", flush=True)
                time.sleep(0.05)
        except KeyboardInterrupt:
            print("\nDone.")


def calibrate_text():
    """Measure the white-text fraction in TEXT_REGION so you can set the bands.
    Stand on dirt (Collect Deposit), in lava (Pan), and mid-shake (Shake);
    record the three FRAC values, then set TEXT_PAN_MAX / TEXT_SHAKE_MAX."""
    l, t, w, h = TEXT_REGION
    region = {"left": l, "top": t, "width": w, "height": h}
    print(f"CALIBRATE TEXT -- region {TEXT_REGION}. Ctrl+C to quit.")
    print("Read FRAC while: on DIRT (Collect Deposit), in LAVA (Pan), mid-SHAKE.")
    print("If the region doesn't sit over the prompt, adjust TEXT_REGION.\n")
    with _MSS() as sct:
        try:
            while True:
                img = np.asarray(sct.grab(region))[:, :, :3]
                frac = float(np.all(img >= TEXT_WHITE_MIN, axis=2).mean())
                if frac <= TEXT_PAN_MAX:
                    guess = "pan"
                elif frac <= TEXT_SHAKE_MAX:
                    guess = "shake"
                else:
                    guess = "deposit"
                print(f"\rFRAC={frac:0.4f}   guess={guess:8}      ",
                      end="", flush=True)
                time.sleep(0.05)
        except KeyboardInterrupt:
            print("\nDone.")


def log_calibration():
    """Log feet colour, capacity colour and text fraction to a CSV while you
    play. Tag what you're doing with global hotkeys so the data is labelled:
        Ctrl+1 = on DIRT      Ctrl+2 = in LAVA/WATER
        Ctrl+3 = mid-SHAKE    Ctrl+4 = DIGGING
        Esc    = stop & save
    Hand me the CSV and I'll read off DIRT_RGB / WET_RGB and the text bands."""
    import os
    path = os.path.join(_DATA_DIR, "prospecting_calib_log.csv")
    label = {"v": "?"}
    stop = {"v": False}
    LABELS = {0x31: "DIRT", 0x32: "LAVA", 0x33: "SHAKE", 0x34: "DIG"}  # vk 1..4

    def _poll():
        while not stop["v"]:
            if _key_pressed(VK_ESC):
                stop["v"] = True
                return
            if _key_pressed(VK_CONTROL):
                for vk, name in LABELS.items():
                    if _key_pressed(vk) and label["v"] != name:
                        label["v"] = name
                        print(f"\n[label = {name}]")
            time.sleep(0.05)

    _threading.Thread(target=_poll, daemon=True).start()

    tl, tt, tw, th = TEXT_REGION
    treg = {"left": tl, "top": tt, "width": tw, "height": th}
    freg = {"left": TERRAIN_PIXEL[0] - 3, "top": TERRAIN_PIXEL[1] - 3,
            "width": 6, "height": 6}
    creg = {"left": CAP_FULL_PIXEL[0] - 3, "top": CAP_FULL_PIXEL[1] - 3,
            "width": 6, "height": 6}

    print("LOGGING to:", path)
    print("Tag while playing: Ctrl+1 DIRT, Ctrl+2 LAVA, Ctrl+3 SHAKE, Ctrl+4 DIG.")
    print("Press Esc to stop & save.\n")
    with _MSS() as sct, open(path, "w") as f:
        f.write("time,label,feet_r,feet_g,feet_b,text_frac,cap_r,cap_g,cap_b\n")
        t0 = time.time()
        while not stop["v"]:
            fb, fg, fr = np.asarray(sct.grab(freg))[:, :, :3].reshape(-1, 3).mean(0)
            cb, cg, cr = np.asarray(sct.grab(creg))[:, :, :3].reshape(-1, 3).mean(0)
            img = np.asarray(sct.grab(treg))[:, :, :3]
            frac = float(np.all(img >= TEXT_WHITE_MIN, axis=2).mean())
            ts = time.time() - t0
            f.write(f"{ts:.2f},{label['v']},{int(fr)},{int(fg)},{int(fb)},"
                    f"{frac:.4f},{int(cr)},{int(cg)},{int(cb)}\n")
            f.flush()
            print(f"\r{ts:6.1f}s {label['v']:6} feet=({int(fr)},{int(fg)},"
                  f"{int(fb)}) text={frac:.4f} cap=({int(cr)},{int(cg)},"
                  f"{int(cb)})    ", end="", flush=True)
            time.sleep(0.1)
    print("\nSaved:", path)


# ---- Main -------------------------------------------------------------------
def main():
    import signal
    def _sigint(_sig, _frm):
        # Ctrl+C in the terminal -> stop everything and exit promptly
        State.running = False
        State.alive = False
        try:
            release_all()
        except Exception:
            pass
        print("\n[interrupted -- exiting]", flush=True)
        os._exit(0)
    try:
        signal.signal(signal.SIGINT, _sigint)
        signal.signal(signal.SIGTERM, _sigint)
    except Exception:
        pass
    load_config()                 # apply UI overrides from prospecting_config.json
    if not apply_auto_calibrate():  # place pixels from the live window (if profile)
        apply_window_offset()       # else shift pixels if the window moved (opt-in)
    place_cue_masks()               # advanced cue matching: place captured masks
    print(__doc__.split("SETUP")[0])
    print(f"Dig trigger pixel {DIG_TRIGGER_PIXEL} (white-line release).")
    print(f"Capacity-full pixel {CAP_FULL_PIXEL} (yellow = full).")
    print(f"Press {_hk_label(HOTKEY_TOGGLE)} to start/stop, {_hk_label(HOTKEY_QUIT)} to quit.\n")

    listener = make_listener()
    listener.start()

    def _stdin_ctl():
        """Control channel from the app (Pause buttons / relic reset)."""
        try:
            for _line in sys.stdin:
                _c = _line.strip().upper()
                if _c == "PAUSE":
                    engine_pause()
                elif _c == "RESUME":
                    engine_resume()
                elif _c == "PAUSE_TOGGLE":
                    (engine_resume() if State.paused else engine_pause())
                elif _c == "RELIC_RESET":
                    if State.relics_ref is not None:
                        State.relics_ref.reset()
                    print("[RELIC TIMERS RESET]", flush=True)
                elif _c.startswith("RELIC_SET "):
                    try:
                        _p = _c.split()
                        _i, _s = int(_p[1]), float(_p[2])
                        if State.relics_ref is not None:
                            State.relics_ref.set_left(_i, _s)
                    except Exception:
                        pass
                elif _c.startswith("RELIC_RESET_ONE "):
                    try:
                        _i = int(_c.split()[1])
                        if State.relics_ref is not None:
                            State.relics_ref.reset_one(_i)
                    except Exception:
                        pass
        except Exception:
            pass
    threading.Thread(target=_stdin_ctl, daemon=True).start()

    gc.enable()   # keep GC ON: disabling it grew memory + slowed long runs
    with _MSS() as sct:
        detector = Detector(sct)
        State.detector = detector
        State.scale = get_scale(sct)
        for _ in range(5):                  # warm up capture path
            sct.grab(detector.dig_region)
        sup = Supervisor()
        relics = RelicScheduler()
        State.relics_ref = relics     # hotkeys/app can reset & set timers
        was_running = False
        last_emit = 0.0
        last_wh_stats = 0.0
        try:
            while State.alive:
                if State.running:
                    if not was_running:     # fresh start -> clear stuck-counters
                        print("__RESET__", flush=True)   # tell the app to clear
                        sup.reset()                      # finds/analytics
                        State.t_side = 0
                        relics.reset()      # start relic timers from now
                        State.stats = SessionStats()
                        State.earn = EarnTracker()
                        State.earn.start()  # no-op unless configured
                        State.finds = FindsWatcher()
                        State.finds.start() # no-op unless configured
                        if TRACKER_MODE:
                            # tracking should GUARANTEE the game is panning:
                            # read the Auto Pan button right away and turn it
                            # on if needed (colour-verified, parks the cursor)
                            _ap = _autopan_state()
                            if _ap is False:
                                log("[tracker] Auto Pan is OFF -> turning it ON")
                                _autopan_set(True)
                            elif _ap is True:
                                log("[tracker] Auto Pan already ON")
                            else:
                                log("[tracker] Auto Pan button not calibrated "
                                    "or unreadable -- start it manually")
                        last_emit = last_wh_stats = time.perf_counter()
                        was_running = True
                        log("=== RUNNING (live trace below) ===")
                        post_webhook("start", "▶️ Macro started",
                                     State.stats.as_dict())
                    if State.want_safe_stop:
                        State.want_safe_stop = False
                        safe_stop("manual soft-stop (test)")
                    if (not TRACKER_MODE) or TRACKER_RELICS:
                        relics.maybe_fire() # timed relic use (no-op unless enabled)
                    if TRACKER_MODE:
                        tracker_tick(detector)   # watch-only: zero input
                    elif TREASURE_MODE:
                        treasure_tick(detector)
                    else:
                        sup.tick(detector)
                    now = time.perf_counter()
                    # live stats line for the app (parsed there, also harmless log)
                    if now - last_emit >= 2.0:
                        last_emit = now
                        _d = State.stats.as_dict()
                        _d["relics"] = relics.remaining()
                        print("__STATS__ " + json.dumps(_d), flush=True)
                    # periodic webhook stats update
                    if (WEBHOOK_STATS_MIN > 0
                            and now - last_wh_stats >= WEBHOOK_STATS_MIN * 60):
                        last_wh_stats = now
                        s = State.stats.as_dict()
                        _m = (f"📊 {s['cycles']} pans · {s['pans_per_hr']}/hr · "
                              f"{s.get('clean_pct', 0)}% clean · "
                              f"{s.get('digs', 0)} digs · "
                              f"{s['runtime_s'] // 60} min\n"
                              f"💰 ${s.get('money_earned', 0):,} earned  "
                              f"(${s.get('money_per_hr', 0):,}/hr · "
                              f"${s.get('money_per_pan', 0):,}/pan)\n"
                              f"💎 {s.get('shards_earned', 0):,} shards  "
                              f"({s.get('shards_per_hr', 0):,}/hr · "
                              f"{s.get('shards_per_pan', 0)}/pan)\n"
                              f"🛠 {s.get('recoveries', 0)} rec · "
                              f"{s.get('nudges', 0)} nudges · "
                              f"{s.get('safe_stops', 0)} safe · "
                              f"{s.get('hard_stops', 0)} hard · "
                              f"{s.get('relics_used', 0)} relics")
                        post_webhook("stats", _m, s, shot=True)
                    # auto-stop timer
                    if (AUTOSTOP_ENABLED and State.stats
                            and State.stats.runtime() >= AUTOSTOP_MINUTES * 60):
                        log(f"=== AUTO-STOP after {AUTOSTOP_MINUTES} min ===")
                        State.stop_reason = "auto"
                        if State.stats: State.stats.stop_reason = "auto"
                        post_webhook("autostop", f"⏱️ Auto-stopped after "
                                     f"{AUTOSTOP_MINUTES} min", State.stats.as_dict())
                        State.running = False
                        release_all()
                    # bag-full guard (stop after N pans)
                    if (STOP_AFTER_PANS > 0 and State.stats
                            and State.stats.cycles >= STOP_AFTER_PANS):
                        log(f"=== STOP after {STOP_AFTER_PANS} pans (bag-full guard) ===")
                        State.stop_reason = "bag-full"
                        if State.stats: State.stats.stop_reason = "bag-full"
                        post_webhook("bag_full", f"🎒 Stopped after "
                                     f"{STOP_AFTER_PANS} pans (bag likely full)",
                                     State.stats.as_dict())
                        State.running = False
                        release_all()
                else:
                    if State.paused:
                        # session PAUSE: keep was_running TRUE so resuming
                        # skips the fresh-start init (stats/relics survive)
                        time.sleep(0.1)
                        continue
                    if was_running:
                        reason = ((State.stats.stop_reason if State.stats
                                   and State.stats.stop_reason else State.stop_reason)
                                  or "manual")
                        if State.stats:
                            State.stats.stop_reason = reason
                        log(f"=== STOPPED ({reason}) ===")
                        if reason == "manual" and State.stats:
                            post_webhook("stop", "⏹️ Macro stopped (manual)",
                                         State.stats.as_dict())
                        State.stop_reason = ""
                        State.safe_retries = 0
                    was_running = False
                    time.sleep(0.02)
        except Exception as _e:
            post_webhook("error", f"❌ Macro error: {_e}",
                         State.stats.as_dict() if State.stats else None)
            raise
        finally:
            release_all()
            gc.enable()
            print("Stopped, all inputs released.")


def monitor():
    """Live sensor readout, NO input sent. Verify the cues/capacity read right
    on land, in the water, and mid-shake. Ctrl+C to quit."""
    load_config()                 # apply UI overrides from prospecting_config.json
    if not apply_auto_calibrate():
        apply_window_offset()
    place_cue_masks()
    print("MONITOR -- no input. Watch the values on land / in water / mid-shake.\n")
    with _MSS() as sct:
        det = Detector(sct)
        try:
            while True:
                s = sense_stable(det)
                dep = "DEP " if s.dep else "----"
                pan = "PAN " if s.pan else "----"
                shk = "SHAKE" if s.shk else "-----"
                full = "FULL" if s.full else "----"
                empt = "EMPTY" if s.empty else "fill "
                print(f"\rcue:[{dep}{pan}{shk}] cap:[{full} {empt}]  "
                      f"=> {s.where:7}/{s.contents:7} plan: {plan_label(s):18}",
                      end="", flush=True)
                time.sleep(0.1)
        except KeyboardInterrupt:
            print("\nDone.")


if __name__ == "__main__":
    arg = sys.argv[1] if len(sys.argv) > 1 else ""
    if arg == "calibrate":
        calibrate()
    elif arg == "calibrate-text":
        calibrate_text()
    elif arg == "log":
        log_calibration()
    elif arg == "monitor":
        monitor()
    else:
        main()
